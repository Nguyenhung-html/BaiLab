<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
<jsp:include page="../menu.jsp"></jsp:include>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách phòng ban</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            color: #ffffff;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        h1 { 
            text-align: center;
            margin: 40px 0;
            font-size: 2.5em;
            font-weight: 300;
            letter-spacing: 2px;
            text-transform: uppercase;
            background: linear-gradient(45deg, #ffffff, #888888);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .form-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            margin: 30px auto;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            transition: transform 0.3s ease;
        }

        .form-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            letter-spacing: 1px;
            color: #e0e0e0;
            font-size: 0.9em;
        }

        input[type="text"] {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: #ffffff;
            font-size: 1em;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #ffffff;
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
        }

        input[type="text"]::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }

        .button-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 30px;
        }

        button {
            padding: 12px 30px;
            border: 2px solid #ffffff;
            background: transparent;
            color: #ffffff;
            font-size: 1em;
            font-weight: 600;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            letter-spacing: 1px;
            text-transform: uppercase;
            position: relative;
            overflow: hidden;
        }

        button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: #ffffff;
            transition: left 0.3s ease;
            z-index: -1;
        }

        button:hover::before {
            left: 0;
        }

        button:hover {
            color: #000000;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(255, 255, 255, 0.3);
        }

        button:active {
            transform: translateY(0);
        }

        .search-box {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-top: 20px;
            justify-content: center;
        }

        .search-box input {
            max-width: 400px;
        }

        .table-container {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 30px;
            margin: 30px auto;
            overflow-x: auto;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        table { 
            border-collapse: collapse;
            width: 100%;
            border-radius: 10px;
            overflow: hidden;
        }

        th {
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
            color: #ffffff;
            padding: 20px;
            text-align: center;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            font-size: 0.9em;
            border-bottom: 2px solid rgba(255, 255, 255, 0.2);
        }

        td { 
            padding: 18px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: #e0e0e0;
        }

        tr {
            transition: all 0.3s ease;
        }

        tr:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: scale(1.01);
        }

        tr:nth-child(even) { 
            background: rgba(255, 255, 255, 0.02);
        }

        .action-links {
            display: flex;
            gap: 15px;
            justify-content: center;
            align-items: center;
        }

        .action-links a {
            color: #ffffff;
            text-decoration: none;
            padding: 8px 20px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 20px;
            transition: all 0.3s ease;
            font-size: 0.9em;
            font-weight: 500;
        }

        .action-links a:hover {
            background: #ffffff;
            color: #000000;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.3);
        }

        .empty-message {
            text-align: center;
            padding: 40px;
            color: rgba(255, 255, 255, 0.6);
            font-size: 1.1em;
            font-style: italic;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 1.8em;
            }

            .form-card {
                padding: 25px;
            }

            .button-group {
                flex-direction: column;
            }

            button {
                width: 100%;
            }

            table {
                font-size: 0.9em;
            }

            th, td {
                padding: 12px 8px;
            }

            .action-links {
                flex-direction: column;
                gap: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Danh sách Phòng Ban</h1>

        <!-- Form thêm / tìm kiếm / xóa -->
        <div class="form-card">
            <form method="post">
                <div class="form-group">
                    <label>Mã Phòng ban:</label>
                    <input type="text" name="id" value="${departmentEdit.id}" placeholder="Nhập mã phòng ban..." />
                </div>

                <div class="form-group">
                    <label>Tên phòng ban:</label>
                    <input type="text" name="name" value="${departmentEdit.name}" placeholder="Nhập tên phòng ban..." />
                </div>

                <div class="form-group">
                    <label>Mô tả:</label>
                    <input type="text" name="description" value="${departmentEdit.description}" placeholder="Nhập mô tả..." />
                </div>

                <div class="button-group">
                    <button formaction="${pageContext.request.contextPath}/Departments/update" name="action" value="update">Cập nhật</button>
                    <button formaction="${pageContext.request.contextPath}/Departments/delete" name="action" value="delete">Xóa</button>
                    <button formaction="${pageContext.request.contextPath}/Departments/add" name="action" value="add">Thêm Mới</button>
                </div>

                <div class="search-box">
                    <input type="text" name="txttim" placeholder="Nhập từ khóa tìm kiếm..." />
                    <button formaction="${pageContext.request.contextPath}/Departments/find" name="action" value="find">Tìm</button>
                </div>
            </form>
        </div>

        <!-- Bảng danh sách phòng ban -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Mã phòng ban</th>
                        <th>Tên phòng ban</th>
                        <th>Mô tả</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${not empty departments}">
                            <c:forEach var="d" items="${departments}">
                                <tr>
                                    <td>${d.id}</td>
                                    <td>${d.name}</td>
                                    <td>${d.description}</td>
                                    <td>
                                        <div class="action-links">
                                            <a href="${pageContext.request.contextPath}/Departments/edit?id=${d.id}">Edit</a>
                                            <a href="${pageContext.request.contextPath}/Departments/delete?id=${d.id}" onclick="return confirm('Bạn có chắc muốn xóa?');">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="4" class="empty-message">Không có phòng ban nào!</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>