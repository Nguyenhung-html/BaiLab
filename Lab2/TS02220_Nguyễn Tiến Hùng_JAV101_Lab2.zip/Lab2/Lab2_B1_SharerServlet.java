package Lab2;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Lab2_JSP/Bai1SharerServlet")
public class Lab2_B1_SharerServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
		throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.setAttribute("message","welcome to FPT Polytechnic !");
	req.setAttribute("now", new Date());

	req.getRequestDispatcher("/Lab2_JSP/L2_B1_page.jsp").forward(req, resp);
	
}
}
