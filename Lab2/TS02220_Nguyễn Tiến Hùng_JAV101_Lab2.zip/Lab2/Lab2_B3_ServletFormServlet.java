package Lab2;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet({"/Lab2_JSP/Bai3ServletFormServlet","/L2_form/ud","/L2_form/create"})
public class Lab2_B3_ServletFormServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
				req.setAttribute("message", "Welcome to FPT Polytechnic");
				Map<String, Object> map = new HashMap<>();
				map.put("fullname","Nguyễn Tiến Hùng");
				map.put("gender", true);
				map.put("country", "Việt Nam");
				req.setAttribute("user", map);
				req.getRequestDispatcher("/L2_form/form.jsp").forward(req, resp);
				
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = req.getRequestURI();
		if(uri.contains("/L2_form/ud")) {
			String  fullname =  req .getParameter( "fullname" );
			System.out.println(fullname);
			String  gender =  req .getParameter( "gender" );
			
			String  country =  req .getParameter( "country" );
			
			Map<String, Object> map = new HashMap<>();
			map.put("fullname",fullname);
			map.put("gender", gender);
			map.put("country", country);
			req.setAttribute("user", map);
			req.setAttribute("capnhat", "Cập nhật thành công");
			req.getRequestDispatcher("/L2_form/form.jsp").forward(req, resp);
			
		}else if(uri.contains("/L2_form/create")){
			String fullname = req.getParameter("fullname");
			String gender = req.getParameter("gender");
			String country = req.getParameter("country");
			
			Map<String, Object> map = new HashMap<>();
			map.put("fullname",fullname);
			map.put("gender", gender);
			map.put("country", country);
			req.setAttribute("user", map);
			req.getRequestDispatcher("/L2_form/themmoi.jsp").forward(req, resp);
		}
		
		
		
	}
	
}

