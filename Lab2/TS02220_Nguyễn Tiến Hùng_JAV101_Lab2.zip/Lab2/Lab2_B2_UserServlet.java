package Lab2;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Lab2_JSP/Bai2UserServlet")

public class Lab2_B2_UserServlet extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	req.setAttribute("message", "Welcome to FPT Polytechnic");
	Map<String, Object> map = new HashMap<>();
	map.put("fullname","Nguyễn Tiến Hùng");
	map.put("gender", "Nam");
	map.put("country", "Việt Nam");
	req.setAttribute("user", map);
	req.getRequestDispatcher("/Lab2_JSP/L2_B2_page.jsp").forward(req, resp);
	
	
}
}
