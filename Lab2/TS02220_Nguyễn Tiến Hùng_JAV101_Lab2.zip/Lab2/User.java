package Lab2;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Lab2_JSP/Bai4User")
public class User extends HttpServlet {
	String  fullname; 
	boolean gender; 
	String  country ;
	
    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public boolean isGender() { 
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	// TODO Auto-generated method stub
    	User  bean =  new User();
    	bean. setFullname( "Nguyễn Tiến Hùng");
    	bean. setGender( true );
    	bean. setCountry(" VN" );
    	req. setAttribute( "user" ,  bean) ;
    	req.getRequestDispatcher("/L2_form/form.jsp").forward(req, resp);
    }
}

