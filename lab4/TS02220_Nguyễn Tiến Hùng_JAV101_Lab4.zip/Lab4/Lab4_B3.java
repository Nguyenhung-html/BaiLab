package Lab4;
import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/Lab4_JSP/add")
@MultipartConfig
public class Lab4_B3 extends HttpServlet {
	  @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        req.getRequestDispatcher("/Lab4_JSP/L4_B3_form.jsp").forward(req, resp);
	    }

	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {

	        // Lấy thông tin từ form
	        String fullname = request.getParameter("fullname");
	        String password = request.getParameter("password");
	        String gender = request.getParameter("gender");
	        String married = request.getParameter("married");
	        String country = request.getParameter("country");
	        String note = request.getParameter("note");
	        String[] hobbies = request.getParameterValues("hobbies");

	        // Xử lý file ảnh
	        Part filePart = request.getPart("photo_file");
	        String fileName = filePart.getSubmittedFileName();

	        // Lưu file lên server
	        String uploadPath = request.getServletContext().getRealPath("uploads");
	        File uploadDir = new File(uploadPath);
	        if (!uploadDir.exists()) uploadDir.mkdirs();

	        filePart.write(uploadPath + File.separator + fileName);

	        // Gửi sang JSP để hiển thị lại
	        request.setAttribute("fullname", fullname);
	        request.setAttribute("password", password);
	        request.setAttribute("gender", gender);
	        request.setAttribute("married", married);
	        request.setAttribute("country", country);
	        request.setAttribute("note", note);
	        request.setAttribute("hobbies", hobbies);
	        request.setAttribute("photo", fileName);

	        request.getRequestDispatcher("/Lab4_JSP/L4_B3_ketqua.jsp").forward(request, response);
	    }

}

