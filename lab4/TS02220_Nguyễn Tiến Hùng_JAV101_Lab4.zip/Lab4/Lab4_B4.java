package Lab4;
import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/upload")
@MultipartConfig
public class Lab4_B4 extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse resp) 
		    throws ServletException, IOException {

		    Part photo = req.getPart("photo");
		    
		    // 1. Định nghĩa đường dẫn tương đối (chỉ là thư mục)
		    String uploadDir = "/static/files"; 
		    
		    // 2. Lấy đường dẫn vật lý tuyệt đối của thư mục lưu file
		    String appPath = req.getServletContext().getRealPath(""); // Lấy root path của ứng dụng
		    String savePath = appPath + uploadDir; // Đường dẫn tuyệt đối đến thư mục lưu
		    
		    // 3. TẠO THƯ MỤC NẾU CHƯA TỒN TẠI (Đây là phần quan trọng nhất)
		    File fileSaveDir = new File(savePath);
		    if (!fileSaveDir.exists()) {
		        fileSaveDir.mkdirs(); // Tạo tất cả các thư mục cha và thư mục con cần thiết
		    }
		    
		    // 4. Tạo đường dẫn tuyệt đối cho file
		    String fileName = photo.getSubmittedFileName();
		    String filename = savePath + File.separator + fileName; // Sử dụng File.separator cho tính di động

		    // 5. Ghi file
		    photo.write(filename);
		    
		    // Thiết lập thông báo thành công (tùy chọn)
		    req.setAttribute("message", "Upload file " + fileName + " thành công!");

		    req.getRequestDispatcher("/Lab4_JSP/L4_B4.jsp").forward(req, resp);
		}
}
