package Lab1;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/bai4")
public class Lab1_B4 extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		// Kiểm tra đường dẫn và xuất thông báo tương ứng
		if (uri.contains("/crud/them"))
			resp.getWriter().println("<h1>Createing a new record...</h1>");
		else if (uri.contains("/crud/xoa"))
			resp.getWriter().println("<h1>Deleting a new record...</h1>");
		else if (uri.contains("/crud/sua"))
			resp.getWriter().println("<h1>Updating a new record...</h1>");
		else 
			resp.getWriter().println("<h1>Not known</h1>");
}
}
