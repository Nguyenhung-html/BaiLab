package Lab3;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Lab3_JSP/Lab3Bai4")
public class Lab3_B4_Controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<>();
		map.put("title", "Tiêu đề bản tin");
		map.put("content", "Nội dung bản tin thường rất dài");
		req.setAttribute("item", map);
		req.getRequestDispatcher("/Lab3_JSP/L3_B4.jsp").forward(req, resp);
	}
	}

