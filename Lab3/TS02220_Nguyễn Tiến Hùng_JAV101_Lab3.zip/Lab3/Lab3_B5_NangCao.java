package Lab3;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Lab3_JSP/Lab3Bai5")
public class Lab3_B5_NangCao extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	
	
	ArrayList<String> danhsach = new ArrayList<String>();
	danhsach.add("Iphone 17");
	danhsach.add("Iphone 16");
	danhsach.add("Iphone 15");
	danhsach.add("Iphone 14");
	req.setAttribute("ds", danhsach);
	
	ArrayList<Lab3_B5_Items> items = new ArrayList<>();
	
	items.add(new Lab3_B5_Items("Iphone 17 Promax", "Iphone17.jpg", 32.000000, 0.8)); 
	items.add(new Lab3_B5_Items("Iphone 16 Promax", "Iphone16.jpg", 30.000000, 0.5));
	items.add(new Lab3_B5_Items("Iphone 15 Promax", "Iphone15.jpg", 28.000000, 0.3));
	items.add(new Lab3_B5_Items("Iphone 14 Promax", "Iphone14.jpg", 20.000000, 0.2));
	
	req.setAttribute("items", items); 
	req.getRequestDispatcher("/Lab3_JSP/L3_B5.jsp").forward(req, resp);
	
}

}