package Lab3;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet({"/Lab3_JSP/Lab3bai1","/Lab3_JSP/Lab3Bai2"})
public class Lab3_B1_Controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	List<Lab3_B1_Country> list = List.of(
			new Lab3_B1_Country("VN", "Việt Nam"),
			new Lab3_B1_Country("US", "United States"),
			new Lab3_B1_Country("CN", "China")
			);
			req.setAttribute("countries", list);
			
			String url = req.getServletPath();
			
			if(url.contains("Lab3bai1")) {
				req.getRequestDispatcher("/Lab3_JSP/L3_B1.jsp").forward(req, resp);
			}else if(url.contains("Lab3Bai2")) {
				req.getRequestDispatcher("/Lab3_JSP/L3_B2.jsp").forward(req, resp);
			}
	
}
}
