package Lab3;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Lab3_JSP/ProductDetailServlet")
public class Lab3_B5_NC_ChiTiet  extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	
	String name = req.getParameter("id");
	selectById(name,req);
	req.getRequestDispatcher("/Lab3_JSP/L3_B5_CT.jsp").forward(req, resp);
	
	
}
public void selectById(String name ,HttpServletRequest request ) throws ServletException, IOException{
	{
		ArrayList<Lab3_B5_Items> items = new ArrayList<>();	
		items.add(new Lab3_B5_Items("Iphone 17 Promax", "Iphone17.jpg", 32.000000, 0.8)); 
		items.add(new Lab3_B5_Items("Iphone 16 Promax", "Iphone16.jpg", 30.000000, 0.5));
		items.add(new Lab3_B5_Items("Iphone 15 Promax", "Iphone15.jpg", 28.000000, 0.3));
		items.add(new Lab3_B5_Items("Iphone 14 Promax", "Iphone14.jpg", 20.000000, 0.2));
		
		ArrayList<Lab3_B5_Items> selecteditems = new ArrayList<>();
		for(Lab3_B5_Items item : items) {
			if (item.getName().equalsIgnoreCase(name)) {
				selecteditems.add(item);
			}
		}
		
		//Luu danh sach da chon vao request de chuyen tiep toi trang JSP
		request.setAttribute("seclectitems", selecteditems);
	
	}
}
@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);

	}
}
