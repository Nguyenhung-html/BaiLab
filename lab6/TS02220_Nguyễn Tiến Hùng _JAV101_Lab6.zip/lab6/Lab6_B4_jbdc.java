package lab6;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Lab6_B4_jbdc {

    static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static String dburl = "jdbc:sqlserver://localhost:1433;databaseName=lab6_java3_csdl;encrypt=false;trustServerCertificate=true;";
    static String username = "sa";
    static String password = "123";

    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    /** Mở kết nối */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dburl, username, password);
    }

    /** Thao tác dữ liệu (INSERT, UPDATE, DELETE) */
    public static int executeUpdate(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        CallableStatement statement = connection.prepareCall(sql);

        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }

        return statement.executeUpdate();
    }

    /** Truy vấn dữ liệu (SELECT) */
    public static ResultSet executeQuery(String sql, Object... values) throws SQLException {
        Connection connection = getConnection();
        CallableStatement statement = connection.prepareCall(sql);

        for (int i = 0; i < values.length; i++) {
            statement.setObject(i + 1, values[i]);
        }

        return statement.executeQuery();
    }

    /** HÀM MAIN - GỌI CÁC THỦ TỤC */
    public static void main(String[] args) {

        // ================================================
        // 1. TRUY VẤN TẤT CẢ
        // ================================================
        try {
            System.out.println("=== TRUY VẤN TẤT CẢ ===");

            String sql = "{CALL spSelectAll}";
            ResultSet rs = executeQuery(sql);

            while (rs.next()) {
                System.out.println(
                        rs.getString("Id") + " | " +
                        rs.getString("Name") + " | " +
                        rs.getString("Description")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        // ================================================
        // 2. TRUY VẤN THEO KHÓA CHÍNH
        // ================================================
        try {
            System.out.println("\n=== TRUY VẤN THEO ID ===");

            String sql = "{CALL spSelectById(?)}";
            ResultSet rs = executeQuery(sql, "001");

            if (rs.next()) {
                System.out.println("Tìm thấy: " + rs.getString("Name"));
            } else {
                System.out.println("Không tồn tại!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        // ================================================
        // 3. THÊM MỚI
        // ================================================
        try {
            System.out.println("\n=== THÊM MỚI ===");

            String sql = "{CALL spInsert(?, ?, ?)}";
            int rows = executeUpdate(sql, "010", "Design", "Design Department");

            System.out.println("Thêm thành công, số dòng ảnh hưởng: " + rows);

        } catch (Exception e) {
            e.printStackTrace();
        }


        // ================================================
        // 4. CẬP NHẬT
        // ================================================
        try {
            System.out.println("\n=== CẬP NHẬT ===");

            String sql = "{CALL spUpdate(?, ?, ?)}";
            int rows = executeUpdate(sql, "010", "Design Updated", "Updated Description");

            System.out.println("Cập nhật thành công, số dòng ảnh hưởng: " + rows);

        } catch (Exception e) {
            e.printStackTrace();
        }


        // ================================================
        // 5. XÓA THEO KHÓA CHÍNH
        // ================================================
        try {
            System.out.println("\n=== XÓA THEO ID ===");

            String sql = "{CALL spDeleteById(?)}";
            int rows = executeUpdate(sql, "010");

            System.out.println("Xóa thành công, số dòng ảnh hưởng: " + rows);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
