-- Tạo bảng Departments
CREATE DATABASE lab6_java3_csdl
use lab6_java3_csdl
CREATE TABLE Departments (
    id CHAR(3) NOT NULL PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL,
    Description NVARCHAR(255) NULL
);
GO

-- Tạo bảng Employees
CREATE TABLE Employees (
    Id VARCHAR(20) NOT NULL PRIMARY KEY,
    Password NVARCHAR(50) NOT NULL,
    Fullname NVARCHAR(50) NOT NULL,
    Photo NVARCHAR(50) NOT NULL,
    Gender BIT NOT NULL,
    Birthday DATE NOT NULL,
    Salary FLOAT NOT NULL,
    DepartmentId CHAR(3) NOT NULL,
    FOREIGN KEY (DepartmentId) REFERENCES Departments(id) 
    ON UPDATE CASCADE 
    ON DELETE CASCADE
);
GO

-- Thêm dữ liệu cho bảng Departments
INSERT INTO Departments (id, Name, Description) 
VALUES 
('001', 'Sales', 'Sales Department'),
('002', 'HR', 'Human Resources Department'),
('003', 'IT', 'Information Technology Department');

-- Thêm dữ liệu cho bảng Employees
INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) 
VALUES 
('E001', 'pass123', 'John Doe', 'john.jpg', 1, '1990-05-15', 50000, '001'),
('E002', 'pass234', 'Jane Smith', 'jane.jpg', 0, '1988-07-23', 60000, '002'),
('E003', 'pass345', 'Michael Johnson', 'michael.jpg', 1, '1985-02-12', 55000, '003');
GO
/*Truy vấn tất cả*/
select * from Departments
select * from Employees

/*Truy vấn theo khóa chính*/
SELECT * FROM Employees WHERE Id = 'E001';
SELECT * FROM Departments WHERE Id = '001';

/*Thêm mới*/
INSERT INTO Departments (id, Name, Description) VALUES ('004', N'Marketing', N'Marketing Department');
INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId) 
VALUES ('E004', 'pass456', N'Anna Lee', 'anna.jpg', 0, '1992-03-10', 65000, '004');

/*Cập nhật theo khóa chính*/
UPDATE Employees
SET 
    Fullname = N'Jane Smith Updated',
    Salary = 62000
WHERE Id = 'E002';

UPDATE Departments
SET Name = N'Information Tech Updated'
WHERE id = '003';

/*Insert*/
ALTER PROCEDURE spInsert(
    @Id CHAR(3),
    @Name NVARCHAR(50),
    @Description NVARCHAR(100)
)
AS BEGIN
INSERT INTO Departments(Id, Name, Description)
VALUES(@Id, @Name, @Description)
END
/*Update*/
ALTER PROCEDURE spUpdate(
    @Id CHAR(3),
    @Name NVARCHAR(50),
    @Description NVARCHAR(100)
)
AS BEGIN
UPDATE Departments
SET Name=@Name, Description=@Description
WHERE Id=@Id
END

ALTER PROCEDURE spDeleteById(
    @Id CHAR(3)
)
AS BEGIN
DELETE FROM Departments WHERE Id=@Id
END

select * from Departments
/* truy vấn tất cả */
EXEC spSelectAll;
/* Tìm kiếm theo Id*/
EXEC spSelectById '001';
/*Thêm mới */
EXEC spInsert '010', N'Design', N'Design Department';
/*Cập nhật theo khóa chính */
EXEC spUpdate '010', N'Design Updated', N'New Description';
/*Xóa theo khóa chính */
EXEC spDeleteById '010';