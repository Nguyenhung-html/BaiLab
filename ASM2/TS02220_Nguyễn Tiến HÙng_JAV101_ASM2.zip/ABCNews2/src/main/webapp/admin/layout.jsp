<!-- admin-layout.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ page isErrorPage="false"%>
<%@ page buffer="256kb" autoFlush="true"%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chuyển động 24 Giờ - Quản trị</title>
<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
	margin: 0;
	padding: 0;
	box-sizing: border-box;
}

body {
	font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
	background: #f5f6fa;
	color: #333;
	display: flex;
	min-height: 100vh;
}

/* Sidebar */
.sidebar {
	width: 260px;
	background: linear-gradient(180deg, #c8102e 0%, #8b0a1f 100%);
	color: white;
	position: fixed;
	height: 100vh;
	overflow-y: auto;
	box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
	z-index: 1000;
	transition: all 0.3s;
}

.sidebar-header {
	padding: 25px 20px;
	background: rgba(0, 0, 0, 0.2);
	border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.admin-logo {
	font-size: 24px;
	font-weight: bold;
	color: white;
	text-decoration: none;
	display: flex;
	align-items: center;
	gap: 10px;
}

.admin-logo i {
	font-size: 28px;
	color: #ffd700;
}

.user-profile {
	padding: 20px;
	background: rgba(0, 0, 0, 0.15);
	margin: 20px;
	border-radius: 10px;
	text-align: center;
}

.user-avatar {
	width: 70px;
	height: 70px;
	border-radius: 50%;
	background: linear-gradient(135deg, #ffd700, #ffed4e);
	display: flex;
	align-items: center;
	justify-content: center;
	margin: 0 auto 15px;
	font-size: 32px;
	color: #c8102e;
}

.user-name {
	font-weight: 600;
	font-size: 16px;
	margin-bottom: 5px;
}

.user-role {
	font-size: 13px;
	color: #ffd700;
	opacity: 0.9;
}

.nav-menu {
	list-style: none;
	padding: 10px 0;
}

.nav-menu li {
	margin: 5px 0;
}

.nav-menu a {
	display: flex;
	align-items: center;
	gap: 12px;
	padding: 15px 20px;
	color: rgba(255, 255, 255, 0.9);
	text-decoration: none;
	transition: all 0.3s;
	position: relative;
	font-size: 15px;
}

.nav-menu a::before {
	content: '';
	position: absolute;
	left: 0;
	top: 0;
	height: 100%;
	width: 4px;
	background: #ffd700;
	transform: scaleY(0);
	transition: transform 0.3s;
}

.nav-menu a:hover, .nav-menu a.active {
	background: rgba(255, 255, 255, 0.15);
	color: white;
}

.nav-menu a:hover::before, .nav-menu a.active::before {
	transform: scaleY(1);
}

.nav-menu a i {
	width: 20px;
	text-align: center;
	font-size: 18px;
}

.nav-divider {
	height: 1px;
	background: rgba(255, 255, 255, 0.1);
	margin: 15px 20px;
}

/* Main Content */
.main-content {
	margin-left: 260px;
	flex: 1;
	display: flex;
	flex-direction: column;
	min-height: 100vh;
}

.top-bar {
	background: white;
	padding: 20px 30px;
	box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
	display: flex;
	justify-content: space-between;
	align-items: center;
	position: sticky;
	top: 0;
	z-index: 100;
}

.page-title {
	font-size: 24px;
	font-weight: 600;
	color: #2c3e50;
}

.top-actions {
	display: flex;
	gap: 15px;
	align-items: center;
}

.btn-logout {
	padding: 10px 20px;
	background: linear-gradient(135deg, #c8102e, #8b0a1f);
	color: white;
	border: none;
	border-radius: 8px;
	cursor: pointer;
	transition: all 0.3s;
	text-decoration: none;
	display: inline-flex;
	align-items: center;
	gap: 8px;
	font-weight: 500;
	font-size: 14px;
}

.btn-logout:hover {
	transform: translateY(-2px);
	box-shadow: 0 5px 15px rgba(200, 16, 46, 0.3);
}

.content-area {
	flex: 1;
	padding: 30px;
}

.content-box {
	background: white;
	padding: 30px;
	border-radius: 15px;
	box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
	min-height: 500px;
}

/* Stats Cards */
.stats-grid {
	display: grid;
	grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
	gap: 20px;
	margin-bottom: 30px;
}

.stat-card {
	background: white;
	padding: 25px;
	border-radius: 15px;
	box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
	display: flex;
	align-items: center;
	gap: 20px;
	transition: all 0.3s;
}

.stat-card:hover {
	transform: translateY(-5px);
	box-shadow: 0 5px 25px rgba(0, 0, 0, 0.15);
}

.stat-icon {
	width: 60px;
	height: 60px;
	border-radius: 12px;
	display: flex;
	align-items: center;
	justify-content: center;
	font-size: 28px;
	color: white;
}

.stat-icon.news {
	background: linear-gradient(135deg, #c8102e, #8b0a1f);
}

.stat-icon.users {
	background: linear-gradient(135deg, #667eea, #764ba2);
}

.stat-icon.categories {
	background: linear-gradient(135deg, #f093fb, #f5576c);
}

.stat-icon.views {
	background: linear-gradient(135deg, #4facfe, #00f2fe);
}

.stat-info h3 {
	font-size: 32px;
	font-weight: bold;
	color: #2c3e50;
	margin-bottom: 5px;
}

.stat-info p {
	color: #7f8c8d;
	font-size: 14px;
}

/* Footer */
/* Admin Footer */
.admin-footer {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
    color: white;
    text-align: center;
    padding: 25px 20px;
    margin-top: auto;
    position: relative;
    overflow: hidden;
    box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.1);
}

/* Decorative Top Border */
.admin-footer::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #c41e3a 0%, #ff8c42 50%, #e74c3c 100%);
}

/* Background Decoration */
.admin-footer::after {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 50%;
}

/* Footer Text */
.admin-footer p,
.admin-footer span,
.admin-footer a {
    position: relative;
    z-index: 1;
}

.admin-footer {
    font-size: 14px;
    line-height: 1.8;
    color: rgba(255, 255, 255, 0.9);
}

/* Responsive */
@media (max-width: 768px) {
    .admin-footer {
        padding: 20px 15px;
        font-size: 13px;
    }
}

/* Alerts */
.alert {
	padding: 15px 20px;
	border-radius: 10px;
	margin-bottom: 20px;
	display: flex;
	align-items: center;
	gap: 10px;
	animation: slideDown 0.3s;
}

.alert-success {
	background: #d4edda;
	color: #155724;
	border-left: 4px solid #28a745;
}

.alert-error {
	background: #f8d7da;
	color: #721c24;
	border-left: 4px solid #dc3545;
}

.alert-info {
	background: #d1ecf1;
	color: #0c5460;
	border-left: 4px solid #17a2b8;
}

@
keyframes slideDown {from { transform:translateY(-20px);
	opacity: 0;
}

to {
	transform: translateY(0);
	opacity: 1;
}

}

/* Mobile Toggle */
.mobile-toggle {
	display: none;
	position: fixed;
	top: 20px;
	left: 20px;
	z-index: 1001;
	background: #c8102e;
	color: white;
	border: none;
	width: 45px;
	height: 45px;
	border-radius: 10px;
	cursor: pointer;
	font-size: 20px;
}

/* Responsive */
@media ( max-width : 768px) {
	.sidebar {
		transform: translateX(-100%);
	}
	.sidebar.active {
		transform: translateX(0);
	}
	.main-content {
		margin-left: 0;
	}
	.mobile-toggle {
		display: block;
	}
	.stats-grid {
		grid-template-columns: 1fr;
	}
	.top-bar {
		padding: 15px 70px 15px 20px;
	}
	.content-area {
		padding: 20px 15px;
	}
}

/* Scrollbar */
.sidebar::-webkit-scrollbar {
	width: 6px;
}

.sidebar::-webkit-scrollbar-track {
	background: rgba(0, 0, 0, 0.1);
}

.sidebar::-webkit-scrollbar-thumb {
	background: rgba(255, 255, 255, 0.3);
	border-radius: 3px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
	background: rgba(255, 255, 255, 0.5);
}
</style>
</head>
<body>
	<!-- Mobile Toggle Button -->
	<button class="mobile-toggle" onclick="toggleSidebar()">
		<i class="fas fa-bars"></i>
	</button>

	<!-- Sidebar -->
	<aside class="sidebar" id="sidebar">
		<div class="sidebar-header">
			<a href="${pageContext.request.contextPath}/admin" class="admin-logo">
				<i class="fas fa-newspaper"></i> <span>Chuyển động 24 Giờ
					Admin</span>
			</a>
		</div>

		<div class="user-profile">
			<div class="user-avatar">
				<i class="fas fa-user"></i>
			</div>
			<div class="user-name">${sessionScope.user.fullname}</div>
			<div class="user-role">
				<c:choose>
					<c:when test="${sessionScope.user.role == 1}">
						<i class="fas fa-crown"></i> Quản trị viên
        </c:when>
					<c:when test="${sessionScope.user.role == 0}">
						<i class="fas fa-pen"></i> Phóng viên
        </c:when>
					<c:otherwise>
						<i class="fas fa-user"></i> Người đọc
        </c:otherwise>
				</c:choose>
			</div>
		</div>

		<nav>
			<ul class="nav-menu">
				<li><a href="${pageContext.request.contextPath}/"> <i
						class="fas fa-home"></i> <span>Trang chủ</span>
				</a></li>
				<li><a href="${pageContext.request.contextPath}/admin"
					class="active"> <i class="fas fa-chart-line"></i> <span>Dashboard</span>
				</a></li>

				<div class="nav-divider"></div>

				<li><a href="${pageContext.request.contextPath}/admin/news">
						<i class="fas fa-newspaper"></i> <span>Quản lý tin tức</span>
				</a></li>

				<c:if test="${sessionScope.user.role == 1}">
					<li><a
						href="${pageContext.request.contextPath}/admin/categories"> <i
							class="fas fa-folder-open"></i> <span>Danh mục tin</span>
					</a></li>
					<li><a href="${pageContext.request.contextPath}/admin/users">
							<i class="fas fa-users"></i> <span>Người dùng</span>
					</a></li>
					<li><a
						href="${pageContext.request.contextPath}/admin/newsletters"> <i
							class="fas fa-envelope"></i> <span>Newsletter</span>
					</a></li>
				</c:if>

				<div class="nav-divider"></div>

				<li></li>
			</ul>
		</nav>
	</aside>

	<!-- Main Content -->
	<div class="main-content">
		<!-- Top Bar -->
		<div class="top-bar">
			<h1 class="page-title">
				<i class="fas fa-tachometer-alt"></i> Dashboard
			</h1>
			<div class="top-actions">
				<a href="${pageContext.request.contextPath}/logout"
					class="btn-logout"> <i class="fas fa-sign-out-alt"></i> <span>Đăng
						xuất</span>
				</a>
			</div>
		</div>

		<!-- Content Area -->
		<div class="content-area">
			<!-- Stats Cards (Optional - chỉ hiện ở dashboard) -->
			<c:if
				test="${empty contentPage or contentPage == 'admin/dashboard.jsp'}">
				<div class="stats-grid">
					<div class="stat-card">
						<div class="stat-icon news">
							<i class="fas fa-newspaper"></i>
						</div>
						<div class="stat-info">
							<h3>150</h3>
							<p>Tổng tin tức</p>
						</div>
					</div>

					<div class="stat-card">
						<div class="stat-icon users">
							<i class="fas fa-users"></i>
						</div>
						<div class="stat-info">
							<h3>25</h3>
							<p>Người dùng</p>
						</div>
					</div>

					<div class="stat-card">
						<div class="stat-icon categories">
							<i class="fas fa-folder-open"></i>
						</div>
						<div class="stat-info">
							<h3>12</h3>
							<p>Danh mục</p>
						</div>
					</div>

					<div class="stat-card">
						<div class="stat-icon views">
							<i class="fas fa-eye"></i>
						</div>
						<div class="stat-info">
							<h3>45.2K</h3>
							<p>Lượt xem</p>
						</div>
					</div>
				</div>
			</c:if>

			<!-- Main Content Box -->
			<div class="content-box">
				<c:catch var="exception">
					<c:choose>
						<c:when test="${not empty contentPage}">
							<jsp:include page="${contentPage}" />
						</c:when>
						<c:otherwise>
							<div style="text-align: center; padding: 50px 0;">
								<i class="fas fa-chart-pie"
									style="font-size: 80px; color: #c8102e; margin-bottom: 20px;"></i>
								<h2 style="color: #2c3e50; margin-bottom: 10px;">Chào mừng
									đến với ABC News Admin</h2>
								<p style="color: #7f8c8d;">Hệ thống quản lý tin tức chuyên
									nghiệp</p>
							</div>
						</c:otherwise>
					</c:choose>
				</c:catch>

				<c:if test="${not empty exception}">
					<div class="alert alert-error">
						<i class="fas fa-exclamation-circle"></i> <span>Có lỗi xảy
							ra khi tải nội dung. Vui lòng thử lại sau.</span>
					</div>
				</c:if>
			</div>
		</div>

		<!-- Footer -->
		<footer class="admin-footer">
			<p>&copy; 2025 Chuyển Động 24 Giờ .</p>
		</footer>
	</div>

	<script>
		function toggleSidebar() {
			document.getElementById('sidebar').classList.toggle('active');
		}
		
		// Auto highlight active menu
		const currentPath = window.location.pathname;
		const menuLinks = document.querySelectorAll('.nav-menu a');
		
		menuLinks.forEach(link => {
			if (link.getAttribute('href') === currentPath) {
				menuLinks.forEach(l => l.classList.remove('active'));
				link.classList.add('active');
			}
		});
	</script>
</body>
</html>