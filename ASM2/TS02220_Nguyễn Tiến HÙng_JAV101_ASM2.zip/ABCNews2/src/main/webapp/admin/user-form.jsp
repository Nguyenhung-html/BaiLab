<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<style> /* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Header */
.page-header {
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '👥';
    position: absolute;
    top: -30px;
    right: 20px;
    font-size: 140px;
    opacity: 0.08;
    transform: rotate(-10deg);
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
    z-index: 1;
}

/* Alert Messages */
.alert {
    padding: 16px 22px;
    border-radius: 10px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideDown 0.4s ease;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
}

.alert-success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
    border-left: 5px solid #28a745;
}

.alert-success::before {
    content: '✓';
    background: #28a745;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
}

.alert-danger {
    background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
    color: #721c24;
    border-left: 5px solid #dc3545;
}

.alert-danger::before {
    content: '✕';
    background: #dc3545;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Form Container */
.form-container {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
    max-width: 1100px;
    margin: 0 auto;
    border: 1px solid #e8e8e8;
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Form Row */
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
    margin-bottom: 25px;
}

/* Form Group */
.form-group {
    display: flex;
    flex-direction: column;
    position: relative;
}

.form-label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 10px;
    letter-spacing: 0.3px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.form-label::before {
    content: '';
    width: 4px;
    height: 16px;
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    border-radius: 2px;
}

/* Form Control */
.form-control {
    width: 100%;
    padding: 14px 18px;
    font-size: 14px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    transition: all 0.3s ease;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fafafa;
    color: #333;
}

.form-control:hover {
    border-color: #c0c0c0;
    background-color: white;
}

.form-control:focus {
    outline: none;
    border-color: #ff8c42;
    background-color: white;
    box-shadow: 0 0 0 4px rgba(255, 140, 66, 0.12);
    transform: translateY(-1px);
}

.form-control::placeholder {
    color: #999;
    font-style: italic;
}

/* Readonly Input */
.form-control[readonly] {
    background-color: #f0f0f0 !important;
    color: #666;
    cursor: not-allowed;
    border-color: #d0d0d0;
}

/* Form Text (Helper) */
.form-text {
    font-size: 12px;
    color: #7f8c8d;
    margin-top: 6px;
    font-style: italic;
    display: flex;
    align-items: center;
    gap: 5px;
}

.form-text::before {
    content: 'ℹ️';
    font-size: 14px;
}

/* Radio Group */
.radio-group {
    display: flex;
    gap: 25px;
    padding: 14px 18px;
    background-color: #f8f9fa;
    border-radius: 8px;
    border: 2px solid #e0e0e0;
    transition: all 0.3s ease;
}

.radio-group:hover {
    border-color: #ff8c42;
    background-color: #fff8f5;
}

.radio-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    color: #2c3e50;
    transition: all 0.2s ease;
    user-select: none;
    padding: 5px 10px;
    border-radius: 6px;
}

.radio-label:hover {
    background-color: rgba(255, 140, 66, 0.1);
    color: #ff6b35;
}

.radio-label input[type="radio"] {
    margin-right: 8px;
    cursor: pointer;
    width: 18px;
    height: 18px;
    accent-color: #ff8c42;
}

.radio-label input[type="radio"]:checked + span {
    color: #ff6b35;
    font-weight: 600;
}

/* Form Actions */
.form-actions {
    display: flex;
    gap: 15px;
    margin-top: 35px;
    padding-top: 30px;
    border-top: 2px solid #f0f0f0;
}

/* Buttons */
.btn {
    padding: 14px 32px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
    min-width: 150px;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.5s, height 0.5s;
}

.btn:hover::before {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    box-shadow: 0 4px 15px rgba(255, 107, 53, 0.3);
    position: relative;
    z-index: 1;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
    transform: translateY(-2px);
}

.btn-primary:active {
    transform: translateY(0);
    box-shadow: 0 2px 10px rgba(255, 107, 53, 0.3);
}

.btn-secondary {
    background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%);
    color: white;
    box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
    position: relative;
    z-index: 1;
}

.btn-secondary:hover {
    background: linear-gradient(135deg, #5a6268 0%, #495057 100%);
    box-shadow: 0 6px 20px rgba(108, 117, 125, 0.4);
    transform: translateY(-2px);
}

/* Input Type Specific Styles */
input[type="date"].form-control {
    cursor: pointer;
}

input[type="date"].form-control::-webkit-calendar-picker-indicator {
    cursor: pointer;
    filter: opacity(0.6);
}

input[type="date"].form-control:hover::-webkit-calendar-picker-indicator {
    filter: opacity(1);
}

input[type="password"].form-control {
    letter-spacing: 2px;
}

input[type="email"].form-control {
    font-family: 'Courier New', monospace;
}

input[type="tel"].form-control {
    font-family: 'Courier New', monospace;
}

/* Validation States */
.form-control:invalid:not(:placeholder-shown):not(:focus) {
    border-color: #e74c3c;
    background-color: #fff5f5;
}

.form-control:valid:not(:placeholder-shown):not([readonly]) {
    border-color: #28a745;
}

/* Required Field Indicator */
.form-label:has(+ .form-control[required])::after {
    content: '*';
    color: #e74c3c;
    margin-left: 5px;
    font-weight: bold;
}

/* Focus Within Effect */
.form-group:focus-within .form-label {
    color: #ff6b35;
}

.form-group:focus-within .form-label::before {
    height: 20px;
    box-shadow: 0 0 8px rgba(255, 140, 66, 0.4);
}

/* Loading State */
.btn-primary:disabled {
    background: #ccc;
    cursor: not-allowed;
    box-shadow: none;
}

.btn-primary:disabled:hover {
    transform: none;
}

/* Responsive */
@media (max-width: 768px) {
    .form-container {
        padding: 25px 20px;
    }

    .page-header {
        padding: 20px;
    }

    .page-title {
        font-size: 22px;
    }

    .form-row {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .form-actions {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        min-width: auto;
    }

    .radio-group {
        flex-direction: column;
        gap: 12px;
    }

    .radio-label {
        padding: 10px 15px;
        background-color: white;
        border: 1px solid #e0e0e0;
        border-radius: 6px;
    }

    .radio-label:hover {
        border-color: #ff8c42;
    }
}

/* Animation for form appearance */
.form-group {
    animation: slideUp 0.3s ease;
    animation-fill-mode: both;
}

.form-group:nth-child(1) { animation-delay: 0.05s; }
.form-group:nth-child(2) { animation-delay: 0.1s; }
.form-group:nth-child(3) { animation-delay: 0.15s; }
.form-group:nth-child(4) { animation-delay: 0.2s; }

@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Smooth Transitions */
* {
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}

/* Card Effect on Form */
.form-container {
    transition: all 0.3s ease;
}

.form-container:hover {
    box-shadow: 0 4px 25px rgba(0, 0, 0, 0.12);
}

/* Custom Radio Button Style Enhancement */
.radio-label input[type="radio"] {
    position: relative;
    appearance: none;
    width: 20px;
    height: 20px;
    border: 2px solid #d0d0d0;
    border-radius: 50%;
    transition: all 0.3s ease;
    background-color: white;
}

.radio-label input[type="radio"]:hover {
    border-color: #ff8c42;
}

.radio-label input[type="radio"]:checked {
    border-color: #ff6b35;
    background-color: #ff6b35;
    box-shadow: 0 0 0 3px rgba(255, 107, 53, 0.2);
}

.radio-label input[type="radio"]:checked::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 8px;
    height: 8px;
    background-color: white;
    border-radius: 50%;
}

/* Password Field Toggle Icon (Optional Enhancement) */
.form-group:has(input[type="password"]) {
    position: relative;
}

/* Date Input Enhancement */
input[type="date"].form-control {
    position: relative;
    padding-right: 45px;
}

/* Tooltip for Required Fields */
.form-label[required]::after {
    content: '(Bắt buộc)';
    font-size: 11px;
    color: #e74c3c;
    font-weight: normal;
    margin-left: 8px;
    font-style: italic;
}</style>
<div class="page-header">
	<h1 class="page-title">
		<c:choose>
			<c:when test="${empty editUser}">➕ Thêm người dùng mới</c:when>
			<c:otherwise>✏️ Sửa người dùng</c:otherwise>
		</c:choose>
	</h1>
</div>

<!-- Hiển thị thông báo -->
<c:if test="${not empty sessionScope.message}">
	<div class="alert alert-success">${sessionScope.message}</div>
	<c:remove var="message" scope="session" />
</c:if>

<c:if test="${not empty sessionScope.error}">
	<div class="alert alert-danger">${sessionScope.error}</div>
	<c:remove var="error" scope="session" />
</c:if>

<form action="${pageContext.request.contextPath}/admin/users"
	method="post">
	<input type="hidden" name="action" value="save">

	<!-- Hidden field để biết là update hay insert -->
	<c:if test="${not empty editUser}">
		<input type="hidden" name="oldId" value="${editUser.id}">
	</c:if>

	<div class="form-container">
		<div class="form-row">
			<div class="form-group">
				<label class="form-label">ID người dùng *</label> <input type="text"
					name="id" class="form-control" value="${editUser.id}"
					${not empty editUser ? 'readonly' : 'required'}
					placeholder="Nhập ID (VD: user001)"> <small
					class="form-text">ID không thể thay đổi sau khi tạo</small>
			</div>

			<div class="form-group">
				<label class="form-label">Mật khẩu *</label> <input type="password"
					name="password" class="form-control" value="${editUser.password}"
					${empty editUser ? 'required' : ''} placeholder="Nhập mật khẩu">
				<c:if test="${not empty editUser}">
					<small class="form-text">Để trống nếu không muốn đổi mật
						khẩu</small>
				</c:if>
			</div>
		</div>

		<div class="form-row">
			<div class="form-group">
				<label class="form-label">Họ và tên *</label> <input type="text"
					name="fullname" class="form-control" value="${editUser.fullname}"
					required placeholder="Nhập họ tên đầy đủ">
			</div>

			<div class="form-group">
				<label class="form-label">Email</label> <input type="email"
					name="email" class="form-control" value="${editUser.email}"
					placeholder="example@gmail.com">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group">
				<label class="form-label">Số điện thoại</label> <input type="tel"
					name="mobile" class="form-control" value="${editUser.mobile}"
					placeholder="0123456789">
			</div>

			<div class="form-group">
				<label class="form-label">Ngày sinh</label> <input type="date"
					name="birthday" class="form-control"
					value="<fmt:formatDate value='${editUser.birthday}' pattern='yyyy-MM-dd'/>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group">
				<label class="form-label">Giới tính</label>
				<div class="radio-group">
					<label class="radio-label"> <input type="radio"
						name="gender" value="true"
						<c:choose>
                   <c:when test="${not empty editUser and editUser.gender}">checked</c:when>
                   <c:when test="${empty editUser}">checked</c:when>
               </c:choose>>
						<span>Nam</span>
					</label> <label class="radio-label"> <input type="radio"
						name="gender" value="false"
						<c:if test="${not empty editUser and not editUser.gender}">checked</c:if>>
						<span>Nữ</span>
					</label>
				</div>

			</div>

			<div class="form-group">
				<label class="form-label">Vai trò</label>
				<div class="radio-group">
					<label class="radio-label"> <input type="radio" name="role"
						value="1"
						<c:if test="${not empty editUser and editUser.role == 1}">checked</c:if>>
						<span>Quản trị</span>
					</label> <label class="radio-label"> <input type="radio"
						name="role" value="0"
						<c:choose>
                       <c:when test="${not empty editUser and editUser.role == 0}">checked</c:when>
                       <c:when test="${empty editUser}">checked</c:when>
                   </c:choose>>
						<span>Phóng viên</span>
					</label> <label class="radio-label"> <input type="radio"
						name="role" value="2"
						<c:if test="${not empty editUser and editUser.role == 2}">checked</c:if>>
						<span>Người đọc</span>
					</label>
				</div>
			</div>

		</div>

		<div class="form-actions">
			<button type="submit" class="btn btn-primary">💾 Lưu</button>
			<a href="${pageContext.request.contextPath}/admin/users"
				class="btn btn-secondary">← Quay lại</a>
		</div>
	</div>
</form>

<style>
.page-header {
	margin-bottom: 20px;
}

.page-title {
	font-size: 24px;
	color: #333;
	margin: 0;
}

.form-container {
	background: white;
	padding: 30px;
	border-radius: 8px;
	box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.form-row {
	display: grid;
	grid-template-columns: 1fr 1fr;
	gap: 20px;
	margin-bottom: 20px;
}

.form-group {
	display: flex;
	flex-direction: column;
}

.form-label {
	font-weight: 600;
	color: #333;
	margin-bottom: 8px;
	font-size: 14px;
}

.form-control {
	padding: 10px 12px;
	border: 1px solid #ced4da;
	border-radius: 4px;
	font-size: 14px;
	transition: border-color 0.15s;
}

.form-control:focus {
	outline: none;
	border-color: #007bff;
	box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
}

.form-control[readonly] {
	background-color: #e9ecef;
	cursor: not-allowed;
}

.form-text {
	font-size: 12px;
	color: #6c757d;
	margin-top: 4px;
}

.radio-group {
	display: flex;
	gap: 20px;
	padding-top: 8px;
}

.radio-label {
	display: flex;
	align-items: center;
	cursor: pointer;
	font-size: 14px;
}

.radio-label input[type="radio"] {
	margin-right: 6px;
	cursor: pointer;
}

.form-actions {
	margin-top: 30px;
	display: flex;
	gap: 10px;
}

.btn {
	padding: 10px 20px;
	border: none;
	border-radius: 4px;
	cursor: pointer;
	text-decoration: none;
	display: inline-block;
	font-size: 14px;
	font-weight: 500;
	transition: all 0.2s;
}

.btn-primary {
	background: #007bff;
	color: white;
}

.btn-primary:hover {
	background: #0056b3;
}

.btn-secondary {
	background: #6c757d;
	color: white;
}

.btn-secondary:hover {
	background: #545b62;
}

.alert {
	padding: 12px 20px;
	margin-bottom: 20px;
	border-radius: 4px;
}

.alert-success {
	background: #d4edda;
	color: #155724;
	border: 1px solid #c3e6cb;
}

.alert-danger {
	background: #f8d7da;
	color: #721c24;
	border: 1px solid #f5c6cb;
}

@media ( max-width : 768px) {
	.form-row {
		grid-template-columns: 1fr;
	}
}
</style>