<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Header */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
    z-index: 1;
}

/* Buttons */
.btn {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
    transform: translate(-50%, -50%);
    transition: width 0.5s, height 0.5s;
}

.btn:hover::before {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    box-shadow: 0 3px 10px rgba(255, 107, 53, 0.3);
    position: relative;
    z-index: 1;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
    transform: translateY(-2px);
}

.btn-sm {
    padding: 8px 16px;
    font-size: 13px;
}

.btn-edit {
    background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
}

.btn-edit:hover {
    background: linear-gradient(135deg, #357abd 0%, #2868a8 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(74, 144, 226, 0.4);
}

.btn-delete {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c0392b 0%, #a93226 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(231, 76, 60, 0.4);
}

/* Alert Messages */
.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideDown 0.4s ease;
}

.alert-success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
    border-left: 4px solid #28a745;
    box-shadow: 0 2px 10px rgba(40, 167, 69, 0.2);
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Data Table */
.data-table {
    width: 100%;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
    border-collapse: separate;
    border-spacing: 0;
}

.data-table thead {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    position: relative;
}

.data-table thead::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
}

.data-table thead tr th {
    padding: 18px 20px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    white-space: nowrap;
}

.data-table tbody tr {
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
}

.data-table tbody tr:hover {
    background: linear-gradient(135deg, #fff8f5 0%, #ffe8e0 100%);
    transform: scale(1.005);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.data-table tbody tr:last-child {
    border-bottom: none;
}

.data-table tbody tr td {
    padding: 16px 20px;
    font-size: 14px;
    color: #333;
    vertical-align: middle;
}

.data-table tbody tr td:first-child {
    font-weight: 700;
    color: #c41e3a;
    font-family: 'Courier New', monospace;
}

.data-table tbody tr td:nth-child(2) {
    font-weight: 500;
    max-width: 300px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.data-table tbody tr td:nth-child(5) {
    font-weight: 600;
    color: #ff8c42;
}

/* Badge */
.badge {
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.badge-home {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(40, 167, 69, 0.3);
    animation: pulse 2s infinite;
}

.badge-home::before {
    content: '⭐';
    font-size: 12px;
}

@keyframes pulse {
    0%, 100% {
        box-shadow: 0 2px 8px rgba(40, 167, 69, 0.3);
    }
    50% {
        box-shadow: 0 2px 15px rgba(40, 167, 69, 0.5);
    }
}

/* Actions */
.actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

/* Form Elements */
.form-group {
    margin-bottom: 20px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    font-size: 14px;
}

.form-control {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s ease;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fafafa;
}

.form-control:focus {
    outline: none;
    border-color: #ff8c42;
    background-color: white;
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.1);
}

textarea.form-control {
    resize: vertical;
    min-height: 120px;
    line-height: 1.6;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    padding: 10px;
    border-radius: 6px;
    transition: background 0.2s;
}

.checkbox-label:hover {
    background: #f8f9fa;
}

.checkbox-label input[type="checkbox"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
    accent-color: #ff8c42;
}

/* Empty State */
.data-table tbody tr td[colspan] {
    text-align: center;
    padding: 60px 20px;
    color: #999;
    font-style: italic;
    font-size: 15px;
}

.data-table tbody tr td[colspan]::before {
    content: '📭';
    display: block;
    font-size: 48px;
    margin-bottom: 15px;
    opacity: 0.5;
}

/* Responsive */
@media (max-width: 1024px) {
    .data-table {
        font-size: 13px;
    }
    
    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 12px 15px;
    }
}

@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
        padding: 20px;
    }

    .page-title {
        font-size: 22px;
    }

    .data-table {
        display: block;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 10px;
        font-size: 12px;
    }

    .actions {
        flex-direction: column;
        gap: 8px;
    }

    .btn-sm {
        width: 100%;
        justify-content: center;
    }
}

/* Scrollbar Styling */
.data-table::-webkit-scrollbar {
    height: 8px;
}

.data-table::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.data-table::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    border-radius: 10px;
}

.data-table::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
}

/* Loading State */
.loading {
    text-align: center;
    padding: 40px;
    color: #999;
}

.loading::after {
    content: '...';
    animation: dots 1.5s steps(4, end) infinite;
}

@keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
}
</style>

<div class="page-header">
	<h1 class="page-title">📰 Quản lý Tin tức</h1>
	<a href="${pageContext.request.contextPath}/admin/news?action=add"
		class="btn btn-primary"> ➕ Thêm tin mới </a>
</div>

<c:if test="${not empty message}">
	<div class="alert alert-success">✓ ${message}</div>
</c:if>

<table class="data-table">
	<thead>
		<tr>
			<th>Mã tin</th>
			<th>Tiêu đề</th>
			<th>Loại tin</th>
			<th>Tác giả</th>
			<th>Lượt xem</th>
			<th>Trang nhất</th>
			<th>Thao tác</th>
		</tr>
	</thead>
	<tbody>
		<c:forEach var="news" items="${newsList}">
			<tr>
				<td>${news.id}</td>
				<td>${news.title}</td>
				<td>${news.categoryName}</td>
				<td>${news.authorName}</td>
				<td>${news.viewCount}</td>
				<td><c:if test="${news.home}">
						<span class="badge badge-home">Trang nhất</span>
					</c:if></td>
				<td>
					<div class="actions">
						<a
							href="${pageContext.request.contextPath}/admin/news?action=edit&id=${news.id}"
							class="btn btn-sm btn-edit">✏️ Sửa</a> <a
							href="${pageContext.request.contextPath}/admin/news?action=delete&id=${news.id}"
							class="btn btn-sm btn-delete"
							onclick="return confirm('Bạn có chắc muốn xóa tin này?')">🗑️
							Xóa</a>
					</div>
				</td>
			</tr>
		</c:forEach>
	</tbody>
</table>