<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<style> 
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
}

/* Page Header */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Buttons */
.btn {
    padding: 12px 24px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.btn-primary {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    box-shadow: 0 3px 10px rgba(255, 107, 53, 0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
    transform: translateY(-2px);
}

.btn-sm {
    padding: 8px 16px;
    font-size: 13px;
}

.btn-edit {
    background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
}

.btn-edit:hover {
    background: linear-gradient(135deg, #357abd 0%, #2868a8 100%);
    transform: translateY(-1px);
}

.btn-delete {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c0392b 0%, #a93226 100%);
    transform: translateY(-1px);
}

/* Alert Messages */
.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideDown 0.3s ease;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border-left: 4px solid #28a745;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Data Table */
.data-table {
    width: 100%;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
}

.data-table thead {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
}

.data-table thead tr th {
    padding: 18px 20px;
    text-align: left;
    font-size: 14px;
    font-weight: 600;
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.data-table tbody tr {
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.2s ease;
}

.data-table tbody tr:hover {
    background-color: #fff8f5;
    transform: scale(1.01);
}

.data-table tbody tr:last-child {
    border-bottom: none;
}

.data-table tbody tr td {
    padding: 16px 20px;
    font-size: 14px;
    color: #333;
}

.data-table tbody tr td:first-child {
    font-weight: 600;
    color: #c41e3a;
}

/* Actions */
.actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

/* Responsive */
@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }

    .page-title {
        font-size: 22px;
    }

    .data-table {
        font-size: 13px;
    }

    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 12px 10px;
    }

    .actions {
        flex-direction: column;
        gap: 8px;
    }

    .btn-sm {
        width: 100%;
        justify-content: center;
    }
}

/* Empty State */
.data-table tbody tr td[colspan] {
    text-align: center;
    padding: 40px 20px;
    color: #999;
    font-style: italic;
}

/* Loading State */
.loading {
    text-align: center;
    padding: 40px;
    color: #999;
}

.loading::after {
    content: '...';
    animation: dots 1.5s steps(4, end) infinite;
}

@keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
}</style>
<div class="page-header">
    <h1 class="page-title">📂 Quản lý Loại tin</h1>
    <a href="${pageContext.request.contextPath}/admin/categories?action=add" class="btn btn-primary">
        ➕ Thêm loại tin
    </a>
</div>

<c:if test="${not empty message}">
    <div class="alert alert-success">✓ ${message}</div>
</c:if>

<table class="data-table">
    <thead>
        <tr>
            <th>Mã loại tin</th>
            <th>Tên loại tin</th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach var="cat" items="${categories}">
            <tr>
                <td>${cat.id}</td>
                <td>${cat.name}</td>
                <td>
                    <div class="actions">
                        <a href="${pageContext.request.contextPath}/admin/categories?action=edit&id=${cat.id}" 
                           class="btn btn-sm btn-edit">✏️ Sửa</a>
                        <a href="${pageContext.request.contextPath}/admin/categories?action=delete&id=${cat.id}" 
                           class="btn btn-sm btn-delete"
                           onclick="return confirm('Bạn có chắc muốn xóa?')">🗑️ Xóa</a>
                    </div>
                </td>
            </tr>
        </c:forEach>
    </tbody>
</table>