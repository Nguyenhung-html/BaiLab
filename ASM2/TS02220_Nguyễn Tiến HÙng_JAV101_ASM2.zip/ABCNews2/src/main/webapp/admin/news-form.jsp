<!-- admin/news-form.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Header */
.page-header {
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 250px;
    height: 250px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 50%;
}

.page-header::after {
    content: '';
    position: absolute;
    bottom: -30%;
    left: -5%;
    width: 180px;
    height: 180px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 50%;
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
    z-index: 1;
}

/* Alert Messages */
.alert {
    padding: 16px 22px;
    border-radius: 10px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideDown 0.4s ease;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
}

.alert::before {
    font-size: 20px;
}

.alert-success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
    border-left: 5px solid #28a745;
}

.alert-success::before {
    content: '✓';
    background: #28a745;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.alert-danger {
    background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
    color: #721c24;
    border-left: 5px solid #dc3545;
}

.alert-danger::before {
    content: '✕';
    background: #dc3545;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Form Container */
form {
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
    max-width: 900px;
    margin: 0 auto;
    border: 1px solid #e8e8e8;
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Form Group */
.form-group {
    margin-bottom: 28px;
    position: relative;
}

.form-label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 10px;
    letter-spacing: 0.3px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.form-label::before {
    content: '';
    width: 4px;
    height: 16px;
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    border-radius: 2px;
}

/* Form Controls */
.form-control {
    width: 100%;
    padding: 14px 18px;
    font-size: 14px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    transition: all 0.3s ease;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fafafa;
    color: #333;
}

.form-control:hover {
    border-color: #c0c0c0;
    background-color: white;
}

.form-control:focus {
    outline: none;
    border-color: #ff8c42;
    background-color: white;
    box-shadow: 0 0 0 4px rgba(255, 140, 66, 0.12);
    transform: translateY(-1px);
}

.form-control::placeholder {
    color: #999;
    font-style: italic;
}

/* Readonly Input */
.form-control[readonly] {
    background-color: #f5f5f5 !important;
    color: #666;
    cursor: not-allowed;
    border-color: #d0d0d0;
}

/* Textarea */
textarea.form-control {
    resize: vertical;
    min-height: 150px;
    line-height: 1.7;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Select Dropdown */
select.form-control {
    cursor: pointer;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23ff8c42' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 15px center;
    background-size: 12px;
    padding-right: 40px;
    appearance: none;
}

select.form-control:focus {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23ff6b35' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
}

select.form-control option {
    padding: 10px;
}

/* File Input */
input[type="file"].form-control {
    padding: 10px 18px;
    cursor: pointer;
    border-style: dashed;
    background-color: #f8f9fa;
}

input[type="file"].form-control:hover {
    border-color: #ff8c42;
    background-color: #fff8f5;
}

input[type="file"].form-control::file-selector-button {
    padding: 8px 16px;
    margin-right: 15px;
    border: none;
    border-radius: 6px;
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
}

input[type="file"].form-control::file-selector-button:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    transform: translateY(-1px);
}

/* Image Preview */
.form-group img {
    max-width: 100%;
    height: auto;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    padding: 8px;
    margin-top: 12px;
    transition: all 0.3s ease;
    background: white;
}

.form-group img:hover {
    border-color: #ff8c42;
    box-shadow: 0 4px 15px rgba(255, 140, 66, 0.2);
    transform: scale(1.02);
}

.form-group p[style*="color: #666"] {
    color: #666 !important;
    font-size: 13px;
    margin-top: 8px;
    font-style: italic;
}

/* Checkbox */
.checkbox-label {
    display: flex;
    align-items: center;
    gap: 12px;
    cursor: pointer;
    padding: 14px 18px;
    border-radius: 8px;
    transition: all 0.3s ease;
    background-color: #f8f9fa;
    border: 2px solid #e0e0e0;
}

.checkbox-label:hover {
    background-color: #fff8f5;
    border-color: #ff8c42;
}

.checkbox-label input[type="checkbox"] {
    width: 22px;
    height: 22px;
    cursor: pointer;
    accent-color: #ff8c42;
    border-radius: 4px;
}

.checkbox-label span {
    font-size: 14px;
    font-weight: 500;
    color: #2c3e50;
    user-select: none;
}

.checkbox-label input[type="checkbox"]:checked + span {
    color: #ff6b35;
}

/* Buttons */
.actions {
    display: flex;
    gap: 15px;
    margin-top: 35px;
    padding-top: 30px;
    border-top: 2px solid #f0f0f0;
}

.btn {
    padding: 14px 32px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
    min-width: 150px;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.5s, height 0.5s;
}

.btn:hover::before {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    box-shadow: 0 4px 15px rgba(255, 107, 53, 0.3);
    position: relative;
    z-index: 1;
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
    transform: translateY(-2px);
}

.btn-primary:active {
    transform: translateY(0);
    box-shadow: 0 2px 10px rgba(255, 107, 53, 0.3);
}

.btn[style*="background: #6c757d"] {
    background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%) !important;
    box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
    position: relative;
    z-index: 1;
}

.btn[style*="background: #6c757d"]:hover {
    background: linear-gradient(135deg, #5a6268 0%, #495057 100%) !important;
    box-shadow: 0 6px 20px rgba(108, 117, 125, 0.4);
    transform: translateY(-2px);
}

/* Required Field Indicator */
.form-label:has(+ .form-control[required])::after,
.form-label:has(+ select[required])::after,
.form-label:has(+ textarea[required])::after {
    content: '*';
    color: #e74c3c;
    margin-left: 5px;
    font-weight: bold;
}

/* Validation States */
.form-control:invalid:not(:placeholder-shown):not(:focus) {
    border-color: #e74c3c;
    background-color: #fff5f5;
}

.form-control:valid:not(:placeholder-shown):not([readonly]) {
    border-color: #28a745;
}

/* Loading State */
.btn-primary:disabled {
    background: #ccc;
    cursor: not-allowed;
    box-shadow: none;
}

.btn-primary:disabled:hover {
    transform: none;
}

/* Responsive */
@media (max-width: 768px) {
    form {
        padding: 25px 20px;
    }

    .page-header {
        padding: 20px;
    }

    .page-title {
        font-size: 22px;
    }

    .actions {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        min-width: auto;
    }

    .form-control {
        padding: 12px 16px;
        font-size: 14px;
    }

    .form-group img {
        max-width: 100%;
    }
}

/* Smooth Transitions */
* {
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}

/* Focus Within Effect */
.form-group:focus-within .form-label {
    color: #ff6b35;
}

.form-group:focus-within .form-label::before {
    height: 20px;
    box-shadow: 0 0 8px rgba(255, 140, 66, 0.4);
}</style>
<div class="page-header">
	<h1 class="page-title">
		<c:choose>
			<c:when test="${empty news}">➕ Thêm tin mới</c:when>
			<c:otherwise>✏️ Sửa tin</c:otherwise>
		</c:choose>
	</h1>
</div>

<!-- Hiển thị thông báo -->
<c:if test="${not empty sessionScope.message}">
	<div class="alert alert-success">${sessionScope.message}</div>
	<c:remove var="message" scope="session"/>
</c:if>

<c:if test="${not empty sessionScope.error}">
	<div class="alert alert-danger">${sessionScope.error}</div>
	<c:remove var="error" scope="session"/>
</c:if>

<form action="${pageContext.request.contextPath}/admin/news"
	method="post" enctype="multipart/form-data">
	<input type="hidden" name="action" value="save">
	
	<!-- CHỈ GỬI ID KHI EDIT (hidden) -->
	<c:if test="${not empty news}">
		<input type="hidden" name="id" value="${news.id}">
		
		<!-- Hiển thị ID cho user xem (readonly, không gửi lên server) -->
		<div class="form-group">
			<label class="form-label">Mã tin</label>
			<input type="text" class="form-control" value="${news.id}" 
				readonly style="background-color: #f5f5f5;">
		</div>
	</c:if>

	<div class="form-group">
		<label class="form-label">Tiêu đề *</label> 
		<input type="text" name="title" class="form-control" 
			value="${news.title}" required>
	</div>

	<div class="form-group">
		<label class="form-label">Nội dung *</label>
		<textarea name="content" class="form-control" rows="8" required>${news.content}</textarea>
	</div>

	<div class="form-group">
		<label class="form-label">Loại tin *</label> 
		<select name="categoryId" class="form-control" required>
			<option value="">-- Chọn loại tin --</option>
			<c:forEach var="cat" items="${categories}">
				<option value="${cat.id}"
					${news.categoryId == cat.id ? 'selected' : ''}>
					${cat.name}
				</option>
			</c:forEach>
		</select>
	</div>

	<div class="form-group">
		<label class="form-label">Hình ảnh</label> 
		<input type="file" name="image" class="form-control" accept="image/*">
		<c:if test="${not empty news.image}">
			<div style="margin-top: 10px;">
				<p style="color: #666;">Hình hiện tại: ${news.image}</p>
				<img src="${pageContext.request.contextPath}/Images/${news.image}" 
					alt="Preview" style="max-width: 300px; border: 1px solid #ddd; padding: 5px; margin-top: 5px;">
			</div>
		</c:if>
	</div>

	<div class="form-group">
		<label class="checkbox-label"> 
			<input type="checkbox" name="home" value="true" 
				${news.home ? 'checked' : ''}> 
			<span>Hiển thị trên trang nhất</span>
		</label>
	</div>

	<div class="actions" style="margin-top: 30px;">
		<button type="submit" class="btn btn-primary">💾 Lưu</button>
		<a href="${pageContext.request.contextPath}/admin/news" class="btn"
			style="background: #6c757d; color: white;">
			← Quay lại
		</a>
	</div>
</form>