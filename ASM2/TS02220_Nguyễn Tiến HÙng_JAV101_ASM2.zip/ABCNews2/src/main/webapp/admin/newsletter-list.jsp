<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<style> 
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Header */
.page-header {
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '✉';
    position: absolute;
    top: -20px;
    right: 30px;
    font-size: 120px;
    opacity: 0.1;
    transform: rotate(-15deg);
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
    z-index: 1;
}

/* Alert Messages */
.alert {
    padding: 16px 22px;
    border-radius: 10px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideDown 0.4s ease;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
}

.alert-success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
    border-left: 5px solid #28a745;
}

.alert-success::before {
    content: '✓';
    background: #28a745;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Data Table */
.data-table {
    width: 100%;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
    border-collapse: separate;
    border-spacing: 0;
}

.data-table thead {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    position: relative;
}

.data-table thead::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
}

.data-table thead tr th {
    padding: 18px 20px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    white-space: nowrap;
}

.data-table tbody tr {
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
}

.data-table tbody tr:hover {
    background: linear-gradient(135deg, #fff8f5 0%, #ffe8e0 100%);
    transform: scale(1.005);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.data-table tbody tr:last-child {
    border-bottom: none;
}

.data-table tbody tr td {
    padding: 16px 20px;
    font-size: 14px;
    color: #333;
    vertical-align: middle;
}

/* Email Column */
.data-table tbody tr td:first-child {
    font-weight: 600;
    color: #2c3e50;
    font-family: 'Courier New', monospace;
    font-size: 15px;
}

.data-table tbody tr td:first-child::before {
    content: '📧 ';
    margin-right: 5px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Badge Status */
.badge {
    padding: 7px 16px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

.badge[style*="background: #28a745"] {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
    box-shadow: 0 3px 10px rgba(40, 167, 69, 0.3) !important;
}

.badge[style*="background: #dc3545"] {
    background: linear-gradient(135deg, #dc3545 0%, #c0392b 100%) !important;
    box-shadow: 0 3px 10px rgba(220, 53, 69, 0.3) !important;
}

/* Actions */
.actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

/* Buttons */
.btn {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.5s, height 0.5s;
}

.btn:hover::before {
    width: 300px;
    height: 300px;
}

.btn-sm {
    padding: 8px 16px;
    font-size: 13px;
}

.btn[style*="background: #ffc107"] {
    background: linear-gradient(135deg, #ffc107 0%, #ffb300 100%) !important;
    color: white !important;
    box-shadow: 0 2px 8px rgba(255, 193, 7, 0.3);
    position: relative;
    z-index: 1;
}

.btn[style*="background: #ffc107"]:hover {
    background: linear-gradient(135deg, #ffb300 0%, #ffa000 100%) !important;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(255, 193, 7, 0.4);
}

.btn-delete {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
    position: relative;
    z-index: 1;
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c0392b 0%, #a93226 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(231, 76, 60, 0.4);
}

/* Empty State */
.data-table tbody tr td[colspan] {
    text-align: center;
    padding: 60px 20px;
    color: #999;
    font-style: italic;
    font-size: 15px;
}

.data-table tbody tr td[colspan]::before {
    content: '📭';
    display: block;
    font-size: 60px;
    margin-bottom: 15px;
    opacity: 0.5;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-10px);
    }
}

/* Statistics Card (nếu cần thêm) */
.stats-card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: center;
    gap: 15px;
}

.stats-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
}

.stats-content h3 {
    font-size: 28px;
    color: #2c3e50;
    margin: 0;
}

.stats-content p {
    font-size: 14px;
    color: #7f8c8d;
    margin: 0;
}

/* Responsive */
@media (max-width: 1024px) {
    .data-table {
        font-size: 13px;
    }
    
    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 12px 15px;
    }
}

@media (max-width: 768px) {
    .page-header {
        padding: 20px;
    }

    .page-title {
        font-size: 22px;
    }

    .data-table {
        display: block;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 10px;
        font-size: 12px;
    }

    .actions {
        flex-direction: column;
        gap: 8px;
    }

    .btn-sm {
        width: 100%;
        justify-content: center;
    }

    .badge {
        font-size: 11px;
        padding: 5px 12px;
    }
}

/* Scrollbar Styling */
.data-table::-webkit-scrollbar {
    height: 8px;
}

.data-table::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.data-table::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    border-radius: 10px;
}

.data-table::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
}

/* Loading State */
.loading {
    text-align: center;
    padding: 40px;
    color: #999;
}

.loading::after {
    content: '...';
    animation: dots 1.5s steps(4, end) infinite;
}

@keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
}

/* Hover Animation for Email */
.data-table tbody tr:hover td:first-child {
    color: #ff6b35;
    transform: translateX(5px);
}

/* Pulse Animation for Active Badge */
.badge[style*="background: #28a745"] {
    animation: badgePulse 2s infinite;
}

@keyframes badgePulse {
    0%, 100% {
        box-shadow: 0 3px 10px rgba(40, 167, 69, 0.3);
    }
    50% {
        box-shadow: 0 3px 20px rgba(40, 167, 69, 0.5);
    }
}</style>
<div class="page-header">
    <h1 class="page-title">✉️ Quản lý Newsletter</h1>
</div>

<c:if test="${not empty message}">
    <div class="alert alert-success">✓ ${message}</div>
</c:if>

<table class="data-table">
    <thead>
        <tr>
            <th>Email</th>
            <th>Trạng thái</th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach var="newsletter" items="${newsletters}">
            <tr>
                <td>${newsletter.email}</td>
                <td>
                    <c:choose>
                        <c:when test="${newsletter.enabled}">
                            <span class="badge" style="background: #28a745; color: white;">✓ Hoạt động</span>
                        </c:when>
                        <c:otherwise>
                            <span class="badge" style="background: #dc3545; color: white;">✗ Tạm dừng</span>
                        </c:otherwise>
                    </c:choose>
                </td>
                <td>
                    <div class="actions">
                        <a href="${pageContext.request.contextPath}/admin/newsletters?action=toggle&email=${newsletter.email}" 
                           class="btn btn-sm" style="background: #ffc107; color: white;">🔄 Đổi trạng thái</a>
                        <a href="${pageContext.request.contextPath}/admin/newsletters?action=delete&email=${newsletter.email}" 
                           class="btn btn-sm btn-delete"
                           onclick="return confirm('Xóa email này?')">🗑️ Xóa</a>
                    </div>
                </td>
            </tr>
        </c:forEach>
    </tbody>
</table>