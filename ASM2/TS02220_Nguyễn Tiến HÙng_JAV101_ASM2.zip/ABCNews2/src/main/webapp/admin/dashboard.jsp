<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Welcome Section */
.welcome-section {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    padding: 35px 40px;
    border-radius: 12px;
    margin-bottom: 35px;
    box-shadow: 0 4px 20px rgba(196, 30, 58, 0.3);
    position: relative;
    overflow: hidden;
    animation: slideDown 0.5s ease;
}

.welcome-section::before {
    content: '👋';
    position: absolute;
    top: -20px;
    right: 30px;
    font-size: 120px;
    opacity: 0.08;
    transform: rotate(-15deg);
}

.welcome-section::after {
    content: '';
    position: absolute;
    bottom: -50%;
    left: -10%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 50%;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.welcome-title {
    font-size: 32px;
    color: white;
    margin-bottom: 12px;
    font-weight: 700;
    position: relative;
    z-index: 1;
}

.welcome-text {
    color: rgba(255, 255, 255, 0.95);
    font-size: 16px;
    line-height: 1.8;
    position: relative;
    z-index: 1;
}

/* Dashboard Title */
.dashboard-title {
    font-size: 32px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 30px;
    display: flex;
    align-items: center;
    gap: 12px;
    padding-bottom: 15px;
    border-bottom: 3px solid #c41e3a;
    position: relative;
}

.dashboard-title::after {
    content: '';
    position: absolute;
    bottom: -3px;
    left: 0;
    width: 120px;
    height: 3px;
    background: linear-gradient(90deg, #ff8c42, transparent);
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
    margin-bottom: 45px;
}

/* Stat Card */
.stat-card {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    padding: 35px 30px;
    border-radius: 15px;
    color: white;
    box-shadow: 0 4px 20px rgba(196, 30, 58, 0.3);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    animation: fadeInUp 0.6s ease;
    animation-fill-mode: both;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stat-card:nth-child(1) { animation-delay: 0.1s; }
.stat-card:nth-child(2) { animation-delay: 0.2s; }
.stat-card:nth-child(3) { animation-delay: 0.3s; }
.stat-card:nth-child(4) { animation-delay: 0.4s; }

.stat-card::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -20%;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    transition: all 0.5s ease;
}

.stat-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 8px 30px rgba(196, 30, 58, 0.4);
}

.stat-card:hover::before {
    transform: scale(1.5);
}

/* Stat Card Colors - Chủ đề đỏ-cam */
.stat-card.blue {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    box-shadow: 0 4px 20px rgba(255, 107, 53, 0.3);
}

.stat-card.blue:hover {
    box-shadow: 0 8px 30px rgba(255, 107, 53, 0.4);
}

.stat-card.green {
    background: linear-gradient(135deg, #e67e22 0%, #d35400 100%);
    box-shadow: 0 4px 20px rgba(230, 126, 34, 0.3);
}

.stat-card.green:hover {
    box-shadow: 0 8px 30px rgba(230, 126, 34, 0.4);
}

.stat-card.purple {
    background: linear-gradient(135deg, #c0392b 0%, #922b21 100%);
    box-shadow: 0 4px 20px rgba(192, 57, 43, 0.3);
}

.stat-card.purple:hover {
    box-shadow: 0 8px 30px rgba(192, 57, 43, 0.4);
}

/* Stat Icon */
.stat-icon {
    font-size: 56px;
    margin-bottom: 18px;
    display: block;
    opacity: 0.95;
    filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
}

/* Stat Label */
.stat-label {
    font-size: 13px;
    opacity: 0.95;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 1.2px;
    font-weight: 600;
}

/* Stat Value */
.stat-value {
    font-size: 42px;
    font-weight: 700;
    letter-spacing: -1px;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

/* Quick Actions Title */
h2[style*="font-size: 24px"] {
    font-size: 28px !important;
    font-weight: 700 !important;
    color: #2c3e50 !important;
    margin: 40px 0 25px !important;
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
    padding-bottom: 12px !important;
    border-bottom: 2px solid #e8e8e8 !important;
}

/* Quick Actions Grid */
.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 22px;
    margin-top: 30px;
}

/* Action Button */
.action-btn {
    padding: 28px 24px;
    background: white;
    border: 2px solid #e8e8e8;
    border-radius: 12px;
    text-align: center;
    text-decoration: none;
    color: #2c3e50;
    font-weight: 600;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    position: relative;
    overflow: hidden;
}

.action-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 0;
}

.action-btn:hover::before {
    opacity: 1;
}

.action-btn:hover {
    border-color: #c41e3a;
    color: white;
    transform: translateY(-5px);
    box-shadow: 0 8px 20px rgba(196, 30, 58, 0.3);
}

.action-btn > * {
    position: relative;
    z-index: 1;
}

/* Action Icon */
.action-icon {
    font-size: 40px;
    display: block;
    transition: transform 0.3s ease;
}

.action-btn:hover .action-icon {
    transform: scale(1.15) rotate(5deg);
}

/* Responsive */
@media (max-width: 1200px) {
    .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    }
}

@media (max-width: 768px) {
    .welcome-section {
        padding: 25px 20px;
    }

    .welcome-title {
        font-size: 26px;
    }

    .welcome-text {
        font-size: 14px;
    }

    .dashboard-title {
        font-size: 26px;
    }

    .stats-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .stat-card {
        padding: 28px 24px;
    }

    .stat-icon {
        font-size: 48px;
    }

    .stat-value {
        font-size: 36px;
    }

    .quick-actions {
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 15px;
    }

    .action-btn {
        padding: 22px 18px;
    }

    .action-icon {
        font-size: 36px;
    }
}

@media (max-width: 480px) {
    .welcome-title {
        font-size: 22px;
    }

    .dashboard-title {
        font-size: 22px;
    }

    .quick-actions {
        grid-template-columns: 1fr;
    }

    .stat-value {
        font-size: 32px;
    }
}

/* Loading State for Stats */
.stat-card.loading {
    background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
    background-size: 200% 100%;
    animation: loading 1.5s infinite;
}

@keyframes loading {
    0% {
        background-position: 200% 0;
    }
    100% {
        background-position: -200% 0;
    }
}

/* Accessibility */
.action-btn:focus {
    outline: 3px solid #ff8c42;
    outline-offset: 2px;
}

.stat-card:focus-within {
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.3);
}

/* Print Styles */
@media print {
    .quick-actions,
    .action-btn {
        display: none;
    }

    .stat-card {
        break-inside: avoid;
        box-shadow: none;
        border: 1px solid #ddd;
    }
}

/* Smooth Transitions */
* {
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
</style>

<div class="welcome-section">
	<h2 class="welcome-title">👋 Xin chào,
		${sessionScope.user.fullname}!</h2>
	<p class="welcome-text">
		Chào mừng bạn đến với trang quản trị ABC News.
		<!-- ✅ LỖI 1: SỬA DÒNG 124 -->
		<c:choose>
			<c:when test="${sessionScope.user.role == 1}">
                Bạn đang đăng nhập với quyền Quản trị viên.
            </c:when>
			<c:when test="${sessionScope.user.role == 0}">
                Bạn đang đăng nhập với quyền Phóng viên.
            </c:when>
			<c:otherwise>
                Bạn đang đăng nhập với quyền Người đọc.
            </c:otherwise>
		</c:choose>
	</p>
</div>

<h1 class="dashboard-title">📊 Thống kê tổng quan</h1>

<div class="stats-grid">
	<div class="stat-card">
		<div class="stat-icon">📰</div>
		<div class="stat-label">Tổng số tin</div>
		<div class="stat-value">${totalNews}</div>
	</div>

	<!-- ✅ LỖI 2: SỬA DÒNG 142 -->
	<c:if test="${sessionScope.user.role == 1}">
		<div class="stat-card blue">
			<div class="stat-icon">👥</div>
			<div class="stat-label">Người dùng</div>
			<div class="stat-value">${totalUsers}</div>
		</div>

		<div class="stat-card green">
			<div class="stat-icon">📂</div>
			<div class="stat-label">Loại tin</div>
			<div class="stat-value">${totalCategories}</div>
		</div>

		<div class="stat-card purple">
			<div class="stat-icon">✉️</div>
			<div class="stat-label">Đăng ký Newsletter</div>
			<div class="stat-value">${totalSubscribers}</div>
		</div>
	</c:if>
</div>

<h2 style="font-size: 24px; color: #ff6b35; margin: 30px 0 20px;">⚡
	Thao tác nhanh</h2>

<div class="quick-actions">
	<a href="${pageContext.request.contextPath}/admin/news?action=add"
		class="action-btn"> <span class="action-icon">➕</span> <span>Thêm
			tin mới</span>
	</a> <a href="${pageContext.request.contextPath}/admin/news"
		class="action-btn"> <span class="action-icon">📋</span> <span>Quản
			lý tin tức</span>
	</a>

	<!-- ✅ LỖI 3: SỬA DÒNG 171 -->
	<c:if test="${sessionScope.user.role == 1}">
		<a href="${pageContext.request.contextPath}/admin/categories"
			class="action-btn"> <span class="action-icon">📂</span> <span>Quản
				lý loại tin</span>
		</a>

		<a href="${pageContext.request.contextPath}/admin/users"
			class="action-btn"> <span class="action-icon">👤</span> <span>Quản
				lý người dùng</span>
		</a>
	</c:if>

	<a href="${pageContext.request.contextPath}/" class="action-btn"> <span
		class="action-icon">🏠</span> <span>Xem trang chủ</span>
	</a>
</div>