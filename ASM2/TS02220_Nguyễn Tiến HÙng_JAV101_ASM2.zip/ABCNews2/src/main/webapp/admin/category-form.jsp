<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
}

/* Page Header */
.page-header {
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Form Container */
form {
    background: white;
    padding: 35px;
    border-radius: 10px;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
    max-width: 700px;
    margin: 0 auto;
}

/* Form Group */
.form-group {
    margin-bottom: 25px;
}

.form-label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
    letter-spacing: 0.3px;
}

.form-label::after {
    content: '';
    display: inline-block;
    width: 4px;
    height: 4px;
    background-color: #e74c3c;
    border-radius: 50%;
    margin-left: 4px;
    vertical-align: middle;
}

/* Form Control */
.form-control {
    width: 100%;
    padding: 14px 18px;
    font-size: 14px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    transition: all 0.3s ease;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #fafafa;
}

.form-control:focus {
    outline: none;
    border-color: #ff8c42;
    background-color: white;
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.1);
}

.form-control:hover {
    border-color: #c0c0c0;
    background-color: white;
}

.form-control[readonly] {
    background-color: #f0f0f0;
    color: #666;
    cursor: not-allowed;
}

.form-control::placeholder {
    color: #999;
    font-style: italic;
}

/* Input Icons */
.form-group {
    position: relative;
}

.form-control:focus ~ .input-icon {
    color: #ff8c42;
}

/* Buttons */
.actions {
    display: flex;
    gap: 15px;
    margin-top: 35px;
    padding-top: 25px;
    border-top: 2px solid #f0f0f0;
}

.btn {
    padding: 14px 30px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all 0.3s ease;
    min-width: 140px;
}

.btn-primary {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    box-shadow: 0 6px 18px rgba(255, 107, 53, 0.4);
    transform: translateY(-2px);
}

.btn-primary:active {
    transform: translateY(0);
    box-shadow: 0 2px 8px rgba(255, 107, 53, 0.3);
}

.btn[style*="background: #6c757d"] {
    background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%) !important;
    box-shadow: 0 4px 12px rgba(108, 117, 125, 0.3);
}

.btn[style*="background: #6c757d"]:hover {
    background: linear-gradient(135deg, #5a6268 0%, #495057 100%) !important;
    box-shadow: 0 6px 18px rgba(108, 117, 125, 0.4);
    transform: translateY(-2px);
}

/* Validation States */
.form-control:invalid:not(:placeholder-shown) {
    border-color: #e74c3c;
}

.form-control:valid:not(:placeholder-shown) {
    border-color: #28a745;
}

.form-control:required:not(:placeholder-shown):invalid {
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%23e74c3c' viewBox='0 0 16 16'%3E%3Cpath d='M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z'/%3E%3Cpath d='M7.002 11a1 1 0 1 1 2 0 1 1 0 0 1-2 0zM7.1 4.995a.905.905 0 1 1 1.8 0l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995z'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 14px center;
    background-size: 18px;
    padding-right: 45px;
}

/* Error Message */
.error-message {
    color: #e74c3c;
    font-size: 13px;
    margin-top: 6px;
    display: none;
}

.form-control:invalid:not(:placeholder-shown) ~ .error-message {
    display: block;
}

/* Helper Text */
.helper-text {
    font-size: 12px;
    color: #666;
    margin-top: 6px;
    font-style: italic;
}

/* Loading State */
.btn-primary:disabled {
    background: #ccc;
    cursor: not-allowed;
    box-shadow: none;
}

.btn-primary:disabled:hover {
    transform: none;
}

/* Responsive */
@media (max-width: 768px) {
    form {
        padding: 25px 20px;
    }

    .page-header {
        padding: 20px;
    }

    .page-title {
        font-size: 22px;
    }

    .actions {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        min-width: auto;
    }

    .form-control {
        padding: 12px 16px;
    }
}

/* Animation */
@keyframes slideUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

form {
    animation: slideUp 0.4s ease;
}

/* Focus Within Effect */
.form-group:focus-within .form-label {
    color: #ff8c42;
}

/* Custom Checkbox/Radio (nếu cần) */
input[type="checkbox"],
input[type="radio"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: #ff8c42;
}

/* Tooltip */
.tooltip {
    position: relative;
    display: inline-block;
    margin-left: 5px;
    color: #999;
    cursor: help;
}

.tooltip:hover::after {
    content: attr(data-tooltip);
    position: absolute;
    bottom: 125%;
    left: 50%;
    transform: translateX(-50%);
    background-color: #333;
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 12px;
    white-space: nowrap;
    z-index: 1;
}

/* Card Effect */
form {
    border: 1px solid #e0e0e0;
    transition: all 0.3s ease;
}

form:hover {
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.12);
}</style>
<div class="page-header">
    <h1 class="page-title">
        <c:choose>
            <c:when test="${empty category}">➕ Thêm loại tin</c:when>
            <c:otherwise>✏️ Sửa loại tin</c:otherwise>
        </c:choose>
    </h1>
</div>

<form action="${pageContext.request.contextPath}/admin/categories" method="post">
    <input type="hidden" name="action" value="save">
    <c:if test="${not empty category}">
        <input type="hidden" name="oldId" value="${category.id}">
    </c:if>
    
    <div class="form-group">
        <label class="form-label">Mã loại tin *</label>
        <input type="text" name="id" class="form-control" 
               value="${category.id}" 
               ${not empty category ? 'readonly' : 'required'}
               placeholder="VD: SPORT, TECH">
    </div>
    
    <div class="form-group">
        <label class="form-label">Tên loại tin *</label>
        <input type="text" name="name" class="form-control" 
               value="${category.name}" required
               placeholder="VD: Thể thao, Công nghệ">
    </div>
    
    <div class="actions">
        <button type="submit" class="btn btn-primary">💾 Lưu</button>
        <a href="${pageContext.request.contextPath}/admin/categories" 
           class="btn" style="background: #6c757d; color: white;">← Quay lại</a>
    </div>
</form>