<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Header */
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px 30px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    border-radius: 10px;
    margin-bottom: 30px;
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '👥';
    position: absolute;
    top: -30px;
    right: 20px;
    font-size: 140px;
    opacity: 0.08;
    transform: rotate(-10deg);
}

.page-header::after {
    content: '';
    position: absolute;
    bottom: -50%;
    left: -10%;
    width: 300px;
    height: 300px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 50%;
}

.page-title {
    font-size: 28px;
    font-weight: 600;
    color: #fff;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    position: relative;
    z-index: 1;
}

/* Buttons */
.btn {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    z-index: 1;
}

.btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.5s, height 0.5s;
    z-index: -1;
}

.btn:hover::before {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    box-shadow: 0 3px 10px rgba(255, 107, 53, 0.3);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
    box-shadow: 0 5px 15px rgba(255, 107, 53, 0.4);
    transform: translateY(-2px);
}

.btn-sm {
    padding: 8px 16px;
    font-size: 13px;
}

.btn-edit {
    background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(74, 144, 226, 0.3);
}

.btn-edit:hover {
    background: linear-gradient(135deg, #357abd 0%, #2868a8 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(74, 144, 226, 0.4);
}

.btn-delete {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
}

.btn-delete:hover {
    background: linear-gradient(135deg, #c0392b 0%, #a93226 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(231, 76, 60, 0.4);
}

/* Alert Messages */
.alert {
    padding: 16px 22px;
    border-radius: 10px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideDown 0.4s ease;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
}

.alert-success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
    border-left: 5px solid #28a745;
}

.alert-success::before {
    content: '✓';
    background: #28a745;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Data Table */
.data-table {
    width: 100%;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
    border-collapse: separate;
    border-spacing: 0;
}

.data-table thead {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    position: relative;
}

.data-table thead::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
}

.data-table thead tr th {
    padding: 18px 20px;
    text-align: left;
    font-size: 13px;
    font-weight: 600;
    color: white;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    white-space: nowrap;
}

.data-table tbody tr {
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
}

.data-table tbody tr:hover {
    background: linear-gradient(135deg, #fff8f5 0%, #ffe8e0 100%);
    transform: scale(1.005);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.data-table tbody tr:last-child {
    border-bottom: none;
}

.data-table tbody tr td {
    padding: 16px 20px;
    font-size: 14px;
    color: #333;
    vertical-align: middle;
}

/* ID Column */
.data-table tbody tr td:first-child {
    font-weight: 700;
    color: #c41e3a;
    font-family: 'Courier New', monospace;
    font-size: 15px;
}

.data-table tbody tr td:first-child::before {
    content: '#';
    opacity: 0.5;
    margin-right: 2px;
}

/* Fullname Column */
.data-table tbody tr td:nth-child(2) {
    font-weight: 600;
    color: #2c3e50;
}

.data-table tbody tr td:nth-child(2)::before {
    content: '👤 ';
    opacity: 0.6;
    margin-right: 5px;
}

/* Email Column */
.data-table tbody tr td:nth-child(3) {
    font-family: 'Courier New', monospace;
    color: #4a90e2;
    font-size: 13px;
}

.data-table tbody tr td:nth-child(3)::before {
    content: '📧 ';
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin-right: 5px;
}

/* Phone Column */
.data-table tbody tr td:nth-child(4) {
    font-family: 'Courier New', monospace;
    color: #28a745;
    font-weight: 500;
}

.data-table tbody tr td:nth-child(4)::before {
    content: '📱 ';
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin-right: 5px;
}

/* Gender Column */
.data-table tbody tr td:nth-child(5) {
    font-weight: 500;
}

.data-table tbody tr td:nth-child(5):has(c\:choose:contains("Nam"))::before {
    content: '♂️ ';
    color: #4a90e2;
    margin-right: 5px;
}

/* Badge Roles */
.badge {
    padding: 7px 16px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    animation: fadeIn 0.3s ease;
    white-space: nowrap;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: scale(0.9);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

/* Badge Quản trị - Đỏ */
.badge[style*="background: #dc3545"] {
    background: linear-gradient(135deg, #dc3545 0%, #c0392b 100%) !important;
    box-shadow: 0 3px 12px rgba(220, 53, 69, 0.4) !important;
    animation: badgePulse 2s infinite;
}

@keyframes badgePulse {
    0%, 100% {
        box-shadow: 0 3px 12px rgba(220, 53, 69, 0.4);
    }
    50% {
        box-shadow: 0 3px 18px rgba(220, 53, 69, 0.6);
    }
}

/* Badge Phóng viên - Xanh */
.badge[style*="background: #28a745"] {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%) !important;
    box-shadow: 0 3px 10px rgba(40, 167, 69, 0.3) !important;
}

/* Badge Người đọc - Xám */
.badge[style*="background: #6c757d"] {
    background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%) !important;
    box-shadow: 0 3px 10px rgba(108, 117, 125, 0.3) !important;
}

/* Actions */
.actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

/* Empty State */
.data-table tbody tr td[colspan] {
    text-align: center;
    padding: 60px 20px;
    color: #999;
    font-style: italic;
    font-size: 15px;
}

.data-table tbody tr td[colspan]::before {
    content: '👥';
    display: block;
    font-size: 60px;
    margin-bottom: 15px;
    opacity: 0.5;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-10px);
    }
}

/* Hover Effects */
.data-table tbody tr:hover td:nth-child(2) {
    color: #ff6b35;
}

.data-table tbody tr:hover td:nth-child(3) {
    color: #ff8c42;
}

.data-table tbody tr:hover .badge {
    transform: scale(1.05);
}

/* Statistics Cards (Optional) */
.stats-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stats-card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s ease;
}

.stats-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
}

.stats-icon {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
}

.stats-icon.admin {
    background: linear-gradient(135deg, #dc3545 0%, #c0392b 100%);
}

.stats-icon.reporter {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
}

.stats-icon.reader {
    background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%);
}

.stats-content h3 {
    font-size: 32px;
    color: #2c3e50;
    margin: 0;
    font-weight: 700;
}

.stats-content p {
    font-size: 14px;
    color: #7f8c8d;
    margin: 0;
    font-weight: 500;
}

/* Responsive */
@media (max-width: 1024px) {
    .data-table {
        font-size: 13px;
    }
    
    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 12px 15px;
    }

    .badge {
        font-size: 10px;
        padding: 5px 12px;
    }
}

@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
        padding: 20px;
    }

    .page-title {
        font-size: 22px;
    }

    .data-table {
        display: block;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .data-table thead tr th,
    .data-table tbody tr td {
        padding: 10px;
        font-size: 12px;
    }

    .actions {
        flex-direction: column;
        gap: 8px;
    }

    .btn-sm {
        width: 100%;
        justify-content: center;
    }

    .stats-container {
        grid-template-columns: 1fr;
    }
}

/* Scrollbar Styling */
.data-table::-webkit-scrollbar {
    height: 8px;
}

.data-table::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

.data-table::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    border-radius: 10px;
}

.data-table::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #ff7a2e 0%, #ff5821 100%);
}

/* Loading State */
.loading {
    text-align: center;
    padding: 40px;
    color: #999;
}

.loading::after {
    content: '...';
    animation: dots 1.5s steps(4, end) infinite;
}

@keyframes dots {
    0%, 20% { content: '.'; }
    40% { content: '..'; }
    60%, 100% { content: '...'; }
}
</style>
<div class="page-header">
	<h1 class="page-title">👥 Quản lý Người dùng</h1>
	<a href="${pageContext.request.contextPath}/admin/users?action=add"
		class="btn btn-primary"> ➕ Thêm người dùng </a>
</div>

<c:if test="${not empty message}">
	<div class="alert alert-success">✓ ${message}</div>
</c:if>

<table class="data-table">
	<thead>
		<tr>
			<th>ID</th>
			<th>Họ tên</th>
			<th>Email</th>
			<th>SĐT</th>
			<th>Giới tính</th>
			<th>Vai trò</th>
			<th>Thao tác</th>
		</tr>
	</thead>
	<tbody>
		<c:forEach var="user" items="${users}">
			<tr>
				<td>${user.id}</td>
				<td>${user.fullname}</td>
				<td>${user.email}</td>
				<td>${user.mobile}</td>
				<td><c:choose>
						<c:when test="${user.gender}">Nam</c:when>
						<c:otherwise>Nữ</c:otherwise>
					</c:choose></td>
				<td><c:choose>
						<c:when test="${user.role == 1}">
							<span class="badge" style="background: #dc3545; color: white;">👑
								Quản trị</span>
						</c:when>
						<c:when test="${user.role == 0}">
							<span class="badge" style="background: #28a745; color: white;">✍️
								Phóng viên</span>
						</c:when>
						<c:otherwise>
							<span class="badge" style="background: #6c757d; color: white;">👤
								Người đọc</span>
						</c:otherwise>
					</c:choose></td>
				<td>
					<div class="actions">
						<a
							href="${pageContext.request.contextPath}/admin/users?action=edit&id=${user.id}"
							class="btn btn-sm btn-edit">✏️ Sửa</a> <a
							href="${pageContext.request.contextPath}/admin/users?action=delete&id=${user.id}"
							class="btn btn-sm btn-delete"
							onclick="return confirm('Bạn có chắc muốn xóa?')">🗑️ Xóa</a>
					</div>
				</td>
			</tr>
		</c:forEach>
	</tbody>
</table>
