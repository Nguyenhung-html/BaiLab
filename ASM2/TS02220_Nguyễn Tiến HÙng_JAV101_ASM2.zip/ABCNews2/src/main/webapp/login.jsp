<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%
    // Kiểm tra xem có phải người đọc truy cập không
    String userType = request.getParameter("type");
    boolean isReaderLayout = "reader".equals(userType);
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - ABC News</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
            width: 100%;
            max-width: 900px;
            display: flex;
        }
        
        .login-left {
            flex: 1;
            background: linear-gradient(135deg, #c8102e 0%, #8b0a1f 100%);
            padding: 60px 40px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .login-left h1 {
            font-size: 42px;
            margin-bottom: 20px;
        }
        
        .login-left h1 span {
            color: #ffd700;
        }
        
        .login-left p {
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .login-left .features {
            list-style: none;
        }
        
        .login-left .features li {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .login-left .features li i {
            font-size: 20px;
            color: #ffd700;
        }
        
        .login-right {
            flex: 1;
            padding: 60px 40px;
        }
        
        .login-right h2 {
            font-size: 32px;
            color: #333;
            margin-bottom: 10px;
        }
        
        .login-right .subtitle {
            color: #999;
            margin-bottom: 40px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 16px;
        }
        
        .form-control {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #c8102e;
            box-shadow: 0 0 0 4px rgba(200, 16, 46, 0.1);
        }
        
        .form-check {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 25px;
        }
        
        .form-check input {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .form-check label {
            font-size: 14px;
            color: #666;
            cursor: pointer;
        }
        
        .btn-login {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #c8102e 0%, #8b0a1f 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(200, 16, 46, 0.3);
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s;
        }
        
        .alert-error {
            background: #fee;
            color: #c00;
            border-left: 4px solid #c00;
        }
        
        .back-home {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-home a {
            color: #c8102e;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .back-home a:hover {
            gap: 12px;
        }
        
        /* ✅ STYLE CHO NÚT ĐĂNG KÝ */
        .register-link {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }
        
        .register-link p {
            color: #666;
            margin-bottom: 10px;
            font-size: 14px;
        }
        
        .register-link a {
            color: #c8102e;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border: 2px solid #c8102e;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .register-link a:hover {
            background: #c8102e;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(200, 16, 46, 0.3);
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }
            
            .login-left {
                padding: 40px 30px;
            }
            
            .login-right {
                padding: 40px 30px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-left">
            <h1>CHUYỂN ĐỘNG <span>24 GIỜ</span></h1>
            <p>Hệ thống quản lý tin tức chuyên nghiệp, hiện đại và dễ sử dụng</p>
            <ul class="features">
                <li>
                    <i class="fas fa-check-circle"></i>
                    <span>Quản lý tin tức hiệu quả</span>
                </li>
                <li>
                    <i class="fas fa-check-circle"></i>
                    <span>Cập nhật những tin tức nóng hổi</span>
                </li>
                <li>
                    <i class="fas fa-check-circle"></i>
                    <span>Tin tức mới nhất mỗi ngày dành cho bạn</span>
                </li>
                <li>
                    <i class="fas fa-check-circle"></i>
                    <span>Hỗ trợ 24/7</span>
                </li>
            </ul>
        </div>
        
        <div class="login-right">
            <h2>Đăng nhập</h2>
            <p class="subtitle">Vui lòng đăng nhập để tiếp tục</p>
            
            <!-- Hiển thị lỗi -->
            <c:if test="${not empty error}">
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${error}</span>
                </div>
            </c:if>
            
            <form method="post" action="${pageContext.request.contextPath}/login">
                <div class="form-group">
                    <label>Tên đăng nhập</label>
                    <div class="input-wrapper">
                        <i class="far fa-user"></i>
                        <input type="text" name="username" class="form-control" 
                               placeholder="Nhập tên đăng nhập" 
                               value="${username}" required autofocus>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Mật khẩu</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Nhập mật khẩu" required>
                    </div>
                </div>
                
                <div class="form-check">
                    <input type="checkbox" name="remember" id="remember">
                    <label for="remember">Ghi nhớ đăng nhập</label>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Đăng nhập
                </button>
            </form>
            
            <!-- ✅ CHỈ HIỂN THỊ NÚT ĐĂNG KÝ KHI type=reader -->
            <% if (isReaderLayout) { %>
                <div class="register-link">
                    <p>Chưa có tài khoản?</p>
                    <a href="${pageContext.request.contextPath}/register.jsp">
                        <i class="fas fa-user-plus"></i> Đăng ký ngay
                    </a>
                </div>
            <% } %>
            
            <div class="back-home">
                <a href="${pageContext.request.contextPath}/">
                    <i class="fas fa-arrow-left"></i> Quay lại trang chủ
                </a>
            </div>
        </div>
    </div>
</body>
</html>