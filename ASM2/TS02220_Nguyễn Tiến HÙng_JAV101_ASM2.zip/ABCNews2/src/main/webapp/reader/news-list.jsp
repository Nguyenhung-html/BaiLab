<!-- news-list.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Title */
.page-title {
    font-size: 36px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 4px solid #c41e3a;
    display: flex;
    align-items: center;
    gap: 12px;
    position: relative;
    animation: slideDown 0.5s ease;
}

.page-title::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 0;
    width: 120px;
    height: 4px;
    background: linear-gradient(90deg, #ff8c42, transparent);
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* News Grid */
.news-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
    margin-top: 30px;
    animation: fadeIn 0.6s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* News Card */
.news-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
    border: 2px solid transparent;
    position: relative;
    animation: fadeInUp 0.6s ease;
    animation-fill-mode: both;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.news-card:nth-child(1) { animation-delay: 0.1s; }
.news-card:nth-child(2) { animation-delay: 0.2s; }
.news-card:nth-child(3) { animation-delay: 0.3s; }
.news-card:nth-child(4) { animation-delay: 0.4s; }
.news-card:nth-child(5) { animation-delay: 0.5s; }
.news-card:nth-child(6) { animation-delay: 0.6s; }
.news-card:nth-child(7) { animation-delay: 0.7s; }
.news-card:nth-child(8) { animation-delay: 0.8s; }
.news-card:nth-child(9) { animation-delay: 0.9s; }

.news-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #c41e3a 0%, #ff8c42 100%);
    transform: scaleX(0);
    transition: transform 0.4s ease;
}

.news-card:hover::before {
    transform: scaleX(1);
}

.news-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 30px rgba(196, 30, 58, 0.2);
    border-color: #c41e3a;
}

/* News Image */
.news-image {
    width: 100%;
    height: 220px;
    object-fit: cover;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 56px;
    position: relative;
    overflow: hidden;
}

.news-image::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: rgba(255, 255, 255, 0.1);
    transform: rotate(45deg);
    transition: all 0.5s ease;
}

.news-card:hover .news-image::before {
    transform: rotate(45deg) translate(50%, 50%);
}

.news-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.news-card:hover .news-image img {
    transform: scale(1.1);
}

/* News Body */
.news-body {
    padding: 24px;
}

/* News Category */
.news-category {
    display: inline-block;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(196, 30, 58, 0.3);
}

/* News Title */
.news-title {
    font-size: 18px;
    font-weight: 700;
    color: #2c3e50;
    margin: 12px 0;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: color 0.3s ease;
}

.news-card:hover .news-title {
    color: #c41e3a;
}

/* News Excerpt */
.news-excerpt {
    color: #666;
    font-size: 14px;
    line-height: 1.7;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin-bottom: 16px;
}

/* News Meta */
.news-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: #999;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
}

.news-author {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    color: #666;
}

.news-views {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    color: #ff8c42;
}

/* No News Section */
.no-news {
    text-align: center;
    padding: 80px 20px;
    color: #999;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
    animation: fadeIn 0.5s ease;
}

.no-news-icon {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.7;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-15px);
    }
}

.no-news h3 {
    font-size: 24px;
    color: #555;
    margin-bottom: 10px;
}

.no-news p {
    font-size: 16px;
    color: #999;
}

/* Pagination (nếu cần) */
.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 50px;
}

.pagination a,
.pagination span {
    padding: 10px 18px;
    background: white;
    color: #2c3e50;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.pagination a:hover {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(196, 30, 58, 0.3);
}

.pagination span.active {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
}

/* Filter/Sort Section (tùy chọn) */
.filter-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding: 20px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.filter-label {
    font-weight: 600;
    color: #2c3e50;
}

.filter-select {
    padding: 10px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.filter-select:focus {
    outline: none;
    border-color: #ff8c42;
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.1);
}

/* Responsive */
@media (max-width: 1200px) {
    .news-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 25px;
    }
}

@media (max-width: 768px) {
    .page-title {
        font-size: 28px;
    }

    .news-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }

    .news-image {
        height: 180px;
        font-size: 48px;
    }

    .news-body {
        padding: 20px;
    }

    .news-title {
        font-size: 16px;
    }

    .news-excerpt {
        font-size: 13px;
        -webkit-line-clamp: 2;
    }

    .no-news {
        padding: 60px 20px;
    }

    .no-news-icon {
        font-size: 64px;
    }

    .filter-section {
        flex-direction: column;
        gap: 15px;
        align-items: stretch;
    }
}

@media (max-width: 480px) {
    .news-grid {
        grid-template-columns: 1fr;
    }

    .page-title {
        font-size: 24px;
    }
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Selection Color */
::selection {
    background-color: #ff8c42;
    color: white;
}

/* Loading State */
.loading-skeleton {
    background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
    background-size: 200% 100%;
    animation: loading 1.5s infinite;
}

@keyframes loading {
    0% {
        background-position: 200% 0;
    }
    100% {
        background-position: -200% 0;
    }
}
</style>

<h1 class="page-title">
	<c:choose>
		<c:when test="${not empty currentCategory}">
            📂 ${currentCategory.name}
        </c:when>
		<c:otherwise>
            📰 Tất cả tin tức
        </c:otherwise>
	</c:choose>
</h1>

<c:choose>
	<c:when test="${not empty newsList}">
		<div class="news-grid">
			<c:forEach var="news" items="${newsList}">
				<div class="news-card"
					onclick="location.href='${pageContext.request.contextPath}/news/detail?id=${news.id}'">
					<div class="news-image">
						<c:choose>
							<c:when test="${not empty news.image}">
								<img
									src="${pageContext.request.contextPath}/Images/${news.image}"
									alt="${news.title}">
							</c:when>
							<c:otherwise>
                                📰
                            </c:otherwise>
						</c:choose>
					</div>
					<div class="news-body">
						<span class="news-category">${news.categoryName}</span>
						<h3 class="news-title">${news.title}</h3>
						<p class="news-excerpt">${news.content}</p>
						<div class="news-meta">
							<span class="news-author"> <span>✍️</span> <span>${news.authorName}</span>
							</span> <span class="news-views"> <span>👁</span> <span>${news.viewCount}</span>
							</span>
						</div>
					</div>
				</div>
			</c:forEach>
		</div>
	</c:when>
	<c:otherwise>
		<div class="no-news">
			<div class="no-news-icon">📭</div>
			<h3>Chưa có tin tức nào trong danh mục này</h3>
			<p>Hãy quay lại sau để xem tin tức mới nhất!</p>
		</div>
	</c:otherwise>
</c:choose>