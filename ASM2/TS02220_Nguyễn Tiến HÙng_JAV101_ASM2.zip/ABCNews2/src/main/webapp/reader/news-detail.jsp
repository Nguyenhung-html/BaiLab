<!-- news-detail.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Back Button */
.back-button {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 24px;
    background: white;
    color: #2c3e50;
    text-decoration: none;
    border-radius: 8px;
    margin-bottom: 25px;
    transition: all 0.3s ease;
    font-weight: 600;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    border: 2px solid #e8e8e8;
}

.back-button:hover {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
    border-color: #c41e3a;
    transform: translateX(-5px);
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
}

.back-button span:first-child {
    font-size: 18px;
    transition: transform 0.3s ease;
}

.back-button:hover span:first-child {
    transform: translateX(-3px);
}

/* News Detail Container */
.news-detail {
    max-width: 900px;
    margin: 0 auto;
    background: white;
    padding: 40px;
    border-radius: 12px;
    box-shadow: 0 2px 20px rgba(0, 0, 0, 0.08);
    animation: fadeIn 0.5s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* News Detail Header */
.news-detail-header {
    margin-bottom: 35px;
    padding-bottom: 25px;
    border-bottom: 3px solid #c41e3a;
    position: relative;
}

.news-detail-header::after {
    content: '';
    position: absolute;
    bottom: -3px;
    left: 0;
    width: 100px;
    height: 3px;
    background: linear-gradient(90deg, #ff8c42, transparent);
}

/* News Category Badge */
.news-detail-category {
    display: inline-block;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
    padding: 8px 20px;
    border-radius: 25px;
    font-size: 13px;
    font-weight: 700;
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    box-shadow: 0 3px 10px rgba(196, 30, 58, 0.3);
    animation: slideDown 0.5s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* News Title */
.news-detail-title {
    font-size: 38px;
    font-weight: 700;
    color: #2c3e50;
    line-height: 1.4;
    margin-bottom: 25px;
    animation: slideDown 0.6s ease;
}

/* News Meta Information */
.news-detail-meta {
    display: flex;
    gap: 30px;
    color: #666;
    font-size: 14px;
    flex-wrap: wrap;
    animation: slideDown 0.7s ease;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    background: #f8f9fa;
    border-radius: 20px;
    transition: all 0.3s ease;
}

.meta-item:hover {
    background: #fff8f5;
    transform: translateY(-2px);
}

.meta-item span:first-child {
    font-size: 18px;
}

.meta-item strong {
    color: #2c3e50;
    margin-right: 5px;
}

/* News Image */
.news-detail-image {
    width: 100%;
    max-height: 550px;
    object-fit: cover;
    border-radius: 12px;
    margin: 35px 0;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    transition: transform 0.3s ease;
    animation: zoomIn 0.6s ease;
}

@keyframes zoomIn {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

.news-detail-image:hover {
    transform: scale(1.02);
}

/* News Content */
.news-detail-content {
    font-size: 18px;
    line-height: 1.9;
    color: #444;
    margin-bottom: 50px;
    text-align: justify;
}

.news-detail-content p {
    margin-bottom: 24px;
}

.news-detail-content p:first-letter {
    font-size: 28px;
    font-weight: 700;
    color: #c41e3a;
    float: left;
    margin-right: 8px;
    line-height: 1;
}

/* Related News Section */
.related-news-section {
    margin-top: 60px;
    padding-top: 40px;
    border-top: 3px solid #c41e3a;
    position: relative;
}

.related-news-section::after {
    content: '';
    position: absolute;
    top: -3px;
    left: 0;
    width: 120px;
    height: 3px;
    background: linear-gradient(90deg, #ff8c42, transparent);
}

/* Section Title */
.section-title {
    font-size: 28px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 30px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.section-title span:first-child {
    font-size: 32px;
    color: #c41e3a;
}

/* Related News List */
.related-news-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 25px;
}

/* Related News Item */
.related-news-item {
    background: white;
    padding: 20px;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.3s ease;
    border-left: 4px solid #c41e3a;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
    position: relative;
    overflow: hidden;
}

.related-news-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 0;
    background: linear-gradient(180deg, #ff8c42, #ff6b35);
    transition: height 0.3s ease;
}

.related-news-item:hover::before {
    height: 100%;
}

.related-news-item:hover {
    background: #fff8f5;
    box-shadow: 0 6px 20px rgba(196, 30, 58, 0.15);
    transform: translateY(-5px);
    border-left-color: #ff8c42;
}

.related-news-item h4 {
    font-size: 16px;
    font-weight: 600;
    color: #2c3e50;
    margin-bottom: 12px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    line-height: 1.5;
    transition: color 0.3s ease;
}

.related-news-item:hover h4 {
    color: #c41e3a;
}

.related-news-item .date {
    font-size: 12px;
    color: #999;
    display: flex;
    align-items: center;
    gap: 5px;
}

.related-news-item .date::before {
    content: '📅';
    font-size: 14px;
}

/* Responsive */
@media (max-width: 768px) {
    .news-detail {
        padding: 25px 20px;
    }

    .news-detail-title {
        font-size: 28px;
    }

    .news-detail-meta {
        gap: 15px;
    }

    .meta-item {
        font-size: 13px;
        padding: 6px 12px;
    }

    .news-detail-image {
        max-height: 350px;
        margin: 25px 0;
    }

    .news-detail-content {
        font-size: 16px;
        line-height: 1.8;
    }

    .section-title {
        font-size: 22px;
    }

    .related-news-list {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .related-news-section {
        margin-top: 40px;
        padding-top: 30px;
    }
}

@media (max-width: 480px) {
    .news-detail {
        padding: 20px 15px;
    }

    .news-detail-title {
        font-size: 24px;
    }

    .news-detail-category {
        font-size: 12px;
        padding: 6px 16px;
    }

    .back-button {
        padding: 10px 20px;
        font-size: 14px;
    }

    .news-detail-content {
        font-size: 15px;
    }

    .news-detail-content p:first-letter {
        font-size: 24px;
    }
}

/* Print Styles */
@media print {
    .back-button,
    .related-news-section {
        display: none;
    }

    .news-detail {
        box-shadow: none;
        padding: 0;
    }

    .news-detail-image {
        max-height: 400px;
    }
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Selection Color */
::selection {
    background-color: #ff8c42;
    color: white;
}
</style>

<a href="javascript:history.back()" class="back-button"> <span>←</span>
	<span>Quay lại</span>
</a>

<article class="news-detail">
	<header class="news-detail-header">
		<span class="news-detail-category">${news.categoryName}</span>
		<h1 class="news-detail-title">${news.title}</h1>
		<div class="news-detail-meta">
			<div class="meta-item">
				<span>✍️</span> <span><strong>Tác giả:</strong>
					${news.authorName}</span>
			</div>
			<div class="meta-item">
				<span>📅</span> <span><strong>Ngày đăng:</strong> <fmt:formatDate
						value="${news.postedDate}" pattern="dd/MM/yyyy" /></span>
			</div>
			<div class="meta-item">
				<span>👁</span> <span><strong>Lượt xem:</strong>
					${news.viewCount}</span>
			</div>
		</div>
	</header>

	<c:if test="${not empty news.image}">
    <img src="${pageContext.request.contextPath}/Images/${news.image}" 
         alt="${news.title}" class="news-detail-image">
</c:if>


	<div class="news-detail-content">
		<p>${news.content}</p>
	</div>
</article>

<c:if test="${not empty relatedNews}">
	<section class="related-news-section">
		<h2 class="section-title">
			<span>📌</span> <span>Tin tức liên quan</span>
		</h2>
		<div class="related-news-list">
			<c:forEach var="related" items="${relatedNews}" end="5">
				<div class="related-news-item"
					onclick="location.href='${pageContext.request.contextPath}/news/detail?id=${related.id}'">
					<h4>${related.title}</h4>
					<div class="date">
						<fmt:formatDate value="${related.postedDate}" pattern="dd/MM/yyyy" />
					</div>
				</div>
			</c:forEach>
		</div>
	</section>
</c:if>