<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>

<style>
/* Reset và thiết lập chung */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    color: #333;
    line-height: 1.6;
}

/* Page Title */
.page-title {
    font-size: 36px;
    font-weight: 700;
    color: #2c3e50;
    margin-bottom: 30px;
    padding-bottom: 15px;
    border-bottom: 4px solid #c41e3a;
    display: flex;
    align-items: center;
    gap: 12px;
    position: relative;
    animation: slideDown 0.5s ease;
}

.page-title::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 0;
    width: 120px;
    height: 4px;
    background: linear-gradient(90deg, #ff8c42, transparent);
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Alert Success */
.alert {
    padding: 16px 22px;
    border-radius: 10px;
    margin-bottom: 25px;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 12px;
    animation: slideDown 0.4s ease;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
}

.alert-success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
    border-left: 5px solid #28a745;
}

.alert-success span:first-child {
    background: #28a745;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
}

/* News Grid */
.news-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 30px;
    margin-top: 30px;
    animation: fadeIn 0.6s ease;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* News Card */
.news-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
    border: 2px solid transparent;
    position: relative;
    animation: fadeInUp 0.6s ease;
    animation-fill-mode: both;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.news-card:nth-child(1) { animation-delay: 0.1s; }
.news-card:nth-child(2) { animation-delay: 0.2s; }
.news-card:nth-child(3) { animation-delay: 0.3s; }
.news-card:nth-child(4) { animation-delay: 0.4s; }
.news-card:nth-child(5) { animation-delay: 0.5s; }
.news-card:nth-child(6) { animation-delay: 0.6s; }

.news-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #c41e3a 0%, #ff8c42 100%);
    transform: scaleX(0);
    transition: transform 0.4s ease;
}

.news-card:hover::before {
    transform: scaleX(1);
}

.news-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 30px rgba(196, 30, 58, 0.2);
    border-color: #c41e3a;
}

/* News Image */
.news-image {
    width: 100%;
    height: 220px;
    object-fit: cover;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 56px;
    position: relative;
    overflow: hidden;
}

.news-image::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -50%;
    width: 200%;
    height: 200%;
    background: rgba(255, 255, 255, 0.1);
    transform: rotate(45deg);
    transition: all 0.5s ease;
}

.news-card:hover .news-image::before {
    transform: rotate(45deg) translate(50%, 50%);
}

.news-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.news-card:hover .news-image img {
    transform: scale(1.1);
}

/* News Body */
.news-body {
    padding: 24px;
}

/* News Category */
.news-category {
    display: inline-block;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(196, 30, 58, 0.3);
}

/* News Title */
.news-title {
    font-size: 18px;
    font-weight: 700;
    color: #2c3e50;
    margin: 12px 0;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    transition: color 0.3s ease;
}

.news-card:hover .news-title {
    color: #c41e3a;
}

/* News Excerpt */
.news-excerpt {
    color: #666;
    font-size: 14px;
    line-height: 1.7;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin-bottom: 16px;
}

/* News Meta */
.news-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 13px;
    color: #999;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
}

.news-author {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    color: #666;
}

.news-views {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    color: #ff8c42;
}

/* No News Section */
.no-news {
    text-align: center;
    padding: 80px 20px;
    color: #999;
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
    animation: fadeIn 0.5s ease;
}

.no-news-icon {
    font-size: 80px;
    margin-bottom: 20px;
    opacity: 0.7;
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-15px);
    }
}

.no-news h3 {
    font-size: 24px;
    color: #555;
    margin-bottom: 10px;
}

.no-news p {
    font-size: 16px;
    color: #999;
}

/* Featured News (nếu cần) */
.featured-news {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    padding: 35px 40px;
    border-radius: 12px;
    margin-bottom: 40px;
    box-shadow: 0 4px 20px rgba(196, 30, 58, 0.3);
    color: white;
    position: relative;
    overflow: hidden;
}

.featured-news::before {
    content: '⭐';
    position: absolute;
    top: -20px;
    right: 30px;
    font-size: 120px;
    opacity: 0.08;
}

.featured-title {
    font-size: 28px;
    font-weight: 700;
    color: white;
    margin-bottom: 20px;
    position: relative;
    z-index: 1;
}

/* Responsive */
@media (max-width: 1200px) {
    .news-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 25px;
    }
}

@media (max-width: 768px) {
    .page-title {
        font-size: 28px;
    }

    .news-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }

    .news-image {
        height: 180px;
        font-size: 48px;
    }

    .news-body {
        padding: 20px;
    }

    .news-title {
        font-size: 16px;
    }

    .news-excerpt {
        font-size: 13px;
        -webkit-line-clamp: 2;
    }

    .no-news {
        padding: 60px 20px;
    }

    .no-news-icon {
        font-size: 64px;
    }

    .featured-news {
        padding: 25px 20px;
    }

    .featured-title {
        font-size: 22px;
    }
}

@media (max-width: 480px) {
    .news-grid {
        grid-template-columns: 1fr;
    }

    .page-title {
        font-size: 24px;
    }
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Selection Color */
::selection {
    background-color: #ff8c42;
    color: white;
}
</style>

<h1 class="page-title">🏠 Trang nhất</h1>

<c:if test="${not empty message}">
	<div class="alert alert-success">
		<span>✓</span> ${message}
	</div>
</c:if>

<c:choose>
	<c:when test="${not empty homeNews}">
		<div class="news-grid">
			<c:forEach var="news" items="${homeNews}">
				<div class="news-card"
					onclick="location.href='${pageContext.request.contextPath}/news/detail?id=${news.id}'">
					<div class="news-image">
						<c:choose>
							<c:when test="${not empty news.image}">
								<img
									src="${pageContext.request.contextPath}/Images/${news.image}"
									alt="${news.title}">
							</c:when>
							<c:otherwise>
                                📰
                            </c:otherwise>
						</c:choose>
					</div>
					<div class="news-body">
						<span class="news-category">${news.categoryName}</span>
						<h3 class="news-title">${news.title}</h3>
						<p class="news-excerpt">${news.content}</p>
						<div class="news-meta">
							<span class="news-author"> <span>✍️</span> <span>${news.authorName}</span>
							</span> <span class="news-views"> <span>👁</span> <span>${news.viewCount}</span>
							</span>
						</div>
					</div>
				</div>
			</c:forEach>
		</div>
	</c:when>
	<c:otherwise>
		<div class="no-news">
			<div class="no-news-icon">📭</div>
			<h3>Chưa có tin tức nào</h3>
			<p>Hãy quay lại sau để xem tin tức mới nhất!</p>
		</div>
	</c:otherwise>
</c:choose>