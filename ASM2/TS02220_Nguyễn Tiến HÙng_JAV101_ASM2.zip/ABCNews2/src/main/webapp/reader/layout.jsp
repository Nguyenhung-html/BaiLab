<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt"%>
<%@ page buffer="256kb" autoFlush="true"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chuyển động 24 Giờ - Tin tức thời sự hàng ngày</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f8f9fa;
    color: #333;
    line-height: 1.6;
}

/* Header */
.header {
    background: linear-gradient(135deg, #c8102e 0%, #8b0a1f 100%);
    color: white;
    box-shadow: 0 4px 20px rgba(200, 16, 46, 0.3);
    position: sticky;
    top: 0;
    z-index: 1000;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.header-main {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    gap: 30px;
}

.logo {
    font-size: 32px;
    font-weight: bold;
    text-decoration: none;
    color: white;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    display: flex;
    align-items: center;
    gap: 10px;
    white-space: nowrap;
}

/* Search Box */
.search-box {
    flex: 1;
    max-width: 500px;
    position: relative;
}

.search-box input {
    width: 100%;
    padding: 12px 45px 12px 15px;
    border: none;
    border-radius: 25px;
    font-size: 14px;
    outline: none;
    background: rgba(255, 255, 255, 0.95);
    transition: all 0.3s;
}

.search-box input:focus {
    background: white;
    box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.3);
}

.search-box button {
    position: absolute;
    right: 5px;
    top: 50%;
    transform: translateY(-50%);
    background: #ffd700;
    border: none;
    color: #c8102e;
    padding: 8px 16px;
    border-radius: 20px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s;
}

.search-box button:hover {
    background: #ffed4e;
    transform: translateY(-50%) scale(1.05);
}

/* Login Button */
.login-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 25px;
    background: #ffd700;
    color: #c8102e;
    text-decoration: none;
    border-radius: 25px;
    font-weight: bold;
    transition: all 0.3s;
    white-space: nowrap;
}

.login-btn:hover {
    background: #ffed4e;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);
}

/* User Menu */
.user-menu {
    display: flex;
    align-items: center;
    gap: 12px;
}

.user-info {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 16px;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 25px;
    color: white;
    font-weight: 600;
    font-size: 14px;
    white-space: nowrap;
}

.user-avatar {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background: linear-gradient(135deg, #ffd700, #ffed4e);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #c8102e;
    font-size: 20px;
}

.user-name {
    max-width: 150px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.admin-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: #ffd700;
    color: #c8102e;
    text-decoration: none;
    border-radius: 25px;
    font-weight: bold;
    transition: all 0.3s;
    white-space: nowrap;
    font-size: 14px;
}

.admin-btn:hover {
    background: #ffed4e;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(255, 215, 0, 0.4);
}

.logout-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    text-decoration: none;
    border-radius: 25px;
    font-weight: bold;
    transition: all 0.3s;
    white-space: nowrap;
    border: 2px solid rgba(255, 255, 255, 0.3);
    font-size: 14px;
}

.logout-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    border-color: #ffd700;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2);
}

/* Navigation */
.nav {
    background: rgba(0, 0, 0, 0.15);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.nav-list {
    list-style: none;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.nav-list li {
    position: relative;
}

.nav-list a {
    display: block;
    padding: 15px 20px;
    color: white;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.3s;
    border-bottom: 3px solid transparent;
}

.nav-list a:hover, .nav-list a.active {
    background: rgba(255, 255, 255, 0.15);
    border-bottom-color: #ffd700;
}

/* ================================
   SLIDER STYLES - HOÀN CHỈNH
   ================================ */
.slider-container {
    position: relative;
    max-width: 1200px;
    margin: 30px auto;
    overflow: hidden;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    background: #1a1a1a;
}

.slider {
    display: flex;
    width: 100%;      /* BẮT BUỘC – tạo đủ không gian cho 4 slide */
    transition: transform 0.6s ease-in-out;
}


.slide {
    min-width: 100%;
    max-width: 100%;
    flex-shrink: 0;
    position: relative;
    height: 500px;
    display: flex;
    align-items: flex-end;
}

.slide img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
}

.slide-content {
    position: relative;
    z-index: 2;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.9), transparent);
    width: 100%;
    padding: 40px;
    color: white;
}

.slide-content h2 {
    font-size: 32px;
    margin-bottom: 10px;
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
}

.slide-content p {
    font-size: 16px;
    margin-bottom: 15px;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8);
}

.slide-content .read-more {
    display: inline-block;
    padding: 10px 25px;
    background: #c8102e;
    color: white;
    text-decoration: none;
    border-radius: 25px;
    font-weight: bold;
    transition: all 0.3s;
}

.slide-content .read-more:hover {
    background: #a00d25;
    transform: scale(1.05);
}

.slider-controls {
    position: absolute;
    bottom: 20px;
    right: 20px;
    z-index: 3;
    display: flex;
    gap: 10px;
}

.slider-btn {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    border: 2px solid white;
    color: white;
    cursor: pointer;
    font-size: 18px;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.slider-btn:hover {
    background: #c8102e;
    transform: scale(1.1);
}

.slider-dots {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 10px;
    z-index: 3;
}

.dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    cursor: pointer;
    transition: all 0.3s;
}

.dot.active {
    background: #ffd700;
    width: 35px;
    border-radius: 6px;
}

/* Main Content */
.main-content {
    display: flex;
    gap: 30px;
    padding: 30px 0;
}

.content-area {
    flex: 1;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.08);
}

/* Sidebar Container */
.sidebar {
    width: 320px;
    flex-shrink: 0;
}

/* Sidebar Section */
.sidebar-section {
    background: white;
    padding: 0;
    border-radius: 12px;
    margin-bottom: 25px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    border: 2px solid transparent;
    transition: all 0.3s ease;
}

.sidebar-section:hover {
    border-color: #ff8c42;
    box-shadow: 0 6px 25px rgba(255, 140, 66, 0.2);
}

/* Sidebar Title */
.sidebar-title {
    font-size: 20px;
    font-weight: 700;
    color: white;
    margin: 0;
    padding: 20px 24px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    position: relative;
    overflow: hidden;
}

.sidebar-title::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 5px;
    height: 100%;
    background: linear-gradient(180deg, #ff8c42, #ff6b35);
}

.sidebar-title::after {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 150px;
    height: 150px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 50%;
}

/* Sidebar Items Container */
.sidebar-section > div:not(.sidebar-title) {
    padding: 12px 0;
}

/* Sidebar Item */
.sidebar-item {
    padding: 14px 24px;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
    position: relative;
    cursor: pointer;
}

.sidebar-item::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #ff8c42 0%, #ff6b35 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.sidebar-item:hover::before {
    transform: scaleY(1);
}

.sidebar-item:last-child {
    border-bottom: none;
}

.sidebar-item:hover {
    background: linear-gradient(90deg, rgba(255, 140, 66, 0.05) 0%, rgba(255, 107, 53, 0.08) 100%);
    padding-left: 28px;
}

/* Sidebar Item Link */
.sidebar-item a {
    color: #2c3e50;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 14px;
    font-weight: 500;
    line-height: 1.5;
    transition: color 0.3s ease;
}

.sidebar-item:hover a {
    color: #c41e3a;
}

/* Icon */
.sidebar-item .icon {
    color: #c41e3a;
    flex-shrink: 0;
    font-size: 18px;
    transition: all 0.3s ease;
}

.sidebar-item:hover .icon {
    color: #ff8c42;
    transform: scale(1.15) rotate(5deg);
}

/* View Count */
.sidebar-item .view-count {
    color: #999;
    font-size: 12px;
    margin-left: auto;
    background: #f8f9fa;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.sidebar-item:hover .view-count {
    background: linear-gradient(135deg, #ff8c42 0%, #ff6b35 100%);
    color: white;
    transform: scale(1.05);
}

/* Badge (nếu có tin nổi bật) */
.sidebar-item .badge-hot {
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    font-size: 10px;
    padding: 3px 8px;
    border-radius: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% {
        box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.7);
    }
    50% {
        box-shadow: 0 0 0 6px rgba(231, 76, 60, 0);
    }
}

/* Newsletter Form (nếu có) */
.newsletter-form {
    padding: 20px 24px;
}

.newsletter-input {
    width: 100%;
    padding: 12px 16px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    margin-bottom: 12px;
    transition: all 0.3s ease;
}

.newsletter-input:focus {
    outline: none;
    border-color: #ff8c42;
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.1);
}

.newsletter-btn {
    width: 100%;
    padding: 12px;
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.newsletter-btn:hover {
    background: linear-gradient(135deg, #a91729 0%, #c0392b 100%);
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(196, 30, 58, 0.3);
}

/* Categories Sidebar */
.category-item {
    padding: 14px 24px;
    border-bottom: 1px solid #f0f0f0;
    transition: all 0.3s ease;
    position: relative;
    cursor: pointer;
}

.category-item::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 100%;
    width: 4px;
    background: linear-gradient(180deg, #c41e3a 0%, #e74c3c 100%);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.category-item:hover::before {
    transform: scaleY(1);
}

.category-item:last-child {
    border-bottom: none;
}

.category-item:hover {
    background: linear-gradient(90deg, rgba(196, 30, 58, 0.05) 0%, rgba(231, 76, 60, 0.08) 100%);
    padding-left: 28px;
}

.category-item a {
    color: #2c3e50;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 15px;
    font-weight: 600;
    transition: color 0.3s ease;
}

.category-item:hover a {
    color: #c41e3a;
}

.category-item .category-icon {
    font-size: 20px;
    color: #c41e3a;
    transition: all 0.3s ease;
}

.category-item:hover .category-icon {
    color: #ff8c42;
    transform: scale(1.15);
}

.category-item .count {
    margin-left: auto;
    background: #f8f9fa;
    color: #666;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 700;
    transition: all 0.3s ease;
}

.category-item:hover .count {
    background: linear-gradient(135deg, #c41e3a 0%, #e74c3c 100%);
    color: white;
}

/* Responsive */
@media (max-width: 1024px) {
    .sidebar {
        width: 100%;
        margin-top: 40px;
    }

    .sidebar-section {
        margin-bottom: 20px;
    }
}

@media (max-width: 768px) {
    .sidebar-title {
        font-size: 18px;
        padding: 16px 20px;
    }

    .sidebar-item {
        padding: 12px 20px;
    }

    .sidebar-item:hover {
        padding-left: 24px;
    }
}

/* Animation */
.sidebar-section {
    animation: slideInRight 0.5s ease;
}

@keyframes slideInRight {
    from {
        opacity: 0;
        transform: translateX(20px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}
/* Newsletter */
.newsletter-form {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.newsletter-form input {
    flex: 1;
    padding: 10px;
    border: 2px solid #eee;
    border-radius: 5px;
    font-size: 14px;
}

.newsletter-form input:focus {
    outline: none;
    border-color: #c8102e;
}

.newsletter-form button {
    padding: 10px 20px;
    background: linear-gradient(135deg, #c8102e, #8b0a1f);
    color: white;
    border: none;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    transition: transform 0.3s;
}

.newsletter-form button:hover {
    transform: scale(1.05);
}

/* Footer */
.footer {
    background: linear-gradient(135deg, #1a252f 0%, #2c3e50 100%);
    color: white;
    padding: 50px 0 20px;
    margin-top: 50px;
}

.footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 35px;
    margin-bottom: 35px;
}

.footer-section h3 {
    color: #c8102e;
    margin-bottom: 18px;
    font-size: 18px;
    font-weight: bold;
    position: relative;
    padding-bottom: 10px;
}

.footer-section h3::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 40px;
    height: 3px;
    background: #c8102e;
}

.footer-section p {
    color: #bdc3c7;
    text-decoration: none;
    display: block;
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 1.8;
}

.footer-section a {
    color: #bdc3c7;
    text-decoration: none;
    display: block;
    margin-bottom: 10px;
    font-size: 14px;
    transition: all 0.3s;
    padding-left: 0;
}

.footer-section a:hover {
    color: #ffd700;
    padding-left: 8px;
}

.footer-section p i, .footer-section a i {
    color: #c8102e;
    margin-right: 8px;
    width: 18px;
}

.social-links {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.social-link {
    display: flex;
    align-items: center;
    padding: 8px 12px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 5px;
    transition: all 0.3s;
}

.social-link:hover {
    background: rgba(200, 16, 46, 0.8);
    transform: translateX(5px);
    padding-left: 15px;
}

.social-link i {
    margin-right: 10px;
    font-size: 16px;
}

.footer-license {
    background: rgba(0, 0, 0, 0.2);
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 25px;
    border-left: 4px solid #c8102e;
}

.license-content p {
    color: #bdc3c7;
    font-size: 13px;
    margin-bottom: 8px;
    line-height: 1.6;
}

.license-content strong {
    color: #ffd700;
}

.footer-bottom {
    text-align: center;
    padding-top: 25px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    color: #95a5a6;
    font-size: 14px;
}

/* Alerts */
.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border-left: 4px solid #28a745;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border-left: 4px solid #dc3545;
}

/* Responsive */
@media (max-width: 992px) {
    .header-main {
        flex-wrap: wrap;
    }
    .search-box {
        order: 3;
        flex: 1 1 100%;
        max-width: 100%;
    }
    .slide {
        height: 350px;
    }
    .slide-content h2 {
        font-size: 24px;
    }
    .user-menu {
        flex-wrap: wrap;
        justify-content: center;
    }
    .user-info {
        order: -1;
        flex: 1 1 100%;
        justify-content: center;
    }
}

@media (max-width: 768px) {
    .main-content {
        flex-direction: column;
    }
    .sidebar {
        width: 100%;
    }
    .nav-list {
        flex-direction: column;
    }
    .logo {
        font-size: 24px;
    }
    .slide {
        height: 300px;
    }
    .slide-content {
        padding: 20px;
    }
    .slide-content h2 {
        font-size: 20px;
    }
    .user-name {
        display: none;
    }
    .admin-btn span, .logout-btn span {
        display: none;
    }
    .admin-btn, .logout-btn {
        padding: 10px;
        width: 40px;
        height: 40px;
        justify-content: center;
    }
    .user-info {
        padding: 8px 12px;
    }
    .footer-content {
        grid-template-columns: 1fr;
        gap: 25px;
    }
    .footer-license {
        padding: 15px;
    }
    .license-content p {
        font-size: 12px;
    }
}
</style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-main">
                <a href="${pageContext.request.contextPath}/" class="logo">
                    <img src="${pageContext.request.contextPath}/Images/logo.png" alt="logo" style="height: 50px;">
                    <span>Chuyển động 24 giờ</span>
                </a>

                <!-- Search Box -->
                <div class="search-box">
                    <form action="${pageContext.request.contextPath}/news/search" method="get">
                        <input type="text" name="keyword" placeholder="Tìm kiếm tin tức..." required>
                        <button type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>

                <!-- User Menu -->
                <c:choose>
                    <c:when test="${empty sessionScope.user}">
                        <a href="${pageContext.request.contextPath}/login?type=reader" class="login-btn">
                            <i class="fas fa-sign-in-alt"></i>
                            <span>Đăng nhập</span>
                        </a>
                    </c:when>

                    <c:when test="${sessionScope.user.role == 0 || sessionScope.user.role == 1}">
                        <div class="user-menu">
                            <div class="user-info">
                                <div class="user-avatar">
                                    <i class="fas fa-user-circle"></i>
                                </div>
                                <span class="user-name">${sessionScope.user.fullname}</span>
                            </div>
                            <a href="${pageContext.request.contextPath}/admin" class="admin-btn">
                                <i class="fas fa-cog"></i>
                                <span>Quản trị</span>
                            </a>
                            <a href="${pageContext.request.contextPath}/logout" class="logout-btn">
                                <i class="fas fa-sign-out-alt"></i>
                                <span>Đăng xuất</span>
                            </a>
                        </div>
                    </c:when>

                    <c:otherwise>
                        <div class="user-menu">
                            <div class="user-info">
                                <div class="user-avatar">
                                    <i class="fas fa-user-circle"></i>
                                </div>
                                <span class="user-name">${sessionScope.user.fullname}</span>
                            </div>
                            <a href="${pageContext.request.contextPath}/logout" class="logout-btn">
                                <i class="fas fa-sign-out-alt"></i>
                                <span>Đăng xuất</span>
                            </a>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>

        <!-- Navigation -->
        <nav class="nav">
            <div class="container">
                <ul class="nav-list">
                    <li><a href="${pageContext.request.contextPath}/" class="${empty param.category ? 'active' : ''}">
                        <i class="fas fa-home"></i> Trang chủ
                    </a></li>
                    <c:forEach var="cat" items="${categories}">
                        <li><a href="${pageContext.request.contextPath}/news?category=${cat.id}"
                               class="${param.category == cat.id ? 'active' : ''}">${cat.name}</a></li>
                    </c:forEach>
                </ul>
            </div>
        </nav>
    </header>

    <!-- Slider -->
    <div class="container">
        <div class="slider-container">
            <div class="slider" id="slider">
                <!-- Slide 1 -->
                <div class="slide">
                    <img src="${pageContext.request.contextPath}/Images/Bida.png" alt="News 1">
                    <div class="slide-content">
                        <h2>Tin tức nổi bật hôm nay</h2>
                        <p>Nam sinh đánh bạn trong quán Bida</p>
                        <a href="${pageContext.request.contextPath}/detail?id=bcf255ee-3fc6-4a1a-8504-b600ff7db7c1" class="read-more">Đọc thêm →</a>
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="slide">
                    <img src="${pageContext.request.contextPath}/Images/logo.png" alt="News 2">
                    <div class="slide-content">
                        <h2>Bóng đá Việt Nam</h2>
                        <p>Đội tuyển Việt Nam giành chiến thắng lịch sử</p>
                        <a href="#" class="read-more">Đọc thêm →</a>
                    </div>
                </div>

                <!-- Slide 3 -->
                <div class="slide">
                    <img src="${pageContext.request.contextPath}/Images/SmartPhone.jpg" alt="News 3">
                    <div class="slide-content">
                        <h2>Công nghệ & Đổi mới</h2>
                        <p>Khám phá những xu hướng công nghệ mới nhất trên thế giới</p>
                        <a href="#" class="read-more">Đọc thêm →</a>
                    </div>
                </div>

                <!-- Slide 4 -->
                <div class="slide">
                    <img src="${pageContext.request.contextPath}/Images/GiaoDuc.jpg" alt="News 4">
                    <div class="slide-content">
                        <h2>Giáo dục & Đào tạo</h2>
                        <p>Cập nhật tin tức giáo dục và cơ hội học tập mới</p>
                        <a href="#" class="read-more">Đọc thêm →</a>
                    </div>
                </div>
            </div>

            <!-- Slider Controls -->
            <div class="slider-controls">
                <button class="slider-btn" onclick="prevSlide()">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="slider-btn" onclick="nextSlide()">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>

            <!-- Slider Dots -->
            <div class="slider-dots" id="sliderDots"></div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container">
        <div class="main-content">
            <!-- Content Area -->
            <div class="content-area">
                <jsp:include page="${contentPage}" />
            </div>

            <!-- Sidebar -->
            <aside class="sidebar">
                <!-- Hot News -->
                <div class="sidebar-section">
                    <h3 class="sidebar-title">🔥 Tin HOT nhất</h3>
                    <c:forEach var="news" items="${hotNews}">
                        <div class="sidebar-item">
                            <a href="${pageContext.request.contextPath}/news/detail?id=${news.id}">
                                <span class="icon">•</span>
                                <span>${news.title}</span>
                                <span class="view-count">${news.viewCount} 👁</span>
                            </a>
                        </div>
                    </c:forEach>
                </div>

                <!-- Latest News -->
                <div class="sidebar-section">
                    <h3 class="sidebar-title">📰 Tin mới nhất</h3>
                    <c:forEach var="news" items="${latestNews}">
                        <div class="sidebar-item">
                            <a href="${pageContext.request.contextPath}/news/detail?id=${news.id}">
                                <span class="icon">•</span>
                                <span>${news.title}</span>
                            </a>
                        </div>
                    </c:forEach>
                </div>

                <!-- Newsletter -->
                <div class="sidebar-section">
                    <h3 class="sidebar-title">✉️ Nhận bản tin</h3>
                    <p style="font-size: 14px; color: #666; margin-bottom: 10px;">
                        Đăng ký để nhận tin tức mới nhất mỗi ngày</p>
                    <form class="newsletter-form" action="${pageContext.request.contextPath}/newsletter/subscribe" method="post">
                        <input type="email" name="email" placeholder="Email của bạn" required>
                        <button type="submit">Đăng ký</button>
                    </form>
                </div>
            </aside>
        </div>
    </div>
	<!-- Footer -->
	<footer class="footer">
		<div class="container">
			<div class="footer-content">
				<!-- Về Chuyển động 24 Giờ -->
				<div class="footer-section">
					<h3>Về Chuyển động 24 Giờ</h3>
					<p>Chuyển động 24 Giờ - Kênh tin tức trực tuyến hàng đầu Việt
						Nam, cập nhật tin tức trong nước và quốc tế 24/7.</p>
					<p style="margin-top: 15px; font-weight: bold; color: #ffd700;">Sự
						thật - Khách quan - Kịp thời</p>
				</div>

				<!-- Liên hệ -->
				<div class="footer-section">
					<h3>Liên hệ</h3>
					<p>
						<i class="fas fa-envelope"></i> Email: hungntts02220@gmail.com
					</p>
					<p>
						<i class="fas fa-phone"></i> Hotline: 0763 573 616
					</p>
					<p>
						<i class="fas fa-map-marker-alt"></i> Địa chỉ: 179 đường số 20,
						phường An Nhơn, TPHCM, Việt Nam
					</p>
					<p>
						<i class="fas fa-fax"></i> Fax: (028) 3838 6666
					</p>
				</div>

				<!-- Danh mục tin tức -->
				<div class="footer-section">
					<h3>Danh mục tin tức</h3>
					<c:forEach var="cat" items="${categories}">
						<a
							href="${pageContext.request.contextPath}/news?category=${cat.id}">${cat.name}</a>
					</c:forEach>
					<a href="${pageContext.request.contextPath}/news/archive">Kho
						tin tức</a>
				</div>

				<!-- Chính sách & Điều khoản -->
				<div class="footer-section">
					<h3>Chính sách & Điều khoản</h3>
					<a href="${pageContext.request.contextPath}/about">Giới thiệu</a> <a
						href="${pageContext.request.contextPath}/privacy-policy">Chính
						sách bảo mật</a> <a href="${pageContext.request.contextPath}/terms">Điều
						khoản sử dụng</a> <a
						href="${pageContext.request.contextPath}/advertising">Quảng
						cáo</a> <a href="${pageContext.request.contextPath}/contact">Liên
						hệ quảng cáo</a> <a href="${pageContext.request.contextPath}/sitemap">Sơ
						đồ trang</a>
				</div>

				<!-- Hỗ trợ & Dịch vụ -->
				<div class="footer-section">
					<h3>Hỗ trợ & Dịch vụ</h3>
					<a href="${pageContext.request.contextPath}/help">Trung tâm trợ
						giúp</a> <a href="${pageContext.request.contextPath}/feedback">Góp
						ý - Phản hồi</a> <a
						href="${pageContext.request.contextPath}/contribute">Gửi tin
						bài</a> <a href="${pageContext.request.contextPath}/careers">Tuyển
						dụng</a> <a href="${pageContext.request.contextPath}/rss">RSS Feed</a>
					<a href="${pageContext.request.contextPath}/mobile-app">Ứng
						dụng Mobile</a>
				</div>

				<!-- Mạng xã hội -->
				<div class="footer-section">
					<h3>Kết nối với chúng tôi</h3>
					<div class="social-links">
						<a href="#" class="social-link" title="Facebook"> <i
							class="fab fa-facebook-f"></i> Facebook
						</a><a href="#" class="social-link" title="YouTube"><i
							class="fab fa-youtube"></i> YouTube </a><a href="#"
							class="social-link" title="Twitter"> <i
							class="fab fa-twitter"></i> Twitter
						</a><a href="#" class="social-link" title="Instagram"> <i
							class="fab fa-instagram"></i> Instagram
						</a> <a href="#" class="social-link" title="Zalo"> <i
							class="fas fa-comment"></i> Zalo
						</a> <a href="#" class="social-link" title="TikTok"> <i
							class="fab fa-tiktok"></i> TikTok
						</a>
					</div>
					<p style="margin-top: 15px; font-size: 13px;">
						<i class="fas fa-users"></i> Theo dõi để cập nhật tin tức nhanh
						nhất
					</p>
				</div>
			</div>

			<!-- Giấy phép & Bản quyền -->
			<div class="footer-license">
				<div class="license-content">
					<p>
						<strong>Giấy phép xuất bản:</strong> Số 123/GP-BTTTT do Bộ Thông
						tin và Truyền thông cấp ngày 01/01/2020
					</p>
					<p>
						<strong>Tổng biên tập:</strong> Đào Quang Trung | <strong>Phó
							Tổng biên tập:</strong> Nguyễn Văn A
					</p>
					<p>
						<strong>Chịu trách nhiệm nội dung:</strong> Đào Quang Trung -
						Email: trungdqts02218@gmail.com
					</p>
				</div>
			</div>

			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<p>&copy; 2025 Chuyển động 24 Giờ. All rights reserved.</p>
				<p style="font-size: 12px; margin-top: 5px; color: #7f8c8d;">
					Ghi rõ nguồn "Chuyển động 24 Giờ" khi phát hành lại thông tin từ
					website này</p>
			</div>
		</div>
	</footer>

	<style>
/* Enhanced Footer Styles */
.footer {
	background: linear-gradient(135deg, #1a252f 0%, #2c3e50 100%);
	color: white;
	padding: 50px 0 20px;
	margin-top: 50px;
}

.footer-content {
	display: grid;
	grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
	gap: 35px;
	margin-bottom: 35px;
}

.footer-section h3 {
	color: #c8102e;
	margin-bottom: 18px;
	font-size: 18px;
	font-weight: bold;
	position: relative;
	padding-bottom: 10px;
}

.footer-section h3::after {
	content: '';
	position: absolute;
	left: 0;
	bottom: 0;
	width: 40px;
	height: 3px;
	background: #c8102e;
}

.footer-section p {
	color: #bdc3c7;
	text-decoration: none;
	display: block;
	margin-bottom: 10px;
	font-size: 14px;
	line-height: 1.8;
}

.footer-section a {
	color: #bdc3c7;
	text-decoration: none;
	display: block;
	margin-bottom: 10px;
	font-size: 14px;
	transition: all 0.3s;
	padding-left: 0;
}

.footer-section a:hover {
	color: #ffd700;
	padding-left: 8px;
}

.footer-section p i, .footer-section a i {
	color: #c8102e;
	margin-right: 8px;
	width: 18px;
}

/* Social Links */
.social-links {
	display: flex;
	flex-direction: column;
	gap: 10px;
}

.social-link {
	display: flex;
	align-items: center;
	padding: 8px 12px;
	background: rgba(255, 255, 255, 0.05);
	border-radius: 5px;
	transition: all 0.3s;
}

.social-link:hover {
	background: rgba(200, 16, 46, 0.8);
	transform: translateX(5px);
	padding-left: 15px;
}

.social-link i {
	margin-right: 10px;
	font-size: 16px;
}

/* Footer License */
.footer-license {
	background: rgba(0, 0, 0, 0.2);
	padding: 20px;
	border-radius: 8px;
	margin-bottom: 25px;
	border-left: 4px solid #c8102e;
}

.license-content p {
	color: #bdc3c7;
	font-size: 13px;
	margin-bottom: 8px;
	line-height: 1.6;
}

.license-content strong {
	color: #ffd700;
}

/* Footer Bottom */
.footer-bottom {
	text-align: center;
	padding-top: 25px;
	border-top: 1px solid rgba(255, 255, 255, 0.1);
	color: #95a5a6;
	font-size: 14px;
}

/* Responsive */
@media ( max-width : 768px) {
	.footer-content {
		grid-template-columns: 1fr;
		gap: 25px;
	}
	.footer-license {
		padding: 15px;
	}
	.license-content p {
		font-size: 12px;
	}
}
</style>

	<script>
		// Slider functionality
		let currentSlide = 0;
		const slider = document.getElementById('slider');
		const slides = document.querySelectorAll('.slide');
		const totalSlides = slides.length;
		const dotsContainer = document.getElementById('sliderDots');

		// Create dots
		for (let i = 0; i < totalSlides; i++) {
			const dot = document.createElement('div');
			dot.className = 'dot';
			if (i === 0) dot.classList.add('active');
			dot.onclick = () => goToSlide(i);
			dotsContainer.appendChild(dot);
		}

		function updateSlider() {
			slider.style.transform = `translateX(-${currentSlide * (100 / totalSlides)}%)`;

			
			// Update dots
			document.querySelectorAll('.dot').forEach((dot, index) => {
				dot.classList.toggle('active', index === currentSlide);
			});
		}

		function nextSlide() {
			currentSlide = (currentSlide + 1) % totalSlides;
			updateSlider();
		}

		function prevSlide() {
			currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
			updateSlider();
		}

		function goToSlide(index) {
			currentSlide = index;
			updateSlider();
		}

		// Auto slide every 3 seconds
		
		// Pause auto-slide on hover
		const sliderContainer = document.querySelector('.slider-container');
		let autoSlideInterval = setInterval(nextSlide, 3000);

		sliderContainer.addEventListener('mouseenter', () => {
			clearInterval(autoSlideInterval);
		});

		sliderContainer.addEventListener('mouseleave', () => {
			autoSlideInterval = setInterval(nextSlide, 3000);
		});
	</script>
</body>
</html>