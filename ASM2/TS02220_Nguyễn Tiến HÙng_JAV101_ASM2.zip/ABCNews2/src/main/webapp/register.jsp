<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký - Chuyển Động 24G</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .register-container {
            display: flex;
            max-width: 1000px;
            width: 100%;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        
        .left-panel {
            flex: 1;
            background: linear-gradient(135deg, #c1272d 0%, #8b1a1f 100%);
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .left-panel h1 {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .left-panel h2 {
            font-size: 40px;
            font-weight: bold;
            color: #ffd700;
            margin-bottom: 30px;
        }
        
        .left-panel p {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 30px;
            opacity: 0.95;
        }
        
        .features {
            list-style: none;
        }
        
        .features li {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            font-size: 15px;
        }
        
        .features li i {
            background: #ffd700;
            color: #c8102e;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-size: 14px;
        }
        
        .right-panel {
            flex: 1;
            padding: 50px 40px;
            background: #fafafa;
        }
        
        .right-panel h3 {
            font-size: 28px;
            color: #333;
            margin-bottom: 10px;
        }
        
        .right-panel .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
            text-align: center;
            font-size: 14px;
        }
        
        .success strong {
            display: block;
            margin: 5px 0;
            font-size: 16px;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"],
        .form-group input[type="date"],
        .form-group input[type="tel"] {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: white;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #c1272d;
            box-shadow: 0 0 0 3px rgba(193, 39, 45, 0.1);
        }
        
        .radio-group {
            display: flex;
            gap: 30px;
            margin-top: 10px;
        }
        
        .radio-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: normal;
            cursor: pointer;
        }
        
        .radio-group input[type="radio"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .checkbox-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 20px 0;
        }
        
        .checkbox-wrapper input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .checkbox-wrapper label {
            font-size: 14px;
            color: #666;
            margin: 0;
        }
        
        .btn-register {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #c1272d 0%, #8b1a1f 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(193, 39, 45, 0.4);
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .login-link a {
            color: #c1272d;
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .error {
            color: #e74c3c;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }
        
        @media (max-width: 768px) {
            .register-container {
                flex-direction: column;
            }
            
            .left-panel {
                padding: 30px 25px;
            }
            
            .right-panel {
                padding: 30px 25px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <!-- Left Panel -->
        <div class="left-panel">
            <h1>CHUYỂN ĐỘNG</h1>
            <h2>24 GIỜ</h2>
            <p>Đăng ký tài khoản để trải nghiệm đầy đủ các tính năng của Chuyển Động 24G</p>
            
            <ul class="features">
                <li>
                    <i class="fas fa-check"></i>
                    <span>Cập nhật tin tức nóng hổi mỗi ngày</span>
                </li>
                <li>
                    <i class="fas fa-check"></i>
                    <span>Quản lý tin tức hiệu quả</span>
                </li>
                <li>
                    <i class="fas fa-check"></i>
                    <span>Trải nghiệm đọc tin mượt mà</span>
                </li>
                <li>
                    <i class="fas fa-check"></i>
                    <span>Hỗ trợ 24/7</span>
                </li>
            </ul>
        </div>
        
        <!-- Right Panel -->
        <div class="right-panel">
            <h3>Đăng ký Tài khoản</h3>
            <p class="subtitle">Tài khoản của bạn sẽ được tự động tạo Username</p>
            
            <% 
                String error = request.getParameter("error");
                String success = request.getParameter("success");
                String newId = request.getParameter("id");
                
                if (success != null) {
            %>
                <div class="success">
                    <i class="fas fa-check-circle"></i> Đăng ký thành công!<br>
                    <strong>ID của bạn: <%= newId %></strong>
                    <div style="margin-top: 10px;">Vui lòng sử dụng username này để đăng nhập.</div>
                </div>
            <% } %>
            
            <% if (error != null) { %>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <% 
                        if (error.equals("password_mismatch")) {
                            out.print(" Mật khẩu xác nhận không khớp!");
                        } else if (error.equals("email_exists")) {
                            out.print(" Email đã được sử dụng!");
                        } else if (error.equals("mobile_exists")) {
                            out.print(" Số điện thoại đã được sử dụng!");
                        } else if (error.equals("empty_fields")) {
                            out.print(" Vui lòng điền đầy đủ thông tin!");
                        } else {
                            out.print(" Đã có lỗi xảy ra!");
                        }
                    %>
                </div>
            <% } %>
            
            <form action="RegisterServlet" method="post" onsubmit="return validateForm()">
                <div class="form-group">
                    <label for="fullname">Họ và tên <span style="color: red;">*</span></label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" id="fullname" name="fullname" placeholder="Nhập Họ và tên" required>
                    </div>
                    <span class="error" id="fullname-error">Vui lòng nhập Họ và Tên </span>
                </div>
                
                <div class="form-group">
                    <label for="email">Email <span style="color: red;">*</span></label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" placeholder="Nhập email" required>
                    </div>
                    <span class="error" id="email-error">Email không hợp lệ</span>
                </div>
                
                <div class="form-group">
                    <label for="mobile">Số điện thoại <span style="color: red;">*</span></label>
                    <div class="input-wrapper">
                        <i class="fas fa-phone"></i>
                        <input type="tel" id="mobile" name="mobile" placeholder="Nhập số điện thoại" required>
                    </div>
                    <span class="error" id="mobile-error">Số điện thoại không hợp lệ (10 số)</span>
                </div>
                
                <div class="form-group">
                    <label for="birthday">Ngày sinh <span style="color: red;">*</span></label>
                    <div class="input-wrapper">
                        <i class="fas fa-calendar"></i>
                        <input type="date" id="birthday" name="birthday" required>
                    </div>
                    <span class="error" id="birthday-error">Vui lòng chọn ngày sinh</span>
                </div>
                
                <div class="form-group">
                    <label>Giới tính <span style="color: red;">*</span></label>
                    <div class="radio-group">
                        <label>
                            <input type="radio" name="gender" value="1" checked> 
                            <i class="fas fa-mars"></i> Nam
                        </label>
                        <label>
                            <input type="radio" name="gender" value="0"> 
                            <i class="fas fa-venus"></i> Nữ
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">Mật khẩu <span style="color: red;">*</span></label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Nhập mật khẩu" required>
                    </div>
                    <span class="error" id="password-error">Mật khẩu phải có ít nhất 6 ký tự</span>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Xác nhận mật khẩu <span style="color: red;">*</span></label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Nhập lại mật khẩu" required>
                    </div>
                    <span class="error" id="confirm-error">Mật khẩu xác nhận không khớp</span>
                </div>
                
                <div class="checkbox-wrapper">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Tôi đồng ý với điều khoản và dịch vụ</label>
                </div>
                
                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus"></i> Đăng ký
                </button>
            </form>
            
            <div class="login-link">
                <i class="fas fa-arrow-left"></i> Đã có tài khoản? <a href="login.jsp">Đăng nhập ngay</a>
            </div>
        </div>
    </div>
    
    <script>
    function validateForm() {
        let isValid = true;

        // Reset errors
        document.querySelectorAll('.error').forEach(el => el.style.display = 'none');

        // Validate fullname
        const fullname = document.getElementById('fullname').value.trim();
        if (fullname.length < 2) {
            document.getElementById('fullname-error').style.display = 'block';
            isValid = false;
        }

        // Validate email
        const email = document.getElementById('email').value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            document.getElementById('email-error').style.display = 'block';
            isValid = false;
        }

        // Mobile: không ràng buộc 10 số nữa → luôn hợp lệ
        const mobile = document.getElementById('mobile').value.trim();
        if (mobile === "") {
            document.getElementById('mobile-error').textContent = "Vui lòng nhập số điện thoại";
            document.getElementById('mobile-error').style.display = 'block';
            isValid = false;
        }

        // Validate birthday
        const birthday = document.getElementById('birthday').value;
        if (!birthday) {
            document.getElementById('birthday-error').style.display = 'block';
            isValid = false;
        }

        // Password: KHÔNG kiểm tra độ dài nữa
        const password = document.getElementById('password').value.trim();

        // Confirm password phải trùng
        const confirmPassword = document.getElementById('confirm_password').value.trim();
        if (password !== confirmPassword) {
            document.getElementById('confirm-error').style.display = 'block';
            isValid = false;
        }

        return isValid;
    }
</script>

</body>
</html>