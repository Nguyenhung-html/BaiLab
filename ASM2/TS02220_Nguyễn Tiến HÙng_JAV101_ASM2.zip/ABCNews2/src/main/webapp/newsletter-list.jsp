
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<div class="page-header">
    <h1 class="page-title">✉️ Quản lý Newsletter</h1>
</div>

<c:if test="${not empty message}">
    <div class="alert alert-success">✓ ${message}</div>
</c:if>

<c:if test="${not empty error}">
    <div class="alert alert-error">❌ ${error}</div>
</c:if>

<table class="data-table">
    <thead>
        <tr>
            <th>Email</th>
            <th>Trạng thái</th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <c:forEach var="newsletter" items="${newsletters}">
            <tr>
                <td>${newsletter.email}</td>
                <td>
                    <c:choose>
                        <c:when test="${newsletter.enabled}">
                            <span class="badge" style="background: #28a745; color: white;">✓ Hoạt động</span>
                        </c:when>
                        <c:otherwise>
                            <span class="badge" style="background: #dc3545; color: white;">✗ Tạm dừng</span>
                        </c:otherwise>
                    </c:choose>
                </td>
                <td>
                    <div class="actions">
                        <a href="${pageContext.request.contextPath}/admin/newsletters?action=toggle&email=${newsletter.email}" 
                           class="btn btn-sm" style="background: #ffc107; color: white;">
                            🔄 Đổi trạng thái
                        </a>
                        <a href="${pageContext.request.contextPath}/admin/newsletters?action=delete&email=${newsletter.email}" 
                           class="btn btn-sm btn-delete"
                           onclick="return confirm('Bạn có chắc muốn xóa email này?')">
                            🗑️ Xóa
                        </a>
                    </div>
                </td>
            </tr>
        </c:forEach>
    </tbody>
</table>
