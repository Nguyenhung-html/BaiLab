package com.abcnews.listener;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import com.abcnews.dao.CategoryDAO;

@WebListener
public class AppContextListener implements ServletContextListener {
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("========================================");
        System.out.println("ABC News Application Started");
        System.out.println("========================================");
        
        // Load categories vào application scope
        CategoryDAO categoryDAO = new CategoryDAO();
        sce.getServletContext().setAttribute("appCategories", categoryDAO.findAll());
        
        System.out.println("✓ Categories loaded");
        System.out.println("✓ Ready to serve!");
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("ABC News Application Stopped");
    }
}
