package com.abcnews.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.abcnews.entity.Category;
import com.abcnews.utils.DBConnect;
public class CategoryDAO {
	public List<Category> findAll() {
		List<Category> list = new ArrayList<>();
		String sql = "SELECT * FROM Categories ORDER BY Name";

		try (Connection conn = DBConnect.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			while (rs.next()) {
				Category cat = new Category();
				cat.setId(rs.getString("Id"));
				cat.setName(rs.getString("Name"));
				list.add(cat);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public Category findById(String id) {
		String sql = "SELECT * FROM Categories WHERE Id = ?";

		try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				Category cat = new Category();
				cat.setId(rs.getString("Id"));
				cat.setName(rs.getString("Name"));
				return cat;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean insert(Category category) {
		String sql = "INSERT INTO Categories (Id, Name) VALUES (?, ?)";

		try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, category.getId());
			ps.setString(2, category.getName());
			return ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean update(Category category) {
		String sql = "UPDATE Categories SET Name = ? WHERE Id = ?";

		try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, category.getName());
			ps.setString(2, category.getId());
			return ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean delete(String id) {
		String sql = "DELETE FROM Categories WHERE Id = ?";

		try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, id);
			return ps.executeUpdate() > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
