package com.abcnews.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.abcnews.entity.Newsletter;
import com.abcnews.utils.DBConnect;

public class NewsletterDAO {
    
    public List<Newsletter> findAll() {
        List<Newsletter> list = new ArrayList<>();
        String sql = "SELECT * FROM Newsletters ORDER BY Email";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                Newsletter newsletter = new Newsletter();
                newsletter.setEmail(rs.getString("Email"));
                newsletter.setEnabled(rs.getBoolean("Enabled"));
                list.add(newsletter);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<String> findAllActiveEmails() {
        List<String> emails = new ArrayList<>();
        String sql = "SELECT Email FROM Newsletters WHERE Enabled = 1";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                emails.add(rs.getString("Email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emails;
    }
    
    public Newsletter findByEmail(String email) {
        String sql = "SELECT * FROM Newsletters WHERE Email = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                Newsletter newsletter = new Newsletter();
                newsletter.setEmail(rs.getString("Email"));
                newsletter.setEnabled(rs.getBoolean("Enabled"));
                return newsletter;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean insert(Newsletter newsletter) {
        // Check if exists first
        if (findByEmail(newsletter.getEmail()) != null) {
            return false;
        }
        
        String sql = "INSERT INTO Newsletters (Email, Enabled) VALUES (?, ?)";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, newsletter.getEmail());
            ps.setBoolean(2, newsletter.getEnabled());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean update(Newsletter newsletter) {
        String sql = "UPDATE Newsletters SET Enabled = ? WHERE Email = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setBoolean(1, newsletter.getEnabled());
            ps.setString(2, newsletter.getEmail());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(String email) {
        String sql = "DELETE FROM Newsletters WHERE Email = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}