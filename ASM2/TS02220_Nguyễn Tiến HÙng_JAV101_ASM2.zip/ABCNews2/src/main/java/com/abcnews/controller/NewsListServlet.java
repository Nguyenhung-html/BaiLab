// NewsListServlet.java
package com.abcnews.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.CategoryDAO;
import com.abcnews.dao.NewsDAO;
import com.abcnews.entity.Category;
import com.abcnews.entity.News;

@WebServlet("/news")
public class NewsListServlet extends HttpServlet {
	private CategoryDAO categoryDAO = new CategoryDAO();
	private NewsDAO newsDAO = new NewsDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String categoryId = request.getParameter("category");

		// Load categories for menu
		List<Category> categories = categoryDAO.findAll();
		request.setAttribute("categories", categories);

		// Load news by category
		List<News> newsList;
		if (categoryId != null && !categoryId.isEmpty()) {
			newsList = newsDAO.findByCategory(categoryId);
			Category category = categoryDAO.findById(categoryId);
			request.setAttribute("currentCategory", category);
		} else {
			newsList = newsDAO.findAll();
		}
		request.setAttribute("newsList", newsList);

		// Load hot news (sidebar)
		List<News> hotNews = newsDAO.findHottest(5);
		request.setAttribute("hotNews", hotNews);

		// Load latest news (sidebar)
		List<News> latestNews = newsDAO.findLatest(5);
		request.setAttribute("latestNews", latestNews);

		// Set content page
		request.setAttribute("contentPage", "/reader/news-list.jsp");

		// Forward to layout
		request.getRequestDispatcher("/reader/layout.jsp").forward(request, response);
	}
}