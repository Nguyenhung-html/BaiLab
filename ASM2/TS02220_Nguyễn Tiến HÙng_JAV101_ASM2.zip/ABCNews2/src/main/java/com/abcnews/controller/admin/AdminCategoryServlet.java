package com.abcnews.controller.admin;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import com.abcnews.dao.CategoryDAO;
import com.abcnews.entity.Category;

@WebServlet("/admin/categories")
public class AdminCategoryServlet extends HttpServlet {
	private CategoryDAO categoryDAO = new CategoryDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");

		if (action == null) {
			action = "list";
		}

		switch (action) {
		case "add":
			showAddForm(request, response);
			break;
		case "edit":
			showEditForm(request, response);
			break;
		case "delete":
			deleteCategory(request, response);
			break;
		default:
			listCategories(request, response);
			break;
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");

		if ("save".equals(action)) {
			saveCategory(request, response);
		}
	}

	private void listCategories(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Category> categories = categoryDAO.findAll();
		request.setAttribute("categories", categories);
		request.setAttribute("contentPage", "/admin/category-list.jsp");
		request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
	}

	private void showAddForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setAttribute("contentPage", "/admin/category-form.jsp");
		request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		Category category = categoryDAO.findById(id);

		if (category == null) {
			response.sendRedirect(request.getContextPath() + "/admin/categories");
			return;
		}

		request.setAttribute("category", category);
		request.setAttribute("contentPage", "/admin/category-form.jsp");
		request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
	}

	private void saveCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			Category category = new Category();
			BeanUtils.populate(category, request.getParameterMap());

			String oldId = request.getParameter("oldId");

			if (oldId == null || oldId.isEmpty()) {
				// Insert new
				if (categoryDAO.insert(category)) {
					request.getSession().setAttribute("message", "Thêm loại tin thành công!");
				} else {
					request.getSession().setAttribute("error", "Thêm loại tin thất bại!");
				}
			} else {
				// Update
				if (categoryDAO.update(category)) {
					request.getSession().setAttribute("message", "Cập nhật loại tin thành công!");
				} else {
					request.getSession().setAttribute("error", "Cập nhật loại tin thất bại!");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			request.getSession().setAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
		}

		response.sendRedirect(request.getContextPath() + "/admin/categories");
	}

	private void deleteCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");

		if (categoryDAO.delete(id)) {
			request.getSession().setAttribute("message", "Xóa loại tin thành công!");
		} else {
			request.getSession().setAttribute("error", "Xóa loại tin thất bại! Có thể loại tin đang được sử dụng.");
		}

		response.sendRedirect(request.getContextPath() + "/admin/categories");
	}
}