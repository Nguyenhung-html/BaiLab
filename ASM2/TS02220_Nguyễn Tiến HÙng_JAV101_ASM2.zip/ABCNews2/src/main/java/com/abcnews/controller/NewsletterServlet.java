package com.abcnews.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.NewsletterDAO;
import com.abcnews.entity.Newsletter;
import com.abcnews.utils.EmailUtil;

@WebServlet("/newsletter/subscribe")
public class NewsletterServlet extends HttpServlet {
    
    private NewsletterDAO newsletterDAO = new NewsletterDAO();
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String email = request.getParameter("email");
        
        System.out.println("=== NEWSLETTER SUBSCRIPTION ===");
        System.out.println("Email: " + email);
        
        // Validate email
        if (email == null || email.trim().isEmpty()) {
            System.out.println("❌ Email is empty");
            request.getSession().setAttribute("error", "Vui lòng nhập email!");
            redirectBack(request, response);
            return;
        }
        
        // Validate email format
        if (!isValidEmail(email)) {
            System.out.println("❌ Invalid email format");
            request.getSession().setAttribute("error", "Email không hợp lệ!");
            redirectBack(request, response);
            return;
        }
        
        try {
            Newsletter newsletter = new Newsletter(email, true);
            boolean success = newsletterDAO.insert(newsletter);
            
            if (success) {
                System.out.println("✅ Email saved to database: " + email);
                
                // GỬI EMAIL XÁC NHẬN - QUAN TRỌNG
                boolean emailSent = sendWelcomeEmail(email);
                
                if (emailSent) {
                    System.out.println("✅ Welcome email sent successfully!");
                    request.getSession().setAttribute("message", 
                        "Đăng ký thành công! ✅ Vui lòng kiểm tra email để xác nhận.");
                } else {
                    System.out.println("⚠️ Email saved but welcome email failed to send");
                    request.getSession().setAttribute("message", 
                        "Đăng ký thành công! (Email xác nhận sẽ được gửi sau)");
                }
                
            } else {
                System.out.println("❌ Email already exists or insert failed");
                request.getSession().setAttribute("error", "Email này đã được đăng ký trước đó!");
            }
            
        } catch (Exception e) {
            System.err.println("❌ Exception: " + e.getMessage());
            e.printStackTrace();
            request.getSession().setAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        }
        
        redirectBack(request, response);
    }
    
    /**
     * Gửi email chào mừng khi đăng ký thành công
     */
    private boolean sendWelcomeEmail(String email) {
        System.out.println("Sending welcome email to: " + email);
        
        String subject = "🎉 Chào mừng bạn đến với Chuyển động 24 Giờ !";
        
        String htmlContent = buildWelcomeEmailHTML(email);
        
        boolean result = EmailUtil.sendEmail(email, subject, htmlContent);
        
        if (result) {
            System.out.println("✅ Welcome email sent successfully to: " + email);
        } else {
            System.err.println("❌ Failed to send welcome email to: " + email);
        }
        
        return result;
    }
    
    /**
     * Tạo HTML cho email chào mừng
     */
    private String buildWelcomeEmailHTML(String email) {
        String baseUrl = "http://localhost:8080/ABCNews2/admin/newsletters"; // Đổi theo context path của bạn
        
        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "    <meta charset='UTF-8'>" +
               "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
               "    <style>" +
               "        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; margin: 0; }" +
               "        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }" +
               "        .header { background: linear-gradient(135deg, #007bff, #0056b3); color: white; padding: 40px 20px; text-align: center; }" +
               "        .header h1 { margin: 0; font-size: 32px; }" +
               "        .header p { margin: 10px 0 0 0; font-size: 16px; opacity: 0.9; }" +
               "        .content { padding: 40px 30px; }" +
               "        .welcome-text { font-size: 18px; color: #333; line-height: 1.6; margin-bottom: 20px; }" +
               "        .highlight-box { background: #e7f3ff; padding: 20px; border-left: 4px solid #007bff; margin: 20px 0; border-radius: 4px; }" +
               "        .highlight-box p { margin: 5px 0; color: #0056b3; font-size: 16px; }" +
               "        .btn { display: inline-block; padding: 15px 30px; background: linear-gradient(135deg, #007bff, #0056b3);" +
               "               color: white !important; text-decoration: none; border-radius: 5px; font-weight: bold; margin: 20px 0; }" +
               "        .btn:hover { opacity: 0.9; }" +
               "        .benefits { margin: 20px 0; }" +
               "        .benefit-item { display: flex; align-items: flex-start; margin: 15px 0; }" +
               "        .benefit-item .icon { font-size: 24px; margin-right: 10px; }" +
               "        .footer { background: #2c3e50; color: white; padding: 20px; text-align: center; font-size: 14px; }" +
               "        .footer p { margin: 5px 0; }" +
               "    </style>" +
               "</head>" +
               "<body>" +
               "    <div class='container'>" +
               "        <div class='header'>" +
               "            <h1>🎉 Chào mừng!</h1>" +
               "            <p>Cảm ơn bạn đã đăng ký Chuyển động 24 Giờ </p>" +
               "        </div>" +
               "        <div class='content'>" +
               "            <p class='welcome-text'>Xin chào <strong>" + email + "</strong>,</p>" +
               "            <p class='welcome-text'>Cảm ơn bạn đã đăng ký nhận bản tin từ <strong>Chuyển động 24 Giờ </strong>! 📰</p>" +
               "            " +
               "            <div class='highlight-box'>" +
               "                <p>✅ <strong>Đăng ký thành công!</strong></p>" +
               "                <p>Bạn sẽ nhận được tin tức mới nhất ngay khi chúng tôi đăng bài.</p>" +
               "            </div>" +
               "            " +
               "            <p><strong>Bạn sẽ nhận được:</strong></p>" +
               "            <div class='benefits'>" +
               "                <div class='benefit-item'>" +
               "                    <span class='icon'>📬</span>" +
               "                    <span>Tin tức nóng hổi được cập nhật liên tục</span>" +
               "                </div>" +
               "                <div class='benefit-item'>" +
               "                    <span class='icon'>⚡</span>" +
               "                    <span>Thông báo ưu tiên về các bài viết đặc biệt</span>" +
               "                </div>" +
               "                <div class='benefit-item'>" +
               "                    <span class='icon'>🎯</span>" +
               "                    <span>Nội dung được chọn lọc kỹ càng</span>" +
               "                </div>" +
               "            </div>" +
               "            " +
               "            <div style='text-align: center; margin: 30px 0;'>" +
               "                <a href='" + baseUrl + "' class='btn'>Khám phá Chuyển động 24 Giờ  ngay</a>" +
               "            </div>" +
               "            " +
               "            <p style='color: #999; font-size: 14px; margin-top: 30px;'>Chúc bạn có những trải nghiệm tuyệt vời với Chuyển động 24 Giờ ! 🚀</p>" +
               "        </div>" +
               "        <div class='footer'>" +
               "            <p><strong>&copy; 2025 Chuyển động 24 Giờ </strong></p>" +
               "            <p style='margin-top: 10px;'>All rights reserved</p>" +
               "            <p style='font-size: 12px; margin-top: 15px; opacity: 0.8;'>" +
               "                Email: support@abcnews.com | Hotline: 1900-1234" +
               "            </p>" +
               "            <p style='font-size: 11px; margin-top: 10px; opacity: 0.7;'>" +
               "                Bạn nhận được email này vì đã đăng ký nhận bản tin từ Chuyển động 24 Giờ " +
               "            </p>" +
               "        </div>" +
               "    </div>" +
               "</body>" +
               "</html>";
    }
    
    /**
     * Validate email format
     */
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }
    
    /**
     * Redirect về trang trước đó
     */
    private void redirectBack(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        String referer = request.getHeader("Referer");
        response.sendRedirect(referer != null ? referer : request.getContextPath() + "/");
    }
}