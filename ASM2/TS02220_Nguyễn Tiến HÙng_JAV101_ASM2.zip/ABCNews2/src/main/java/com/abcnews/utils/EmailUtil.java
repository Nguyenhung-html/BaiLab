package com.abcnews.utils;

import java.util.List;
import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

public class EmailUtil {
    
    // Cấu hình email sender (Gmail)
    private static final String FROM_EMAIL = "hungntts02220@gmail.com";
    private static final String PASSWORD = "lsnc teyt vvug ekih"; // App password
    
    /**
     * Gửi email đơn
     */
    public static boolean sendEmail(String toEmail, String subject, String htmlContent) {
        System.out.println("=== SENDING EMAIL ===");
        System.out.println("To: " + toEmail);
        System.out.println("Subject: " + subject);
        
        try {
            // Cấu hình properties
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");
            props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
            
            // Debug mode - BẬT để xem lỗi chi tiết
            props.put("mail.debug", "true");
            
            // Tạo session
            Session session = Session.getInstance(props, new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(FROM_EMAIL, PASSWORD);
                }
            });
            
            // Bật debug
            session.setDebug(true);
            
            // Tạo message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL, "ABC News"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setContent(htmlContent, "text/html; charset=UTF-8");
            
            // Gửi email
            Transport.send(message);
            
            System.out.println("✅ Email sent successfully to: " + toEmail);
            return true;
            
        } catch (MessagingException e) {
            System.err.println("❌ MessagingException: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.err.println("❌ Exception: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Gửi newsletter đến nhiều email
     */
    public static void sendNewsletterToAll(List<String> emails, String newsTitle, String newsLink) {
        System.out.println("=== SENDING NEWSLETTER TO " + emails.size() + " RECIPIENTS ===");
        
        String subject = "📰 ABC News - Tin mới: " + newsTitle;
        String htmlContent = buildNewsletterHTML(newsTitle, newsLink);
        
        int successCount = 0;
        int failCount = 0;
        
        for (String email : emails) {
            try {
                if (sendEmail(email, subject, htmlContent)) {
                    successCount++;
                    System.out.println("✅ Sent newsletter to: " + email);
                } else {
                    failCount++;
                    System.err.println("❌ Failed to send to: " + email);
                }
                
                // Delay giữa các email để tránh spam
                Thread.sleep(1000);
                
            } catch (Exception e) {
                failCount++;
                System.err.println("❌ Error sending to: " + email);
                e.printStackTrace();
            }
        }
        
        System.out.println("=== NEWSLETTER SUMMARY ===");
        System.out.println("Success: " + successCount);
        System.out.println("Failed: " + failCount);
    }
    
    /**
     * Tạo HTML content cho newsletter
     */
    private static String buildNewsletterHTML(String newsTitle, String newsLink) {
        return "<!DOCTYPE html>" +
               "<html>" +
               "<head>" +
               "    <meta charset='UTF-8'>" +
               "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
               "    <style>" +
               "        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; margin: 0; }" +
               "        .container { max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }" +
               "        .header { background: linear-gradient(135deg, #007bff, #0056b3); color: white; padding: 30px; text-align: center; }" +
               "        .header h1 { margin: 0; font-size: 28px; }" +
               "        .content { padding: 30px; }" +
               "        .news-title { font-size: 20px; font-weight: bold; color: #333; margin: 20px 0; line-height: 1.4; }" +
               "        .btn { display: inline-block; padding: 12px 30px; background: linear-gradient(135deg, #007bff, #0056b3);" +
               "               color: white !important; text-decoration: none; border-radius: 5px; font-weight: bold; margin: 20px 0; }" +
               "        .btn:hover { opacity: 0.9; }" +
               "        .footer { background: #2c3e50; color: white; padding: 20px; text-align: center; font-size: 14px; }" +
               "        .footer p { margin: 5px 0; }" +
               "    </style>" +
               "</head>" +
               "<body>" +
               "    <div class='container'>" +
               "        <div class='header'>" +
               "            <h1>📰 ABC News</h1>" +
               "            <p>Tin tức mới nhất</p>" +
               "        </div>" +
               "        <div class='content'>" +
               "            <p style='color: #666;'>Xin chào,</p>" +
               "            <p style='color: #666;'>Chúng tôi vừa đăng một bài viết mới mà bạn có thể quan tâm:</p>" +
               "            <div class='news-title'>" + newsTitle + "</div>" +
               "            <div style='text-align: center; margin: 30px 0;'>" +
               "                <a href='" + newsLink + "' class='btn'>Đọc bài viết đầy đủ</a>" +
               "            </div>" +
               "            <p style='color: #999; font-size: 14px;'>Cảm ơn bạn đã theo dõi ABC News!</p>" +
               "        </div>" +
               "        <div class='footer'>" +
               "            <p>&copy; 2025 ABC News. All rights reserved.</p>" +
               "            <p style='font-size: 12px; margin-top: 10px;'>" +
               "                Bạn nhận được email này vì đã đăng ký nhận bản tin từ ABC News." +
               "            </p>" +
               "        </div>" +
               "    </div>" +
               "</body>" +
               "</html>";
    }
    
    /**
     * Test gửi email
     */
    public static void main(String[] args) {
        System.out.println("=== EMAIL TEST STARTING ===");
        
        // Test 1: Gửi đến chính email của bạn
        String testEmail = "hungntts02220@gmail.com"; // Đổi thành email của bạn
        
        boolean success = sendEmail(
            testEmail,
            "Test Email from ABC News",
            "<div style='font-family: Arial; padding: 20px;'>" +
            "<h1 style='color: #007bff;'>Hello from ABC News!</h1>" +
            "<p>This is a test email to verify email sending functionality.</p>" +
            "<p>If you receive this, the email system is working correctly! ✅</p>" +
            "<hr>" +
            "<p style='color: #666; font-size: 12px;'>Sent at: " + new java.util.Date() + "</p>" +
            "</div>"
        );
        
        if (success) {
            System.out.println("\n✅ TEST PASSED: Email sent successfully!");
            System.out.println("Check your inbox: " + testEmail);
        } else {
            System.out.println("\n❌ TEST FAILED: Could not send email");
        }
    }
}