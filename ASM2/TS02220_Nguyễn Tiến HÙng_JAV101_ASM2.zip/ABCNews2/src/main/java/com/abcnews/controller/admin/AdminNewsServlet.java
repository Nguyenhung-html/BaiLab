package com.abcnews.controller.admin;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import org.apache.commons.beanutils.BeanUtils;

import com.abcnews.dao.CategoryDAO;
import com.abcnews.dao.NewsDAO;
import com.abcnews.entity.News;
import com.abcnews.entity.User;

@WebServlet("/admin/news")
@MultipartConfig
public class AdminNewsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private NewsDAO newsDAO = new NewsDAO();
	private CategoryDAO categoryDAO = new CategoryDAO();
	
	// Role constants
	private static final int ROLE_REPORTER = 0;  // Phóng viên
	private static final int ROLE_ADMIN = 1;     // Admin
	private static final int ROLE_READER = 2;    // Người đọc

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		User user = (User) request.getSession().getAttribute("user");

		// Chặn người chưa đăng nhập hoặc người đọc
		if (user == null || user.getRole() == ROLE_READER) {
			response.sendRedirect(request.getContextPath() + "/home");
			return;
		}

		String action = request.getParameter("action");
		if (action == null) action = "list";

		switch (action) {
			case "add":
				showAddForm(request, response);
				break;

			case "edit":
				showEditForm(request, response);
				break;

			case "delete":
				deleteNews(request, response);
				break;

			default:
				listNews(request, response);
				break;
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		if ("save".equals(request.getParameter("action"))) {
			saveNews(request, response);
		}
	}

	// ===================== LIST ============================
	private void listNews(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		User user = (User) request.getSession().getAttribute("user");

		List<News> list = newsDAO.findAll();

		// Phóng viên chỉ xem tin của mình
		if (user.getRole() == ROLE_REPORTER) {
			list.removeIf(n -> !n.getAuthor().equals(user.getId()));
		}

		request.setAttribute("newsList", list);
		request.setAttribute("contentPage", "/admin/news-list.jsp");
		request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
	}

	// ===================== ADD FORM ========================
	private void showAddForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setAttribute("categories", categoryDAO.findAll());
		request.setAttribute("contentPage", "/admin/news-form.jsp");
		request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
	}

	// ===================== EDIT FORM =======================
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		News news = newsDAO.findById(id);

		if (news == null) {
			response.sendRedirect(request.getContextPath() + "/admin/news");
			return;
		}

		User user = (User) request.getSession().getAttribute("user");

		// Phóng viên không được sửa tin người khác
		if (user.getRole() == ROLE_REPORTER && !news.getAuthor().equals(user.getId())) {
			response.sendRedirect(request.getContextPath() + "/admin/news");
			return;
		}

		request.setAttribute("news", news);
		request.setAttribute("categories", categoryDAO.findAll());
		request.setAttribute("contentPage", "/admin/news-form.jsp");
		request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
	}

	// ====================== SAVE NEWS =======================
	private void saveNews(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		try {
			String idForm = request.getParameter("id");
			boolean isNew = (idForm == null || idForm.isEmpty());

			News news = new News();
			BeanUtils.populate(news, request.getParameterMap());

			User user = (User) request.getSession().getAttribute("user");

			String newsId;
			if (isNew) {
				newsId = java.util.UUID.randomUUID().toString();
				news.setId(newsId);
			} else {
				newsId = idForm;
				news.setId(newsId);

				// kiểm tra quyền sửa
				News old = newsDAO.findById(newsId);
				if (user.getRole() == ROLE_REPORTER && !old.getAuthor().equals(user.getId())) {
					response.sendRedirect(request.getContextPath() + "/admin/news");
					return;
				}

				news.setPostedDate(old.getPostedDate());
				news.setAuthor(old.getAuthor());
				news.setViewCount(old.getViewCount());
			}

			// xử lý upload ảnh
			Part file = request.getPart("image");
			if (file != null && file.getSize() > 0) {

				String fileName = System.currentTimeMillis() + "_" + getFileName(file);

				String uploadPath = getServletContext().getRealPath("/Images");
				File dir = new File(uploadPath);
				if (!dir.exists()) dir.mkdirs();

				file.write(uploadPath + File.separator + fileName);
				news.setImage(fileName);

			} else if (!isNew) {
				News old = newsDAO.findById(newsId);
				news.setImage(old.getImage());
			}

			// =================== CHECK HOME ====================
			// phóng viên không được phép đặt home
			if (user.getRole() == ROLE_REPORTER) {
				news.setHome(false);
			} else {
				// admin mới có quyền set home
				news.setHome(request.getParameter("home") != null);
			}

			// set cho thêm mới
			if (isNew) {
				news.setPostedDate(new Date());
				news.setAuthor(user.getId());
				news.setViewCount(0);

				// ✅ SỬA: nwsDAO → newsDAO
				newsDAO.insert(news);
				request.getSession().setAttribute("message", "Thêm tin mới thành công!");
			} else {
				newsDAO.update(news);
				request.getSession().setAttribute("message", "Cập nhật tin thành công!");
			}

		} catch (Exception e) {
			e.printStackTrace();
			request.getSession().setAttribute("error", "Lỗi xử lý tin: " + e.getMessage());
		}

		response.sendRedirect(request.getContextPath() + "/admin/news");
	}

	// ======================== DELETE =========================
	private void deleteNews(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String id = request.getParameter("id");
		User user = (User) request.getSession().getAttribute("user");
		News news = newsDAO.findById(id);

		// Admin hoặc phóng viên xóa tin của chính họ
		if (news != null && (user.getRole() == ROLE_ADMIN || news.getAuthor().equals(user.getId()))) {
			// ✅ SỬA: nwsDAO → newsDAO
			newsDAO.delete(id);
			request.getSession().setAttribute("message", "Xóa tin thành công!");
		} else {
			request.getSession().setAttribute("error", "Không có quyền xóa!");
		}

		response.sendRedirect(request.getContextPath() + "/admin/news");
	}

	// extract filename
	private String getFileName(Part part) {
		String header = part.getHeader("content-disposition");
		for (String s : header.split(";")) {
			if (s.trim().startsWith("filename")) {
				return s.substring(s.indexOf("=") + 2, s.length() - 1);
			}
		}
		return "";
	}
}