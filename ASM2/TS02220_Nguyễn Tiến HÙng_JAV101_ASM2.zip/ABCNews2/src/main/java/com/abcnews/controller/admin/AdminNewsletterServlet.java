package com.abcnews.controller.admin;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.NewsletterDAO;
import com.abcnews.entity.Newsletter;

@WebServlet("/admin/newsletters")
public class AdminNewsletterServlet extends HttpServlet {
    private NewsletterDAO newsletterDAO = new NewsletterDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            deleteNewsletter(request, response);
        } else if ("toggle".equals(action)) {
            toggleNewsletter(request, response);
        } else {
            listNewsletters(request, response);
        }
    }
    
    private void listNewsletters(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Newsletter> newsletters = newsletterDAO.findAll();
        request.setAttribute("newsletters", newsletters);
        request.setAttribute("contentPage", "/admin/newsletter-list.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
    
    private void deleteNewsletter(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        
        if (newsletterDAO.delete(email)) {
            request.getSession().setAttribute("message", "Xóa email thành công!");
        } else {
            request.getSession().setAttribute("error", "Xóa email thất bại!");
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/newsletters");
    }
    
    private void toggleNewsletter(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        Newsletter newsletter = newsletterDAO.findByEmail(email);
        
        if (newsletter != null) {
            newsletter.setEnabled(!newsletter.getEnabled());
            if (newsletterDAO.update(newsletter)) {
                request.getSession().setAttribute("message", "Cập nhật trạng thái thành công!");
            } else {
                request.getSession().setAttribute("error", "Cập nhật trạng thái thất bại!");
            }
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/newsletters");
    }
}