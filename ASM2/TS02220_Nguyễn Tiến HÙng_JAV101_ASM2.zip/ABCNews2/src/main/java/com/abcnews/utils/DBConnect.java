package com.abcnews.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {
	 private static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=ABCNews;encrypt=true;trustServerCertificate=true";
	    private static final String USERNAME = "sa";
	    private static final String PASSWORD = "123"; // Thay đổi mật khẩu của bạn
	    
	    static {
	        try {
	            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	        } catch (ClassNotFoundException e) {
	            throw new RuntimeException("SQL Server JDBC Driver not found", e);
	        }
	    }
	    
	    public static Connection getConnection() throws SQLException {
	        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
	    }
	    
	    public static void close(AutoCloseable... closeables) {
	        for (AutoCloseable closeable : closeables) {
	            if (closeable != null) {
	                try {
	                    closeable.close();
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
}
