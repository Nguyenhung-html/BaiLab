package com.abcnews.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=ABCNews;encrypt=true;trustServerCertificate=true";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "123";

    private String generateReaderId(Connection conn) throws SQLException {
        String newId = "";
        boolean isUnique = false;
        Random random = new Random();

        while (!isUnique) {
            long timestamp = System.currentTimeMillis() % 10000;
            int randomNum = random.nextInt(9000) + 1000;
            newId = "reader" + timestamp + randomNum;

            String sql = "SELECT Id FROM Users WHERE Id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, newId);
            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) {
                isUnique = true;
            }

            rs.close();
            stmt.close();
        }
        return newId;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String password = request.getParameter("password");
        String fullname = request.getParameter("fullname");
        String birthday = request.getParameter("birthday");
        String genderStr = request.getParameter("gender");
        String mobile = request.getParameter("mobile");
        String email = request.getParameter("email");

        // Bỏ hoàn toàn kiểm tra mật khẩu trùng & số điện thoại
        if (password == null || fullname == null || birthday == null || 
            genderStr == null || mobile == null || email == null ||
            password.isEmpty() || fullname.trim().isEmpty() ||
            birthday.isEmpty() || mobile.trim().isEmpty() || email.trim().isEmpty()) {

            response.sendRedirect("register.jsp?error=empty_fields");
            return;
        }

        int gender = Integer.parseInt(genderStr);

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Chỉ kiểm tra email
            String checkEmailSql = "SELECT Email FROM Users WHERE Email = ?";
            stmt = conn.prepareStatement(checkEmailSql);
            stmt.setString(1, email);
            rs = stmt.executeQuery();

            if (rs.next()) {
                response.sendRedirect("register.jsp?error=email_exists");
                return;
            }

            rs.close();
            stmt.close();

            String newId = generateReaderId(conn);

            String insertSql = "INSERT INTO Users (Id, Password, Fullname, Birthday, Gender, Mobile, Email, Role) VALUES (?, ?, ?, ?, ?, ?, ?, 2)";
            stmt = conn.prepareStatement(insertSql);
            stmt.setString(1, newId);
            stmt.setString(2, password); // không bắt buộc 6 ký tự
            stmt.setNString(3, fullname);
            stmt.setString(4, birthday);
            stmt.setInt(5, gender);
            stmt.setString(6, mobile);   // số gì cũng được
            stmt.setString(7, email);

            int result = stmt.executeUpdate();

            if (result > 0) {
                response.sendRedirect("register.jsp?success=true&id=" + newId);
            } else {
                response.sendRedirect("register.jsp?error=unknown");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("register.jsp?error=database");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("register.jsp");
    }
}
