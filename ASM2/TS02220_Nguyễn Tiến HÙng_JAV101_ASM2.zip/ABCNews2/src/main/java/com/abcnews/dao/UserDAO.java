package com.abcnews.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.abcnews.entity.User;
import com.abcnews.utils.DBConnect;

public class UserDAO {

    // ======================== FIND ALL ===========================
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM Users ORDER BY Fullname";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(extractUser(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // ======================== FIND BY ID ===========================
    public User findById(String id) {
        String sql = "SELECT * FROM Users WHERE Id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return extractUser(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ======================== LOGIN ===========================
    public User login(String username, String password) {
        String sql = "SELECT * FROM Users WHERE Id = ? AND Password = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return extractUser(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ======================== INSERT ===========================
    public boolean insert(User user) {
        String sql = "INSERT INTO Users (Id, Password, Fullname, Birthday, Gender, Mobile, Email, Role) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getId());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getFullname());

            if (user.getBirthday() != null) {
                ps.setDate(4, new java.sql.Date(user.getBirthday().getTime()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            if (user.getGender() != null) {
                ps.setBoolean(5, user.getGender());
            } else {
                ps.setNull(5, Types.BOOLEAN);
            }

            ps.setString(6, user.getMobile());
            ps.setString(7, user.getEmail());

            if (user.getRole() != null) {
                ps.setInt(8, user.getRole());
            } else {
                ps.setNull(8, Types.INTEGER);  // ✅ Sửa: BOOLEAN → INTEGER
            }

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ======================== UPDATE ===========================
    public boolean update(User user) {
        String sql = "UPDATE Users SET Password=?, Fullname=?, Birthday=?, Gender=?, "
                + "Mobile=?, Email=?, Role=? WHERE Id=?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, user.getPassword());
            ps.setString(2, user.getFullname());

            if (user.getBirthday() != null) {
                ps.setDate(3, new java.sql.Date(user.getBirthday().getTime()));
            } else {
                ps.setNull(3, Types.DATE);
            }

            if (user.getGender() != null) {
                ps.setBoolean(4, user.getGender());
            } else {
                ps.setNull(4, Types.BOOLEAN);
            }

            ps.setString(5, user.getMobile());
            ps.setString(6, user.getEmail());

            if (user.getRole() != null) {
                ps.setInt(7, user.getRole());
            } else {
                ps.setNull(7, Types.INTEGER);  // ✅ Sửa: BOOLEAN → INTEGER
            }

            ps.setString(8, user.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ======================== DELETE ===========================
    public boolean delete(String id) {
        String sql = "DELETE FROM Users WHERE Id = ?";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ======================== EXTRACT USER ===========================
    private User extractUser(ResultSet rs) throws SQLException {
        User u = new User();

        u.setId(rs.getString("Id"));
        u.setPassword(rs.getString("Password"));
        u.setFullname(rs.getString("Fullname"));
        u.setBirthday(rs.getDate("Birthday"));

        boolean gender = rs.getBoolean("Gender");
        u.setGender(rs.wasNull() ? null : gender);

        u.setMobile(rs.getString("Mobile"));
        u.setEmail(rs.getString("Email"));

        // ✅ Sửa: "role" → "Role" (viết hoa chữ R)
        int role = rs.getInt("Role");
        u.setRole(rs.wasNull() ? null : role);
        
        return u;
    }
}