package com.abcnews.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.abcnews.dao.UserDAO;
import com.abcnews.entity.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO = new UserDAO();
    
    private static final int ROLE_REPORTER = 0;
    private static final int ROLE_ADMIN = 1;
    private static final int ROLE_READER = 2;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
        if (session != null && session.getAttribute("user") != null) {
            User user = (User) session.getAttribute("user");
            redirectByRole(request, response, user);
            return;
        }
        
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            request.setAttribute("error", "Vui lòng nhập đầy đủ thông tin!");
            request.setAttribute("username", username);
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }
        
        try {
            User user = userDAO.login(username.trim(), password);
            
            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                session.setAttribute("username", user.getId());
                session.setAttribute("fullname", user.getFullname());
                session.setAttribute("role", user.getRole());
                session.setMaxInactiveInterval(30 * 60);
                
                redirectByRole(request, response, user);
            } else {
                request.setAttribute("error", "Tên đăng nhập hoặc mật khẩu không đúng!");
                request.setAttribute("username", username);
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi hệ thống! Vui lòng thử lại sau.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    } 
    
    private void redirectByRole(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        String contextPath = request.getContextPath();
        
        switch (user.getRole()) {
            case ROLE_ADMIN:
                response.sendRedirect(contextPath + "/admin");
                break;
            case ROLE_REPORTER:
                response.sendRedirect(contextPath + "/admin");
                break;
            case ROLE_READER:
                response.sendRedirect(contextPath + "/home");
                break;
            default:
                response.sendRedirect(contextPath + "/home");
                break;
        }
    }
}