package com.abcnews.listener;

import java.util.List;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;
import com.abcnews.dao.NewsletterDAO;
import com.abcnews.utils.EmailUtil;

/**
 * Listener này có thể được sử dụng để gửi email
 * Trong thực tế, bạn nên tích hợp vào AdminNewsServlet
 * khi insert news mới
 */
@WebListener
public class NewsListener implements HttpSessionListener {
    
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        // Khởi tạo session
    }
    
    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        // Cleanup
    }
    
    /**
     * Method này được gọi từ AdminNewsServlet khi có tin mới
     */
    public static void sendNewsletterForNewNews(String newsId, String newsTitle, String newsLink) {
        // Chạy trong thread riêng để không block request
        new Thread(() -> {
            try {
                NewsletterDAO dao = new NewsletterDAO();
                List<String> emails = dao.findAllActiveEmails();
                
                if (!emails.isEmpty()) {
                    EmailUtil.sendNewsletterToAll(emails, newsTitle, newsLink);
                    System.out.println("Newsletter sent to " + emails.size() + " subscribers");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}