package com.abcnews.controller.admin;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.UserDAO;
import com.abcnews.entity.User;

@WebServlet("/admin/users")
public class AdminUserServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list";
        }
        
        switch (action) {
            case "add":
                showAddForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "delete":
                deleteUser(request, response);
                break;
            default:
                listUsers(request, response);
                break;
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        
        if ("save".equals(action)) {
            saveUser(request, response);
        }
    }
    
    private void listUsers(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<User> users = userDAO.findAll();
        request.setAttribute("users", users);
        request.setAttribute("contentPage", "/admin/user-list.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
    
    private void showAddForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // KHÔNG SET editUser - form sẽ hiện chế độ thêm mới
        request.setAttribute("contentPage", "/admin/user-form.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String id = request.getParameter("id");
        User editUser = userDAO.findById(id);  // ✅ ĐỔI TÊN BIẾN
        
        if (editUser == null) {
            response.sendRedirect(request.getContextPath() + "/admin/users");
            return;
        }
        
        // ✅ DÙNG "editUser" THAY VÌ "user"
        request.setAttribute("editUser", editUser);
        request.setAttribute("contentPage", "/admin/user-form.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
    
    private void saveUser(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            User newUser = new User();
            newUser.setId(request.getParameter("id"));
            newUser.setPassword(request.getParameter("password"));
            newUser.setFullname(request.getParameter("fullname"));
            newUser.setMobile(request.getParameter("mobile"));
            newUser.setEmail(request.getParameter("email"));
            newUser.setGender("true".equals(request.getParameter("gender")));
            newUser.setRole(Integer.parseInt(request.getParameter("role")));

            
            // Parse birthday
            String birthdayStr = request.getParameter("birthday");
            if (birthdayStr != null && !birthdayStr.isEmpty()) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                newUser.setBirthday(sdf.parse(birthdayStr));
            }
            
            String oldId = request.getParameter("oldId");
            
            if (oldId == null || oldId.isEmpty()) {
                // INSERT NEW
                if (userDAO.insert(newUser)) {
                    request.getSession().setAttribute("message", "Thêm người dùng thành công!");
                } else {
                    request.getSession().setAttribute("error", "Thêm người dùng thất bại!");
                }
            } else {
                // UPDATE - giữ nguyên password cũ nếu không nhập mới
                if (newUser.getPassword() == null || newUser.getPassword().trim().isEmpty()) {
                    User oldUser = userDAO.findById(oldId);
                    if (oldUser != null) {
                        newUser.setPassword(oldUser.getPassword());
                    }
                }
                
                if (userDAO.update(newUser)) {
                    request.getSession().setAttribute("message", "Cập nhật người dùng thành công!");
                } else {
                    request.getSession().setAttribute("error", "Cập nhật người dùng thất bại!");
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/users");
    }
    
    private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String id = request.getParameter("id");
        
        // Không cho xóa user đang đăng nhập
        User currentUser = (User) request.getSession().getAttribute("user");
        if (currentUser.getId().equals(id)) {
            request.getSession().setAttribute("error", "Không thể xóa tài khoản đang đăng nhập!");
        } else {
            if (userDAO.delete(id)) {
                request.getSession().setAttribute("message", "Xóa người dùng thành công!");
            } else {
                request.getSession().setAttribute("error", "Xóa người dùng thất bại!");
            }
        }
        
        response.sendRedirect(request.getContextPath() + "/admin/users");
    }
}