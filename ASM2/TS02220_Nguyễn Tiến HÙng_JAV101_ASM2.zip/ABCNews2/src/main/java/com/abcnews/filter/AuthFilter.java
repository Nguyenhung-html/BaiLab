package com.abcnews.filter;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.abcnews.entity.User;

@WebFilter("/admin/*")
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String uri = req.getRequestURI();

        // Cho phép file tĩnh
        if (uri.endsWith(".png") || uri.endsWith(".jpg") || uri.endsWith(".jpeg")
                || uri.endsWith(".gif") || uri.endsWith(".css") || uri.endsWith(".js")
                || uri.contains("/Images/") || uri.contains("/assets/")) {

            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;

        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        int role = user.getRole(); // 1 = admin, 0 = reporter, 2 = reader

        // ❌ 1. Người đọc không được phép truy cập /admin/*
        if (role == 2) {
            res.sendRedirect(req.getContextPath() + "/home");
            return;
        }

        // ❌ 2. Phóng viên chỉ được phép vào /admin/news/*
        if (role == 0 && !uri.startsWith(req.getContextPath() + "/admin/news")) {
            res.sendRedirect(req.getContextPath() + "/admin/news");
            return;
        }

        // ✔ Hợp lệ
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {}

}
