package com.abcnews.entity;

import java.util.Date;

public class News {
	 private String id;
	    private String title;
	    private String content;
	    private String image;
	    private Date postedDate;
	    private String author;
	    private Integer viewCount;
	    private String categoryId;
	    private Boolean home;
	    
	    // For display purposes
	    private String categoryName;
	    private String authorName;
	    
	    public News() {}
	    
	    public String getId() { return id; }
	    public void setId(String id) { this.id = id; }
	    public String getTitle() { return title; }
	    public void setTitle(String title) { this.title = title; }
	    public String getContent() { return content; }
	    public void setContent(String content) { this.content = content; }
	    public String getImage() { return image; }
	    public void setImage(String image) { this.image = image; }
	    public Date getPostedDate() { return postedDate; }
	    public void setPostedDate(Date postedDate) { this.postedDate = postedDate; }
	    public String getAuthor() { return author; }
	    public void setAuthor(String author) { this.author = author; }
	    public Integer getViewCount() { return viewCount; }
	    public void setViewCount(Integer viewCount) { this.viewCount = viewCount; }
	    public String getCategoryId() { return categoryId; }
	    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }
	    public Boolean getHome() { return home; }
	    public void setHome(Boolean home) { this.home = home; }
	    public String getCategoryName() { return categoryName; }
	    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }
	    public String getAuthorName() { return authorName; }
	    public void setAuthorName(String authorName) { this.authorName = authorName; }
	}

