package com.abcnews.controller.admin;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.NewsDAO;
import com.abcnews.dao.UserDAO;
import com.abcnews.dao.CategoryDAO;
import com.abcnews.dao.NewsletterDAO;
import com.abcnews.entity.User;

@WebServlet("/admin")
public class AdminDashboardServlet extends HttpServlet {
    
    private static final int ROLE_REPORTER = 0;
    private static final int ROLE_ADMIN = 1;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        User user = (User) request.getSession().getAttribute("user");
        
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // ✅ CHO PHÉP CẢ ADMIN (1) VÀ PHÓNG VIÊN (0)
        if (user.getRole() != ROLE_ADMIN && user.getRole() != ROLE_REPORTER) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }
        
        NewsDAO newsDAO = new NewsDAO();
        UserDAO userDAO = new UserDAO();
        CategoryDAO categoryDAO = new CategoryDAO();
        NewsletterDAO newsletterDAO = new NewsletterDAO();
        
        request.setAttribute("totalNews", newsDAO.findAll().size());
        request.setAttribute("totalUsers", userDAO.findAll().size());
        request.setAttribute("totalCategories", categoryDAO.findAll().size());
        request.setAttribute("totalSubscribers", newsletterDAO.findAll().size());
        
        request.setAttribute("contentPage", "/admin/dashboard.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
}