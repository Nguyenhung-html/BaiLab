package com.abcnews.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.abcnews.dao.CategoryDAO;
import com.abcnews.dao.NewsDAO;
import com.abcnews.entity.Category;
import com.abcnews.entity.News;

@WebServlet("/news/detail")
public class NewsDetailServlet extends HttpServlet {
	private CategoryDAO categoryDAO = new CategoryDAO();
	private NewsDAO newsDAO = new NewsDAO();

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String newsId = request.getParameter("id");

		if (newsId == null || newsId.isEmpty()) {
			response.sendRedirect(request.getContextPath() + "/");
			return;
		}

		// Load news detail
		News news = newsDAO.findById(newsId);
		if (news == null) {
			response.sendRedirect(request.getContextPath() + "/");
			return;
		}

		// Increase view count
		newsDAO.increaseViewCount(newsId);

		// Save to recently viewed (cookie)
		saveRecentlyViewed(request, response, newsId);

		// Load categories for menu
		List<Category> categories = categoryDAO.findAll();
		request.setAttribute("categories", categories);

		// Load related news (same category)
		List<News> relatedNews = newsDAO.findByCategory(news.getCategoryId());
		relatedNews.removeIf(n -> n.getId().equals(newsId)); // Remove current news
		request.setAttribute("relatedNews", relatedNews);

		request.setAttribute("news", news);

		// Load hot news (sidebar)
		List<News> hotNews = newsDAO.findHottest(5);
		request.setAttribute("hotNews", hotNews);

		// Load latest news (sidebar)
		List<News> latestNews = newsDAO.findLatest(5);
		request.setAttribute("latestNews", latestNews);

		// Set content page
		request.setAttribute("contentPage", "/reader/news-detail.jsp");

		// Forward to layout
		request.getRequestDispatcher("/reader/layout.jsp").forward(request, response);
	}

	private void saveRecentlyViewed(HttpServletRequest request, HttpServletResponse response, String newsId) {
		Cookie[] cookies = request.getCookies();
		String recentViewed = "";

		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if ("recentViewed".equals(cookie.getName())) {
					recentViewed = cookie.getValue();
					break;
				}
			}
		}

		// Split theo dấu gạch ngang (an toàn trong cookie)
		String[] ids = recentViewed.split("-");

		StringBuilder newRecentViewed = new StringBuilder(newsId);
		int count = 1;

		for (String id : ids) {
			if (!id.isEmpty() && !id.equals(newsId) && count < 5) {
				newRecentViewed.append("-").append(id);
				count++;
			}
		}

		Cookie cookie = new Cookie("recentViewed", newRecentViewed.toString());
		cookie.setMaxAge(7 * 24 * 60 * 60); // 7 days
		cookie.setPath("/");
		response.addCookie(cookie);
	}
}