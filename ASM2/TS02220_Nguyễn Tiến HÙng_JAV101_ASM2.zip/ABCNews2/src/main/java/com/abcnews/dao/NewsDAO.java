package com.abcnews.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.abcnews.entity.News;
import com.abcnews.utils.DBConnect;
public class NewsDAO {
	public List<News> findAll() {
        List<News> list = new ArrayList<>();
        String sql = "SELECT n.*, c.Name as CategoryName, u.Fullname as AuthorName " +
                     "FROM News n " +
                     "LEFT JOIN Categories c ON n.CategoryId = c.Id " +
                     "LEFT JOIN Users u ON n.Author = u.Id " +
                     "ORDER BY PostedDate DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(extractNews(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<News> findByCategory(String categoryId) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT n.*, c.Name as CategoryName, u.Fullname as AuthorName " +
                     "FROM News n " +
                     "LEFT JOIN Categories c ON n.CategoryId = c.Id " +
                     "LEFT JOIN Users u ON n.Author = u.Id " +
                     "WHERE n.CategoryId = ? " +
                     "ORDER BY PostedDate DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoryId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(extractNews(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<News> findHomeNews() {
        List<News> list = new ArrayList<>();
        String sql = "SELECT n.*, c.Name as CategoryName, u.Fullname as AuthorName " +
                     "FROM News n " +
                     "LEFT JOIN Categories c ON n.CategoryId = c.Id " +
                     "LEFT JOIN Users u ON n.Author = u.Id " +
                     "WHERE n.Home = 1 " +
                     "ORDER BY PostedDate DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(extractNews(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<News> findHottest(int limit) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT TOP (?) n.*, c.Name as CategoryName, u.Fullname as AuthorName " +
                     "FROM News n " +
                     "LEFT JOIN Categories c ON n.CategoryId = c.Id " +
                     "LEFT JOIN Users u ON n.Author = u.Id " +
                     "ORDER BY ViewCount DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(extractNews(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public List<News> findLatest(int limit) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT TOP (?) n.*, c.Name as CategoryName, u.Fullname as AuthorName " +
                     "FROM News n " +
                     "LEFT JOIN Categories c ON n.CategoryId = c.Id " +
                     "LEFT JOIN Users u ON n.Author = u.Id " +
                     "ORDER BY PostedDate DESC";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(extractNews(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public News findById(String id) {
        String sql = "SELECT n.*, c.Name as CategoryName, u.Fullname as AuthorName " +
                     "FROM News n " +
                     "LEFT JOIN Categories c ON n.CategoryId = c.Id " +
                     "LEFT JOIN Users u ON n.Author = u.Id " +
                     "WHERE n.Id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return extractNews(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean insert(News news) {
        // ✅ Thêm Id vào câu SQL
        String sql = "INSERT INTO News (Id, Title, Content, Image, PostedDate, Author, ViewCount, CategoryId, Home) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            System.out.println("=== DEBUG DAO INSERT ===");
            System.out.println("ID: " + news.getId());
            System.out.println("Title: " + news.getTitle());
            System.out.println("CategoryId: " + news.getCategoryId());
            
            ps.setString(1, news.getId());              // Id
            ps.setString(2, news.getTitle());           // Title
            ps.setString(3, news.getContent());         // Content
            ps.setString(4, news.getImage());           // Image
            
            // ✅ Dùng setDate() vì database dùng DATE, không phải DATETIME
            ps.setDate(5, new java.sql.Date(news.getPostedDate().getTime())); // PostedDate
            
            ps.setString(6, news.getAuthor());          // Author
            ps.setInt(7, news.getViewCount());          // ViewCount
            ps.setString(8, news.getCategoryId());      // CategoryId
            ps.setBoolean(9, news.getHome());           // Home
            
            int result = ps.executeUpdate();
            System.out.println("Insert result: " + result + " row(s) affected");
            
            return result > 0;
            
        } catch (SQLException e) {
            System.out.println("DAO ERROR: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    public boolean update(News news) {
        String sql = "UPDATE News SET Title = ?, Content = ?, Image = ?, CategoryId = ?, Home = ? WHERE Id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, news.getTitle());
            ps.setString(2, news.getContent());
            ps.setString(3, news.getImage());
            ps.setString(4, news.getCategoryId());
            ps.setBoolean(5, news.getHome());
            ps.setString(6, news.getId());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(String id) {
        String sql = "DELETE FROM News WHERE Id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean increaseViewCount(String id) {
        String sql = "UPDATE News SET ViewCount = ViewCount + 1 WHERE Id = ?";
        
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private News extractNews(ResultSet rs) throws SQLException {
        News news = new News();
        news.setId(rs.getString("Id"));
        news.setTitle(rs.getString("Title"));
        news.setContent(rs.getString("Content"));
        news.setImage(rs.getString("Image"));
        news.setPostedDate(rs.getDate("PostedDate"));
        news.setAuthor(rs.getString("Author"));
        news.setViewCount(rs.getInt("ViewCount"));
        news.setCategoryId(rs.getString("CategoryId"));
        news.setHome(rs.getBoolean("Home"));
        news.setCategoryName(rs.getString("CategoryName"));
        news.setAuthorName(rs.getString("AuthorName"));
        return news;
    }
}
