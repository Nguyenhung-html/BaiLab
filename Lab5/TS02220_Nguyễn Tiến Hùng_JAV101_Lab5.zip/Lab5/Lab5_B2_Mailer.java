package Lab5;

import java.util.Properties;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.Authenticator;
import javax.mail.Message.RecipientType;

public class Lab5_B2_Mailer {
	public static void send(String from, String to, String subject, String body) {
		// Code send mail đặt ở đây
		// Thông số kết nối GMail
		Properties props = new Properties();
		props.setProperty("mail.smtp.auth", "true");
		props.setProperty("mail.smtp.starttls.enable", "true");
		props.setProperty("mail.smtp.host", "smtp.gmail.com");
		props.setProperty("mail.smtp.port", "587");
		// Đăng nhập GMail
		Session session = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				String username = "hungntts02220@gmail.com";
				String password = "lsnc teyt vvug ekih";
				return new PasswordAuthentication(username, password);
			}
		});
		try {
			// Tạo mail
			MimeMessage mail = new MimeMessage(session);
			mail.setFrom(new InternetAddress(from));
			mail.setRecipients(RecipientType.TO, to);
			mail.setSubject(subject, "utf-8");
			mail.setText(body, "utf-8", "html");
			mail.setReplyTo(mail.getFrom());
			// Gửi mail
			Transport.send(mail);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
