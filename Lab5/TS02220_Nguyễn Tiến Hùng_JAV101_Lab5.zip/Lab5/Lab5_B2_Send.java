package Lab5;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Lab5_JSP/send")
public class Lab5_B2_Send extends HttpServlet {
	 @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
	        req.getRequestDispatcher("/Lab5_JSP/L5_B2.jsp").forward(req, resp);
	    }

	    @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {

	        String from = req.getParameter("from");
	        String to = req.getParameter("to");
	        String subject = req.getParameter("subject");
	        String body = req.getParameter("body");

	        Lab5_B2_Mailer.send(from, to, subject, body);

	        req.setAttribute("message", "Đã gửi email!");

	        req.getRequestDispatcher("/Lab5_JSP/L5_B2.jsp").forward(req, resp);
	    }
}
