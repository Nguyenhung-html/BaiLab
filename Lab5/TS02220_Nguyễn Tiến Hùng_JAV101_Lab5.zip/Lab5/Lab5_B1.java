package Lab5;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.Converter;

@WebServlet("/save")
public class Lab5_B1 extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.getRequestDispatcher("/Lab5_JSP/L5_B1.jsp").forward(req, resp);

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Staff bean = new Staff(); // dùng để chứa dữ liệu form
		try {
			// Khai báo định dạng ngày
			DateConverter  dtc = new DateConverter();
			dtc.setPattern("MM/dd/yyyy");
			ConvertUtils.register(dtc, Date.class);
			// đọc và chuyển đổi tham số vào bean
			BeanUtils.populate(bean, req.getParameterMap());
			
			 // Đẩy bean sang JSP để hiển thị
            req.setAttribute("form", bean);
			System.out.println(bean.getFullname());
		} catch (Exception e) {
			e.printStackTrace();
		}
		req.getRequestDispatcher("/Lab5_JSP/save.jsp").forward(req, resp);
	}
	
}
